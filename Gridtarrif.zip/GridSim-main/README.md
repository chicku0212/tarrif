# Digital Twin Dashboard & Simulator

Welcome to the Digital Twin Simulator & Dashboard. This application serves as a comprehensive system for real-time electrical grid simulation and load forecasting using deep learning models.

## Infrastructure
The backend architecture is built primarily on:
- **FastAPI**: Serves RESTful endpoints and WebSocket streams.
- **PyTorch**: Model inference for LSTM, Deep LSTM, and Transformer networks.
- **TimescaleDB & PostgreSQL**: Storage for structured historical measurements.
- **Redis**: Streaming states, snapshot architectures, and request rate limiting.

### Digital Twin Components
1. **Simulator**: Replays historical multi-variate dataset simulating actual load and weather behaviors. Speed adjustments are completely configurable.
2. **State Manager**: Routes simulated loads into hot storage and structured databases.
3. **Forecasting Engine**: Real-time evaluation of data utilizing multiple pre-trained ML models.

## Frontend Dashboard
Built with **Vite**, **React**, and **Tailwind CSS**.
The frontend features live streaming connection matching simulation state directly into visualizations.

**New Feature - Multi-Model Analytics (`ModelPerformanceMetrics`):**
- Dynamic multi-model performance streaming driven strictly by the backend simulation loop. The backend computes `RMSE`, `MAE`, `R2`, and `MAPE` natively.
- Metrics are completely perfectly synchronized with the graph visually at any simulation speed as they share the WebSocket connection payload.
- Automatic ranking evaluating models based on real-time MAPE margins.
- Interactive spark-lines mapping history degradation gracefully without relying on HTTP polling.

**New Feature - Queue-Based What-If Analysis Panel:**
- Fully animated scrolling queue that preserves up to 5 concurrent scenarios in `PredictionComparison.jsx`.
- Calculates simulated maximum peaks (`Δ Max`) and presents LSTM, DeepLSTM, and Transformer results on a unified gradient scale.
- Cross-talks asynchronously with `app/routers/simulation.py` to evaluate hypothetical real-world deviations instantly.

## Getting Started

1. Set up python virtual environment, install dependencies (`requirements.txt`) and `npm install` for dashboard.
2. Initialize Docker container for Redis.
3. Configure PostgreSQL parameters within the `.env` settings.
4. Run `uvicorn app.main:app --reload` for the backend and `npm run dev` for the frontend dashboard.

**New Feature - Intelligent Alert Notification System:**
- Processes real-time WebSocket data (`liveData`) from `simulated_data` stream.
- Dynamically generates Weather (Amber) and Grid (Red/Orange) alerts using a historical rolling buffer for conditions like Rapid Temp Rise and Demand Spikes.
- Self-managing alert lifecycle: Deduplicates alerts using a 2-hour simulation lock-out mechanism, auto-dismisses on max limit (20), and tracks unread count.
- Includes Web Audio API integration for unobtrusive sound notifications (default muted).
