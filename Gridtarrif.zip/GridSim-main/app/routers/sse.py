import asyncio
import logging
from fastapi import APIRouter
from sse_starlette.sse import EventSourceResponse
import redis.asyncio as redis
from src.config import settings

router = APIRouter()
logger = logging.getLogger("SSERouter")

@router.get("/sse/stream")
async def sse_stream():
    """Server-Sent Events endpoint for real-time updates."""
    async def event_generator():
        redis_client = redis.Redis(
            host=settings.redis.host,
            port=settings.redis.port,
            db=settings.redis.db,
            password=settings.redis.password,
            decode_responses=True
        )
        pubsub = redis_client.pubsub()
        await pubsub.subscribe("digital_twin:updates")
        logger.info("SSE Client subscribed to digital_twin:updates")
        
        # Send initial connection confirmation
        yield {
            "event": "message",
            "data": "connected"
        }

        try:
            async for message in pubsub.listen():
                if message["type"] == "message":
                    yield {
                        "event": "update",
                        "data": message["data"]
                    }
        except asyncio.CancelledError:
            logger.info("SSE Client disconnected")
        finally:
            await pubsub.close()
            await redis_client.close()

    return EventSourceResponse(event_generator())
