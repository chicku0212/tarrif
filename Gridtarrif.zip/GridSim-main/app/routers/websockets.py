import asyncio
import json
import logging
import os
from typing import List, Optional
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
import redis.asyncio as redis
from starlette.websockets import WebSocketState

from src.config import settings

router = APIRouter()
logger = logging.getLogger("WebSocketRouter")

class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.redis_client: Optional[redis.Redis] = None
        self.pubsub = None

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"Client connected. Total clients: {len(self.active_connections)}")
        
        # If this is the first connection, start the Redis listener
        if len(self.active_connections) == 1:
             asyncio.create_task(self.start_redis_listener())

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
            logger.info(f"Client disconnected. Total clients: {len(self.active_connections)}")

    async def broadcast(self, message: str):
        # Iterate over a copy to avoid modification during iteration issues
        for connection in self.active_connections.copy():
            try:
                if connection.client_state == WebSocketState.CONNECTED:
                    await connection.send_text(message)
            except Exception as e:
                logger.error(f"Error broadcasting to client: {e}")
                self.disconnect(connection)

    async def start_redis_listener(self):
        """Subscribes to Redis channel and broadcasts messages to Websockets."""
        if not self.redis_client:
            redis_url = os.environ.get("REDIS_URL")
            if redis_url:
                self.redis_client = redis.from_url(
                    redis_url, 
                    decode_responses=True,
                    health_check_interval=30,
                    socket_keepalive=True
                )
            else:
                self.redis_client = redis.Redis(
                    host=settings.redis.host,
                    port=settings.redis.port,
                    db=settings.redis.db,
                    password=settings.redis.password,
                    ssl=settings.redis.ssl or "upstash.io" in settings.redis.host,
                    ssl_cert_reqs="none",
                    decode_responses=True,
                    health_check_interval=30,
                    socket_keepalive=True
                )
        
        self.pubsub = self.redis_client.pubsub()
        await self.pubsub.subscribe("digital_twin:updates")
        logger.info("Subscribed to Redis channel: digital_twin:updates")

        try:
            async for message in self.pubsub.listen():
                if message["type"] == "message":
                    await self.broadcast(message["data"])
        except Exception as e:
            logger.error(f"Redis listener error: {e}")
        finally:
             if self.pubsub:
                 await self.pubsub.close()
                 logger.info("Redis listener closed.")

manager = ConnectionManager()

@router.websocket("/ws/dashboard")
async def websocket_dashboard(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            # Keep the connection open.
            # We don't necessarily expect input from the client, 
            # but we need to await something to keep the loop running.
            # A simple heartbeat or just waiting for disconnect.
            await websocket.receive_text() 
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        manager.disconnect(websocket)
