from fastapi import APIRouter, HTTPException, Query, Request
from typing import List, Optional, Dict
from datetime import datetime, timedelta
import asyncpg
from pydantic import BaseModel
import pandas as pd
import numpy as np
import torch
from sklearn.metrics import root_mean_squared_error, mean_absolute_error, r2_score

from src.config import settings
from app.schemas import WeatherPoint

router = APIRouter()


class AnalyticsResponse(BaseModel):
    timestamp: datetime
    value: float

class AccuracyMetrics(BaseModel):
    mape: float
    rmse: float
    period_start: datetime
    period_end: datetime

async def get_db_connection():
    dsn = f"postgresql://{settings.database.user}:{settings.database.password}@{settings.database.host}:{settings.database.port}/{settings.database.name}"
    return await asyncpg.connect(dsn)

@router.get("/analytics/daily-peak", response_model=List[AnalyticsResponse])
async def get_daily_peak(days: int = 30):
    """Get daily peak load for the last N days."""
    conn = await get_db_connection()
    try:
        query = """
            SELECT date_trunc('day', timestamp) as day, MAX(load) as max_load
            FROM digital_twin_states
            WHERE timestamp > NOW() - INTERVAL '$1 days'
            GROUP BY day
            ORDER BY day ASC
        """
        # asyncpg requires explicit parameter indices like $1
        rows = await conn.fetch(query.replace('$1', str(days)))
        return [AnalyticsResponse(timestamp=row['day'], value=row['max_load']) for row in rows]
    finally:
        await conn.close()

@router.get("/analytics/average-load-hourly", response_model=List[Dict[str, float]])
async def get_average_load_hourly():
    """Get average load by hour of day (0-23)."""
    conn = await get_db_connection()
    try:
        query = """
            SELECT EXTRACT(HOUR FROM timestamp) as hour, AVG(load) as avg_load
            FROM digital_twin_states
            GROUP BY hour
            ORDER BY hour ASC
        """
        rows = await conn.fetch(query)
        result = [{"hour": row['hour'], "avg_load": row['avg_load']} for row in rows]
        return result
    finally:
        await conn.close()

@router.get("/analytics/accuracy", response_model=AccuracyMetrics)
async def get_prediction_accuracy(days: int = 7):
    """Calculate MAPE over the last N days."""
    conn = await get_db_connection()
    try:
        query = """
            SELECT load, prediction
            FROM digital_twin_states
            WHERE timestamp > NOW() - INTERVAL '$1 days'
              AND prediction IS NOT NULL
        """
        rows = await conn.fetch(query.replace('$1', str(days)))
        
        if not rows:
            return AccuracyMetrics(mape=0.0, rmse=0.0, period_start=datetime.now(), period_end=datetime.now())

        df = pd.DataFrame(rows, columns=['load', 'prediction'])
        df['abs_error'] = abs(df['load'] - df['prediction'])
        df['pct_error'] = df['abs_error'] / df['load']
        
        mape = (df['pct_error'].mean()) * 100
        rmse = np.sqrt(((df['load'] - df['prediction']) ** 2).mean())
        
        return AccuracyMetrics(
            mape=round(mape, 2),
            rmse=round(rmse, 2),
            period_start=datetime.now() - timedelta(days=days),
            period_end=datetime.now()
        )
    finally:
        await conn.close()

class ModelPerformanceMetricsResp(BaseModel):
    rmse: float
    mae: float
    mape: float
    smape: float
    r2: float
    mape_history: List[float]

@router.get("/analytics/model-performance", response_model=Dict[str, ModelPerformanceMetricsResp])
async def get_model_performance(request: Request):
    """Calculate performance metrics for all three models over the last 24 live tracking hours."""
    models = request.app.state.models if hasattr(request.app.state, 'models') else {}
    preprocessor = request.app.state.preprocessor if hasattr(request.app.state, 'preprocessor') else None
    
    if not models or not preprocessor:
        raise HTTPException(status_code=503, detail="Models are not loaded on backend.")

    conn = await get_db_connection()
    try:
        # Fetch last 48 records to allow rolling 24h predictions for the last 24h of actuals
        rows = await conn.fetch("""
            SELECT timestamp, load, temperature_2m, relative_humidity_2m, windspeed_10m, dew_point_2m
            FROM digital_twin_states
            WHERE load IS NOT NULL
            ORDER BY timestamp DESC
            LIMIT 48
        """)
        
        # We need at least 25 points total to make 1 prediction.
        if len(rows) < 25:
            # Not enough data for meaningful metric, return dummy or zeros mapping
            return {
                m: ModelPerformanceMetricsResp(rmse=0.0, mae=0.0, mape=0.0, smape=0.0, r2=0.0, mape_history=[0.0]*24)
                for m in models.keys()
            }
            
        rows_asc = rows[::-1] # Ordered chronological (oldest to newest)
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        results = {}
        for model_name, model in models.items():
            scaler_type = "transformer" if model_name == "transformer" else "lstm"
            preds = []
            actuals = []
            mapes = []
            
            # Slide window: For each valid target in the last (len - 24) records
            for i in range(len(rows_asc) - 24):
                window = rows_asc[i : i+24]
                target_row = rows_asc[i+23]  # Target aligns with the LAST timestep in the 24h window
                
                w_points = [
                    WeatherPoint(
                        timestamp=r['timestamp'].isoformat() if hasattr(r['timestamp'], 'isoformat') else str(r['timestamp']),
                        temperature=r['temperature_2m'],
                        humidity=r['relative_humidity_2m'],
                        wind_speed=r['windspeed_10m']
                    ) for r in window
                ]
                
                try:
                    w_points_converted = [w for w in w_points]
                    input_tensor = preprocessor.prepare_input(w_points_converted, model_type=scaler_type).to(device)
                    
                    with torch.no_grad():
                        pred_scaled = model(input_tensor).item()
                        
                    dummy_row = np.zeros((1, 12))
                    dummy_row[0, -1] = pred_scaled
                    scaler = preprocessor.scaler_transformer if scaler_type == "transformer" else preprocessor.scaler_lstm
                    pred_mw = scaler.inverse_transform(dummy_row)[0, -1]
                    
                    preds.append(pred_mw)
                    target_load = float(target_row['load'])
                    actuals.append(target_load)
                    
                    err = abs(target_load - pred_mw) / target_load * 100 if target_load > 0 else 0
                    mapes.append(err)
                except Exception as e:
                    print(f"Error predicting point: {e}")
                    continue
            
            if len(actuals) > 0:
                y_true = np.array(actuals)
                y_pred = np.array(preds)
                
                # Use imported functions correctly
                try:
                    from sklearn.metrics import root_mean_squared_error, mean_absolute_error, r2_score
                    rmse = float(root_mean_squared_error(y_true, y_pred))
                    mae = float(mean_absolute_error(y_true, y_pred))
                    r2 = float(r2_score(y_true, y_pred))
                except Exception:
                    # Fallback math if import fails or versions differ
                    rmse = float(np.sqrt(((y_true - y_pred)**2).mean()))
                    mae = float(np.abs(y_true - y_pred).mean())
                    r2 = 0.0 # simplified if failing
                
                mape = float(np.mean(mapes))
                
                # Calculate sMAPE
                smapes = 200 * np.abs(y_true - y_pred) / (np.abs(y_true) + np.abs(y_pred) + 1e-8)
                smape_val = float(np.mean(smapes))
                
                # Padded to 24 if needed
                padded_mapes = mapes[-24:]
                if len(padded_mapes) < 24:
                    padded_mapes = [0]*(24 - len(padded_mapes)) + padded_mapes

                results[model_name] = ModelPerformanceMetricsResp(
                    rmse=float(round(rmse, 2)),
                    mae=float(round(mae, 2)),
                    mape=float(round(mape, 2)),
                    smape=float(round(smape_val, 2)),
                    r2=float(round(r2, 4)),
                    mape_history=[float(round(m, 2)) for m in padded_mapes]
                )
            else:
                results[model_name] = ModelPerformanceMetricsResp(rmse=0.0, mae=0.0, mape=0.0, smape=0.0, r2=0.0, mape_history=[0.0]*24)
                
        return results
    finally:
        await conn.close()
