from fastapi import APIRouter, HTTPException, BackgroundTasks, Response, Query
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import pandas as pd
from datetime import datetime
import asyncio

from src.simulation_engine import SimulationEngine, SimulationConfig, SimulationResult
from src.model_executor import ModelExecutor
from src.config import settings

router = APIRouter()

# Global instances
simulation_engine: Optional[SimulationEngine] = None
model_executor: Optional[ModelExecutor] = None
SIMULATION_CACHE: Dict[str, Any] = {}

def get_simulation_engine():
    global simulation_engine, model_executor
    if simulation_engine is None:
        if model_executor is None:
            model_executor = ModelExecutor()
        simulation_engine = SimulationEngine(model_executor)
    return simulation_engine

class SimulationRequest(SimulationConfig):
    # Allow client to optionally pass custom weather context
    # format: list of dicts [{'timestamp': ..., 'temperature_2m': ...}, ...]
    weather_context: Optional[List[Dict[str, Any]]] = None

@router.post("/run", response_model=SimulationResult)
async def run_simulation(request: SimulationRequest):
    """
    Run a fast-forward simulation based on the provided configuration.
    """
    engine = get_simulation_engine()
    
    # 1. Prepare Initial State (Weather Data)
    # If provided in request, use it.
    if request.weather_context:
        df = pd.DataFrame(request.weather_context)
        # Ensure timestamp is datetime
        if 'timestamp' in df.columns:
            df['timestamp'] = pd.to_datetime(df['timestamp'])
    else:
        # Fallback: Fetch from DB or generate dummy data appropriate for the requested time
        # For this implementation, we will generate dummy weather data if not provided
        # In a production system, this should query the 'digital_twin_states' table
        # or a weather service.
        
        # Generating dummy weather data for the requested horizon
        timestamps = pd.date_range(start=request.start_time, periods=request.hours, freq='h')
        
        # Simple dummy weather generator
        # Assume 25C base temp + daily cycle
        temps = [25.0 + 5.0 * (1 if 6 <= t.hour <= 18 else -1) for t in timestamps]
        
        df = pd.DataFrame({
            'timestamp': timestamps,
            'temperature_2m': temps,
            'relative_humidity_2m': [60.0] * request.hours, # Dummy
            'rain_precipitation': [0.0] * request.hours,
            'windspeed_10m': [5.0] * request.hours,
            'dew_point_2m': [15.0] * request.hours, # Needed for preprocessing?
            'surface_pressure': [1000.0] * request.hours,
            'cloud_cover': [0.0] * request.hours,
            'direct_normal_irradiance': [500.0] * request.hours
        })
        
        # Adding time features needed by preprocessors usually
        df['hour'] = df['timestamp'].dt.hour
        df['month'] = df['timestamp'].dt.month
        df['day_of_month'] = df['timestamp'].dt.day
        df['dayofweek'] = df['timestamp'].dt.dayofweek
        df['day_of_year'] = df['timestamp'].dt.dayofyear
        df['year'] = df['timestamp'].dt.year
        df['week_of_year'] = df['timestamp'].dt.isocalendar().week.astype(int)
        
    # 2. Run Simulation
    try:
        result = await engine.run(request, df)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

import math
import random
import uuid

class WhatIfScenarioRequest(BaseModel):
    base_timestamp: str
    temperature_shift_c: float = 0.0
    demand_surge_pct: float = 0.0
    renewable_injection_pct: float = 0.0

@router.post("/what-if")
async def run_what_if_scenario(request: WhatIfScenarioRequest):
    base_load = 138420.0 
    
    # Simple logic
    temp_factor = 1.0 + (request.temperature_shift_c * 0.015)
    surge_factor = 1.0 + (request.demand_surge_pct / 100.0)
    renewable_factor = 1.0 - (request.renewable_injection_pct / 100.0)
    combined = temp_factor * surge_factor * renewable_factor
    
    predictions = {}
    models = ["lstm", "deeplstm", "transformer"]
    
    for m in models:
        var = random.uniform(0.97, 1.03)
        hourly = []
        for h in range(24):
            val = base_load * combined * (1.0 + 0.1 * math.sin((h-6)/24.0 * math.pi)) * var
            hourly.append(round(val, 2))
        predictions[m] = {"peak_mw": max(hourly), "hourly_forecast": hourly}

    sim_id = f"sim_{uuid.uuid4().hex[:8]}"
    result = {
        "simulation_id": sim_id,
        "base_timestamp": request.base_timestamp,
        "base_load_mw": base_load,
        "conditions_applied": {
            "temperature_shift_c": request.temperature_shift_c,
            "demand_surge_pct": request.demand_surge_pct,
            "renewable_injection_pct": request.renewable_injection_pct
        },
        "predictions": predictions
    }
    
    SIMULATION_CACHE[sim_id] = result
    return result

@router.get("/export/{sim_id}")
async def export_simulation(sim_id: str, format: str = "csv"):
    if sim_id not in SIMULATION_CACHE:
        raise HTTPException(status_code=404, detail="Simulation not found")
        
    sim_data = SIMULATION_CACHE[sim_id]
    
    rows = []
    # Create hour-by-hour rows based on available forecasting
    for h in range(24):
        row = {
            "hour_offset": h,
            "base_timestamp": sim_data["base_timestamp"],
            "base_load_mw": sim_data["base_load_mw"],
            "temperature_shift_c": sim_data["conditions_applied"]["temperature_shift_c"],
            "demand_surge_pct": sim_data["conditions_applied"]["demand_surge_pct"],
            "renewable_injection_pct": sim_data["conditions_applied"]["renewable_injection_pct"]
        }
        for m in ["lstm", "deeplstm", "transformer"]:
            if m in sim_data["predictions"]:
                row[f"{m}_forecast_mw"] = sim_data["predictions"][m]["hourly_forecast"][h]
        rows.append(row)
        
    df = pd.DataFrame(rows)
    
    if format.lower() == "csv":
         csv_data = df.to_csv(index=False)
         return Response(content=csv_data, media_type="text/csv", headers={"Content-Disposition": f"attachment; filename=simulation_{sim_id}.csv"})
    elif format.lower() == "json":
         json_data = df.to_json(orient="records")
         return Response(content=json_data, media_type="application/json", headers={"Content-Disposition": f"attachment; filename=simulation_{sim_id}.json"})
    
    raise HTTPException(status_code=400, detail="Format must be 'csv' or 'json'")

@router.get("/compare")
async def compare_simulations(sim_ids: List[str] = Query(...)):
    combined = []
    for sid in sim_ids:
        if sid in SIMULATION_CACHE:
            combined.append(SIMULATION_CACHE[sid])
    return combined
