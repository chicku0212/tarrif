from fastapi import APIRouter, HTTPException, Depends
from typing import Optional, Dict, Any
import redis.asyncio as redis
import json
from src.config import settings
# from app.main import get_prediction # Circular import if not careful, better to inject service

router = APIRouter()

async def get_redis():
    import os
    redis_url = os.getenv("REDIS_URL", getattr(settings, "redis_url", None))
    if not redis_url:
        # fallback to old config if REDIS_URL is not set
        client = redis.Redis(
            host=settings.redis.host,
            port=settings.redis.port,
            db=settings.redis.db,
            password=settings.redis.password,
            decode_responses=True
        )
    else:
        client = redis.from_url(redis_url, ssl_cert_reqs=None, decode_responses=True)
    try:
        yield client
    finally:
        await client.close()

@router.get("/grid/status")
async def get_grid_status(redis_client: redis.Redis = Depends(get_redis)):
    """Get the latest real-time grid state from Redis."""
    data = await redis_client.get("digital_twin:current_state")
    if not data:
        raise HTTPException(status_code=404, detail="No grid state available")
    return json.loads(data)

@router.get("/predictions/24h")
async def get_forecast(model: str = "lstm", redis_client: redis.Redis = Depends(get_redis)):
    """
    Get 24-hour forecast. 
    Options for model: 'lstm', 'deeplstm', 'transformer'.
    """
    # Validate model name
    if model not in ["lstm", "deeplstm", "transformer"]:
         raise HTTPException(status_code=400, detail="Invalid model. Choose from: lstm, deeplstm, transformer")
         
    key = f"digital_twin:forecast:24h:{model}"
    data = await redis_client.get(key)
    
    if data:
        return json.loads(data)
    
    # Optional: Trigger background job to generate forecast
    # For now, return status indicating computation needed
    return {"status": "pending", "message": f"Forecast for {model} not yet generated"}

@router.get("/historical/{region}")
async def get_historical_data(region: str, start: str, end: str):
    """Placeholder for fetching historical data from TimescaleDB."""
    # This logic is similar to analytics router but filtered by region and raw data
    return {"message": "Not implemented yet - requires specific query logic"}
