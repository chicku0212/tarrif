import pandas as pd
import numpy as np
import pickle
import math
import torch
from pathlib import Path
from typing import List
from app.schemas import WeatherPoint

# Constants for dew point calculation
A = 17.27
B = 237.7

class Preprocessor:
    def __init__(self, scaler_path_lstm: str, scaler_path_transformer: str):
        self.scaler_lstm = self._load_scaler(scaler_path_lstm)
        self.scaler_transformer = self._load_scaler(scaler_path_transformer)
        # Expected features order for the models
        self.FEATURES = ["hour", "day_of_month", "dayofweek", "day_of_year", "month", "year", 
                         "week_of_year", "temperature_2m", "relative_humidity_2m", 
                         "windspeed_10m", "dew_point_2m"]

    def _load_scaler(self, path: str):
        if not Path(path).exists():
            raise FileNotFoundError(f"Scaler not found at {path}")
        with open(path, 'rb') as f:
            return pickle.load(f)

    def calculate_dew_point(self, temp, humidity):
        # Magnus formula
        alpha = ((A * temp) / (B + temp)) + math.log(humidity / 100.0)
        return (B * alpha) / (A - alpha)

    def prepare_input(self, weather_points: List[WeatherPoint], model_type: str = "lstm"):
        """
        Prepares input for the model.
        Args:
            weather_points: List of WeatherPoint objects (must be length 24)
            model_type: "lstm" or "transformer" to select correct scaler
        Returns:
            torch.Tensor of shape (1, 24, 11)
        """
        # 1. Convert to DataFrame
        data = []
        for wp in weather_points:
            data.append({
                "timestamp": wp.timestamp,
                "temperature_2m": wp.temperature,
                "relative_humidity_2m": wp.humidity,
                "windspeed_10m": wp.wind_speed
            })
        df = pd.DataFrame(data)

        # 2. Feature Engineering
        # Ensure we evaluate time features in the correct local timezone (IST) for India load models
        if df['timestamp'].dt.tz is not None:
            df['timestamp'] = df['timestamp'].dt.tz_convert('Asia/Kolkata')
            
        # Time features
        df['hour'] = df['timestamp'].dt.hour
        df['day_of_month'] = df['timestamp'].dt.day
        df['dayofweek'] = df['timestamp'].dt.dayofweek
        df['day_of_year'] = df['timestamp'].dt.dayofyear
        df['month'] = df['timestamp'].dt.month
        df['year'] = df['timestamp'].dt.year
        df['week_of_year'] = df['timestamp'].dt.isocalendar().week.astype(int)

        # Dew Point
        df['dew_point_2m'] = df.apply(lambda x: self.calculate_dew_point(x['temperature_2m'], x['relative_humidity_2m']), axis=1)

        # Reorder columns to match training
        df_features = df[self.FEATURES]

        # 3. Scaling
        # The scalers were fitted on [FEATURES + TARGET] (12 cols)
        # We need to pad with a dummy target column to use the scaler
        # then drop it after transforming, or just transform the features if scaler supports it.
        # MinMaxScaler usually expects the same number of features.
        
        vals = df_features.values
        # Add dummy target column (column 12)
        vals_padded = np.hstack([vals, np.zeros((vals.shape[0], 1))])

        scaler = self.scaler_transformer if model_type == "transformer" else self.scaler_lstm
        
        vals_scaled = scaler.transform(vals_padded)
        
        # Drop the dummy target column
        # Input to models is (Batch, Seq, Features=11)
        X = vals_scaled[:, :-1]
        
        # Reshape linearly to (Batch, Seq_len, Features)
        # Assumes batch size 1 and sequence length equal to number of weather points
        X = X.reshape(1, len(weather_points), 11)
        
        return torch.FloatTensor(X)

# Global instance to be initialized in startup event
preprocessor = None
