from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

class WeatherPoint(BaseModel):
    timestamp: datetime = Field(..., description="Timestamp of the observation")
    temperature: float = Field(..., description="Temperature in Celsius (temperature_2m)")
    humidity: float = Field(..., description="Relative Humidity in % (relative_humidity_2m)")
    wind_speed: float = Field(..., description="Wind Speed in km/h (windspeed_10m)")
    
    class Config:
        json_schema_extra = {
            "example": {
                "timestamp": "2024-01-01T10:00:00",
                "temperature": 25.4,
                "humidity": 45.0,
                "wind_speed": 12.5
            }
        }

class PredictionRequest(BaseModel):
    features: List[WeatherPoint] = Field(..., min_items=24, max_items=24, description="List of exactly 24 weather points (last 24 hours)")
    historical_loads: Optional[List[float]] = Field(None, description="Historical load data (Ignored by Digital Twin models)")

class PredictionResponse(BaseModel):
    load: float = Field(..., description="Predicted System Load in MW")
    confidence_interval: Optional[List[float]] = Field(None, description="[Lower, Upper] bound of prediction confidence")
    model_name: str = Field(..., description="Name of the model used")
    execution_time: float = Field(..., description="Inference time in seconds")
