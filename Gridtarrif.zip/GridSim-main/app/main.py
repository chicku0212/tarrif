from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import torch
import time
import os
import asyncio
from typing import Dict, Any
import redis.asyncio as redis
from fastapi_limiter import FastAPILimiter
from fastapi_limiter.depends import RateLimiter
import httpx

from app.schemas import PredictionRequest, PredictionResponse, WeatherPoint
from app.models.lstm import StandardLSTM, DeepLSTM
from app.models.transformer import IndiaTransformer
from app.preprocessing import Preprocessor
from src.config import settings

# Import new routers
from app.routers import websockets, dashboard, analytics, sse
from src.simulator import router as simulator_router, start_simulator_task

# Global variables for models and preprocessor
models: Dict[str, Any] = {}
preprocessor = None
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Feature configuration matching training
INPUT_SIZE = 11  # number of features
D_MODEL = 64
NUM_HEADS = 4
NUM_LAYERS = 2
HIDDEN_SIZE_LSTM = 64
HIDDEN_SIZE_DEEP_LSTM = 64

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    global models, preprocessor
    print(f"Loading models on {device}...")
    
    # Initialize Redis for Rate Limiting
    redis_url = os.environ.get("REDIS_URL")
    
    # Check if a custom username is embedded or implied by upstash
    redis_user = os.environ.get("APP_REDIS__USERNAME", None)
    if not redis_user and "upstash.io" in settings.redis.host:
        # Some upstash setups prefer default, others none based on TLS mode and Redis version
        pass
        
    if redis_url:
        redis_connection = redis.from_url(
            redis_url, 
            encoding="utf-8", 
            decode_responses=True,
            health_check_interval=30,
            socket_keepalive=True
        )
    else:
        redis_connection = redis.Redis(
            host=settings.redis.host, 
            port=settings.redis.port, 
            db=settings.redis.db, 
            password=settings.redis.password, 
            ssl=settings.redis.ssl or "upstash.io" in settings.redis.host,
            ssl_cert_reqs="none",
            encoding="utf-8", 
            decode_responses=True,
            health_check_interval=30,
            socket_keepalive=True
        )
    
    try:
        await FastAPILimiter.init(redis_connection)
        print("✅ Rate Limiter initialized.")
    except Exception as e:
        print(f"⚠️ Failed to connect to Redis for Rate Limiter: {e}")
        # Proceed without crashing the app, but rate limiting will error on hit
    
    # Paths (relative to project root via pathlib)
    import pathlib
    BASE_DIR = pathlib.Path(__file__).resolve().parent.parent
    path_lstm = BASE_DIR / "india_models" / "standard_lstm.pt"
    path_deep_lstm = BASE_DIR / "india_models" / "deep_lstm.pt"
    path_transformer = BASE_DIR / "transformer_model" / "best_transformer.pt"
    scaler_lstm = BASE_DIR / "india_models" / "scaler.pkl"
    scaler_transformer = BASE_DIR / "transformer_model" / "scaler_transformer.pkl"

    print(f"📁 BASE_DIR: {BASE_DIR}")
    print(f"   LSTM exists: {path_lstm.exists()}")
    print(f"   DeepLSTM exists: {path_deep_lstm.exists()}")
    print(f"   Transformer exists: {path_transformer.exists()}")
    print(f"   Scaler LSTM exists: {scaler_lstm.exists()}")
    print(f"   Scaler Transformer exists: {scaler_transformer.exists()}")

    # Load Preprocessor
    try:
        preprocessor = Preprocessor(scaler_lstm, scaler_transformer)
        print("✅ Preprocessor loaded.")
    except Exception as e:
        print(f"❌ Failed to load preprocessor: {e}")
        # Ideally, we should probably fail startup if core components invoke error
        # raise e 

    # Load Models
    if settings.hf_inference_url:
        print(f"Skipping local model loading, using HF Space inference API: {settings.hf_inference_url}")
    else:
        try:
            # Standard LSTM
            if path_lstm.exists():
                model_lstm = StandardLSTM(input_size=INPUT_SIZE, hidden_size=HIDDEN_SIZE_LSTM)
                model_lstm.load_state_dict(torch.load(path_lstm, map_location=device))
                model_lstm.to(device)
                model_lstm.eval()
                models["lstm"] = torch.jit.script(model_lstm) # JIT optimization
                print("✅ Standard LSTM loaded & JIT scripted.")
            else:
                 print(f"⚠️ Standard LSTM model not found at {path_lstm}")

            # Deep LSTM
            if path_deep_lstm.exists():
                model_deep = DeepLSTM(input_size=INPUT_SIZE, hidden_size=HIDDEN_SIZE_DEEP_LSTM)
                model_deep.load_state_dict(torch.load(path_deep_lstm, map_location=device))
                model_deep.to(device)
                model_deep.eval()
                models["deeplstm"] = torch.jit.script(model_deep)
                print("✅ Deep LSTM loaded & JIT scripted.")
            else:
                 print(f"⚠️ Deep LSTM model not found at {path_deep_lstm}")

            # Transformer
            if path_transformer.exists():
                model_trans = IndiaTransformer(input_size=INPUT_SIZE, d_model=D_MODEL, nhead=NUM_HEADS,
                                             num_encoder_layers=NUM_LAYERS, dim_feedforward=128, output_size=1)
                model_trans.load_state_dict(torch.load(path_transformer, map_location=device))
                model_trans.to(device)
                model_trans.eval()
                models["transformer"] = torch.jit.script(model_trans)
                print("✅ Transformer loaded & JIT scripted.")
            else:
                 print(f"⚠️ Transformer model not found at {path_transformer}")
            
        except Exception as e:
            print(f"❌ Failed to load models: {e}")
            # raise e

    # Warmup
    if models:
        print("🔥 Warming up models...")
        dummy_input = torch.randn(1, 24, 11).to(device)
        with torch.no_grad():
            for name, model in models.items():
                try:
                    model(dummy_input)
                    print(f"   {name} warmed up.")
                except Exception as e:
                    print(f"   ❌ {name} warmup failed: {e}")
    
    # Start Background Task
    task = asyncio.create_task(generate_forecast_background_task())
    
    # Start Simulator
    await start_simulator_task()
    
    # Initialize HTTPX client for HuggingFace if URL is provided
    if settings.hf_inference_url:
        app.state.hf_client = httpx.AsyncClient()
        app.state.hf_base_url = settings.hf_inference_url.rstrip('/')
        print(f"✅ HTTPX client initialized for HuggingFace space: {settings.hf_inference_url}")
    else:
        app.state.hf_client = None
        app.state.hf_base_url = None

    # Attach to app state for analytics router
    app.state.models = models
    app.state.preprocessor = preprocessor

    yield


    # Shutdown
    task.cancel() # Stop the background task
    models.clear()
    await redis_connection.close()
    if app.state.hf_client:
        await app.state.hf_client.aclose()
    print("Models unloaded & Redis connection closed.")

async def generate_forecast_background_task():
    """
    Disabled via User Request: Mock 2 autoregressive fallback.
    """
    import asyncio
    while True:
        await asyncio.sleep(86400)
    import pandas as pd
    import numpy as np
    import json
    
    while True:
        try:
            await asyncio.sleep(10) # Initial delay to allow startup
            
            print("🔮 Starting scheduled 24h forecast generation...")
            
            # 1. Connect to DB to get last 24h data
            import os
            dsn = os.environ.get("DATABASE_URL", f"postgresql://{settings.database.user}:{settings.database.password}@{settings.database.host}:{settings.database.port}/{settings.database.name}")
            try:
                conn = await asyncpg.connect(dsn)
            except Exception as e:
                print(f"⚠️ Failed to connect to DB for forecast: {e}")
                await asyncio.sleep(60)
                continue
            
            try:
                # Fetch last 24 records
                rows = await conn.fetch("""
                    SELECT timestamp, load, temperature_2m, relative_humidity_2m, windspeed_10m, dew_point_2m
                    FROM digital_twin_states
                    ORDER BY timestamp DESC
                    LIMIT 24
                """)
                
                if len(rows) < 24:
                    print(f"⚠️ Not enough data for forecast (Got {len(rows)}, need 24). Skipping.")
                    await asyncio.sleep(300) # Retry sooner if no data
                    continue
                
                # Reverse to chronological order (oldest to newest)
                rows = rows[::-1]
                
                # 2. Preprocess & Inference
                # Iterate through all loaded models
                for model_name, model in models.items():
                    if preprocessor:
                        try:
                            # Select appropriate scaler type
                            scaler_type = "transformer" if model_name == "transformer" else "lstm"
                            
                            # Prepare features
                            # We need to construct WeatherPoints
                            
                            weather_points = []
                            for row in rows:
                                weather_points.append(WeatherPoint(
                                     timestamp=row['timestamp'], 
                                     temperature=row['temperature_2m'],
                                     humidity=row['relative_humidity_2m'],
                                     wind_speed=row['windspeed_10m']
                                ))
                            
                            # Prepare input
                            input_tensor = preprocessor.prepare_input(weather_points, model_type=scaler_type).to(device)
                            
                            # Inference
                            with torch.no_grad():
                                # Mocking 24h profile based on single prediction + daily seasonality
                                base_load = model(input_tensor).item()
                                
                                # Inverse transform
                                dummy_row = np.zeros((1, 12))
                                dummy_row[0, -1] = base_load
                                
                                scaler = preprocessor.scaler_transformer if scaler_type == "transformer" else preprocessor.scaler_lstm
                                base_mw = scaler.inverse_transform(dummy_row)[0, -1]
                                
                                # Create a synthetic 24h curve rooted at this prediction
                                forecast_values = []
                                import math
                                for i in range(24):
                                    # Simple sine wave pattern for daily cycle
                                    factor = 1.0 + 0.1 * math.sin((i / 24) * 2 * math.pi) 
                                    forecast_values.append(base_mw * factor)

                                # Cache to Redis with model-specific key
                                import os
                                redis_url = os.environ.get("REDIS_URL")
                                if redis_url:
                                    redis_client = redis.from_url(redis_url, decode_responses=True)
                                else:
                                    redis_client = redis.Redis(
                                        host=settings.redis.host, port=settings.redis.port, 
                                        db=settings.redis.db, password=settings.redis.password,
                                        decode_responses=True
                                    )
                                await redis_client.set(key, json.dumps(forecast_values), ex=3600)
                                await redis_client.close()
                                
                                print(f"✅ Generated and cached 24h forecast for {model_name} (Base: {base_mw:.2f} MW)")

                        except Exception as e:
                            print(f"❌ Forecast inference failed for {model_name}: {e}")

            finally:
                await conn.close()
                
            # Sleep for 1 hour
            await asyncio.sleep(3600) 
            
        except asyncio.CancelledError:
            break
        except Exception as e:
            print(f"❌ Background task error: {e}")
            await asyncio.sleep(60) # Retry on error

app = FastAPI(title="India Load Forecasting Digital Twin", lifespan=lifespan)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_url, "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include Routers
app.include_router(websockets.router, tags=["Real-time"])
app.include_router(dashboard.router, tags=["Dashboard"], dependencies=[Depends(RateLimiter(times=60, seconds=60))])
app.include_router(analytics.router, tags=["Analytics"], dependencies=[Depends(RateLimiter(times=20, seconds=60))])
app.include_router(sse.router, tags=["Real-time"])
app.include_router(simulator_router, tags=["Simulation"])
from app.routers import simulation
app.include_router(simulation.router, prefix="/simulation", tags=["Simulation Engine"])

async def get_prediction(model_name: str, request: PredictionRequest):
    start_time = time.time()
    
    # Try HuggingFace Inference API if available
    if getattr(app.state, 'hf_client', None) is not None:
        try:
            url = f"{app.state.hf_base_url}/predict/{model_name}"
            headers = {}
            if settings.hf_token:
                headers["Authorization"] = f"Bearer {settings.hf_token}"
            
            prediction_payload = request.model_dump()
            response = await app.state.hf_client.post(url, json=prediction_payload, headers=headers, timeout=10.0)
            response.raise_for_status()
            data = response.json()
            
            return PredictionResponse(
                load=data.get("load", 0.0),
                model_name=model_name,
                execution_time=time.time() - start_time,
                confidence_interval=data.get("confidence_interval")
            )
        except Exception as e:
            print(f"⚠️ HF Inference failed for {model_name}, falling back to local: {e}")

    if model_name not in models:
        raise HTTPException(status_code=404, detail="Model not found")
        
    # Preprocess
    # Use 'transformer' scaler for transformer model, 'lstm' for others
    scaler_type = "transformer" if model_name == "transformer" else "lstm"
    
    try:
        input_tensor = preprocessor.prepare_input(request.features, model_type=scaler_type).to(device)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Preprocessing error: {str(e)}")

    # Inference
    with torch.no_grad():
        prediction_scaled = models[model_name](input_tensor).item()

    # Inverse Transform
    # We need to inverse transform just the target.
    # The scalers were fitted on 12 cols (11 features + 1 target).
    # We construct a dummy row with the prediction in the target column (last col)
    # and inverse transform.
    dummy_row = np.zeros((1, 12))
    dummy_row[0, -1] = prediction_scaled
    
    scaler = preprocessor.scaler_transformer if scaler_type == "transformer" else preprocessor.scaler_lstm
    prediction_mw = scaler.inverse_transform(dummy_row)[0, -1]
    
    execution_time = time.time() - start_time
    
    return PredictionResponse(
        load=prediction_mw,
        model_name=model_name,
        execution_time=execution_time,
        confidence_interval=None # Not implemented yet
    )

import numpy as np

@app.post("/predict/lstm", response_model=PredictionResponse, dependencies=[Depends(RateLimiter(times=100, seconds=60))])
async def predict_lstm(request: PredictionRequest):
    return await get_prediction("lstm", request)

@app.post("/predict/deeplstm", response_model=PredictionResponse, dependencies=[Depends(RateLimiter(times=100, seconds=60))])
async def predict_deeplstm(request: PredictionRequest):
    return await get_prediction("deeplstm", request)

@app.post("/predict/transformer", response_model=PredictionResponse, dependencies=[Depends(RateLimiter(times=100, seconds=60))])
async def predict_transformer(request: PredictionRequest):
    return await get_prediction("transformer", request)

@app.get("/model/info")
async def model_info():
    return {
        "models": list(models.keys()),
        "features": preprocessor.FEATURES if preprocessor else [],
        "device": str(device),
        "description": "Digital Twin for India Load Forecasting using LSTM and Transformer models. Expects 24h weather sequence."
    }

@app.get("/health")
async def health():
    return {"status": "ok", "services": ["api", "redis", "database"]}

if __name__ == "__main__":
    import uvicorn
    # monitoring and reloading enabled
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
