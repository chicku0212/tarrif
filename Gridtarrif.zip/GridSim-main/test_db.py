import asyncio
import asyncpg

async def main():
    conn = await asyncpg.connect('postgresql://postgres:1111@localhost/postgres')
    rows = await conn.fetch("""
        SELECT timestamp, load
        FROM digital_twin_states
        WHERE load IS NOT NULL
        ORDER BY timestamp DESC
        LIMIT 48
    """)
    print("Fetched", len(rows), "rows")
    if rows:
        print("Last row load:", rows[0]['load'], "timestamp:", rows[0]['timestamp'])
        print("Oldest row load:", rows[-1]['load'], "timestamp:", rows[-1]['timestamp'])
        for r in rows[::-1]:
            print(r['timestamp'], r['load'])

asyncio.run(main())
