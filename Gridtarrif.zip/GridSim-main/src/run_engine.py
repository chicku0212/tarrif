
import asyncio
import json
import logging
import websockets
from src.state_manager import StateManager
from src.config import settings

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("DigitalTwinEngine")

async def run_engine():
    """
    Main loop for the Digital Twin Engine.
    Connects to the Simulator WebSocket and processes incoming data.
    """
    state_manager = StateManager()
    await state_manager.connect()
    
    # Ensure we use localhost for client connection if host is 0.0.0.0
    host = settings.api.host
    if host == "0.0.0.0":
        host = "127.0.0.1"
        
    uri = f"ws://{host}:{settings.api.port}/ws/simulation"
    
    retry_delay = 5
    while True:
        try:
            logger.info(f"Connecting to Simulator at {uri}...")
            async with websockets.connect(uri) as websocket:
                logger.info("Connected to Simulator.")
                
                while True:
                    message = await websocket.recv()
                    data = json.loads(message)
                    
                    # Update State
                    await state_manager.update_state(data)
                    
                    # Periodically check for staleness (every update might be too frequent, 
                    # but here we do it for simplicity or use a separate task)
                    # asyncio.create_task(state_manager.check_staleness())
                    
        except (websockets.exceptions.ConnectionClosed, ConnectionRefusedError) as e:
            logger.warning(f"Connection lost: {e}. Retrying in {retry_delay} seconds...")
            await asyncio.sleep(retry_delay)
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            await asyncio.sleep(retry_delay)

if __name__ == "__main__":
    try:
        asyncio.run(run_engine())
    except KeyboardInterrupt:
        logger.info("Engine stopped by user.")
