import asyncio
import websockets
import json
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(message)s")
logger = logging.getLogger("DigitalTwinClient")

async def listen():
    uri = "ws://localhost:8000/ws/simulation"
    async with websockets.connect(uri) as websocket:
        logger.info(f"Connected to {uri}")
        try:
            while True:
                message = await websocket.recv()
                data = json.loads(message)
                logger.info(f"Received Simulation Data: Datetime: {data.get('datetime')}, Load: {data.get('load'):.2f}")
        except websockets.exceptions.ConnectionClosed:
            logger.info("Connection closed")

if __name__ == "__main__":
    try:
        asyncio.run(listen())
    except KeyboardInterrupt:
        logger.info("Client stopped by user")
