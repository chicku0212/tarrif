from fastapi import FastAPI, HTTPException
from src.api.schema import TariffInput, PredictionOutput, ModelInfo
from src.models.lstm import IndiaLSTM
from src.models.transformer import IndiaTransformer
from src.preprocessing.pipeline import TariffPreprocessor
from src.api.simulation import router as simulation_router
import torch
import os
import pandas as pd
import time
from typing import List

app = FastAPI(title="India Load Tariff Prediction API")

app.include_router(simulation_router)

# Global variables for models and preprocessors
lstm_model = None
transformer_model = None
lstm_preprocessor = None
transformer_preprocessor = None

MODEL_DIR = "models"
LSTM_PATH = os.path.join(MODEL_DIR, "lstm_model.pt")
TRANSFORMER_PATH = os.path.join(MODEL_DIR, "transformer_model.pt")
LSTM_SCALER_PATH = os.path.join(MODEL_DIR, "scaler_lstm.pkl")
TRANSFORMER_SCALER_PATH = os.path.join(MODEL_DIR, "scaler_transformer.pkl")

@app.on_event("startup")
async def startup_event():
    global lstm_model, transformer_model, lstm_preprocessor, transformer_preprocessor
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Load Preprocessors
    if os.path.exists(LSTM_SCALER_PATH):
        lstm_preprocessor = TariffPreprocessor(LSTM_SCALER_PATH)
    
    if os.path.exists(TRANSFORMER_SCALER_PATH):
        transformer_preprocessor = TariffPreprocessor(TRANSFORMER_SCALER_PATH)
        
    # Load LSTM Model
    # Input size 11, hidden 50, layers 1, output 1 (based on training script)
    if os.path.exists(LSTM_PATH):
        lstm_model = IndiaLSTM(input_size=11, hidden_size=50, num_layers=1, output_size=1)
        lstm_model.load_state_dict(torch.load(LSTM_PATH, map_location=device))
        lstm_model.to(device)
        lstm_model.eval()
        # Optimize with JIT
        try:
             dummy_input = torch.randn(1, 1, 11).to(device)
             lstm_model = torch.jit.trace(lstm_model, dummy_input)
             print("LSTM model JIT traced successfully.")
        except Exception as e:
             print(f"Failed to JIT trace LSTM model: {e}")

    # Load Transformer Model
    # input_size=11, d_model=64, nhead=4, num_encoder_layers=1, dim_feedforward=128, output_size=1
    if os.path.exists(TRANSFORMER_PATH):
        transformer_model = IndiaTransformer(input_size=11, d_model=64, nhead=4, num_encoder_layers=1, dim_feedforward=128, output_size=1)
        transformer_model.load_state_dict(torch.load(TRANSFORMER_PATH, map_location=device))
        transformer_model.to(device)
        transformer_model.eval()
        # Optimize with JIT
        try:
             dummy_input = torch.randn(1, 1, 11).to(device)
             transformer_model = torch.jit.trace(transformer_model, dummy_input)
             print("Transformer model JIT traced successfully.")
        except Exception as e:
             print(f"Failed to JIT trace Transformer model: {e}")

    # Warmup
    print("Warming up models...")
    dummy_data = pd.DataFrame([{
        "hour": 0, "day_of_month": 1, "dayofweek": 0, "day_of_year": 1, "month": 1, "year": 2024,
        "week_of_year": 1, "temperature_2m": 25.0, "relative_humidity_2m": 50.0, "windspeed_10m": 5.0, "dew_point_2m": 15.0
    }])
    
    if lstm_model and lstm_preprocessor:
        _predict(lstm_model, lstm_preprocessor, dummy_data, device)
        
    if transformer_model and transformer_preprocessor:
        _predict(transformer_model, transformer_preprocessor, dummy_data, device)
    print("Warmup complete.")

def _predict(model, preprocessor, data: pd.DataFrame, device):
    tensor_input = preprocessor.preprocess(data).to(device)
    with torch.no_grad():
        output = model(tensor_input)
    prediction = preprocessor.inverse_transform(output)
    return prediction

@app.post("/predict/lstm", response_model=List[PredictionOutput])
async def predict_lstm(inputs: List[TariffInput]):
    if not lstm_model or not lstm_preprocessor:
        raise HTTPException(status_code=503, detail="LSTM model not available")
        
    start_time = time.time()
    df = pd.DataFrame([i.dict() for i in inputs])
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    predictions = _predict(lstm_model, lstm_preprocessor, df, device)
    
    end_time = time.time()
    inference_time = (end_time - start_time) * 1000
    
    results = []
    for pred in predictions:
        results.append(PredictionOutput(load=float(pred), model_name="LSTM", inference_time_ms=inference_time/len(predictions)))
    
    return results

@app.post("/predict/transformer", response_model=List[PredictionOutput])
async def predict_transformer(inputs: List[TariffInput]):
    if not transformer_model or not transformer_preprocessor:
        raise HTTPException(status_code=503, detail="Transformer model not available")
        
    start_time = time.time()
    df = pd.DataFrame([i.dict() for i in inputs])
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    predictions = _predict(transformer_model, transformer_preprocessor, df, device)
    
    end_time = time.time()
    inference_time = (end_time - start_time) * 1000
    
    results = []
    for pred in predictions:
        results.append(PredictionOutput(load=float(pred), model_name="Transformer", inference_time_ms=inference_time/len(predictions)))
    
    return results

@app.get("/model/info", response_model=List[ModelInfo])
async def model_info():
    infos = []
    if lstm_model:
        infos.append(ModelInfo(name="IndiaLSTM", type="LSTM", input_features=lstm_preprocessor.features, output_dim=1))
    if transformer_model:
        infos.append(ModelInfo(name="IndiaTransformer", type="Transformer", input_features=transformer_preprocessor.features, output_dim=1))
    return infos
