from pydantic import BaseModel, Field
from typing import List, Optional

class TariffInput(BaseModel):
    hour: int = Field(..., description="Hour of the day (0-23)")
    day_of_month: int = Field(..., description="Day of the month (1-31)")
    dayofweek: int = Field(..., description="Day of the week (0-6)")
    day_of_year: int = Field(..., description="Day of the year (1-366)")
    month: int = Field(..., description="Month (1-12)")
    year: int = Field(..., description="Year")
    week_of_year: int = Field(..., description="Week of the year (1-53)")
    temperature_2m: float = Field(..., description="Temperature at 2m")
    relative_humidity_2m: float = Field(..., description="Relative humidity at 2m")
    windspeed_10m: float = Field(..., description="Wind speed at 10m")
    dew_point_2m: float = Field(..., description="Dew point at 2m")

class PredictionOutput(BaseModel):
    load: float
    model_name: str
    inference_time_ms: Optional[float] = None

class ModelInfo(BaseModel):
    name: str
    type: str
    input_features: List[str]
    output_dim: int
