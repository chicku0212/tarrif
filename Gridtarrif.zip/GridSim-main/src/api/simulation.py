from fastapi import APIRouter, HTTPException, BackgroundTasks, Query
from typing import List, Optional
import pandas as pd
from datetime import datetime
import uuid
import json
from fastapi.responses import Response

from src.simulation_engine import SimulationEngine, SimulationConfig, SimulationResult
from src.model_executor import ModelExecutor
from src.state_manager import StateManager
from src.api.schema import PredictionOutput
from src.config import settings

router = APIRouter(prefix="/simulation", tags=["Simulation"])

# Global Instances (initialized on startup in main.py usually, but for now lazy or local)
# Ideally main.py should pass these, but fastAPI DI is cleaner.
# We will use a singleton pattern for ModelExecutor to avoid reloading.

_model_executor = None

def get_model_executor():
    global _model_executor
    if _model_executor is None:
        _model_executor = ModelExecutor()
    return _model_executor

# In-memory cache for demo purposes (should be Redis in prod)
# We will try to use Redis if StateManager has it, but for simplicity here a dict.
# Actually, the user asked for "Simulation Cache".
SIMULATION_CACHE = {}

@router.post("/run", response_model=SimulationResult)
async def run_simulation(config: SimulationConfig):
    """
    Run a simulation based on the provided configuration.
    """
    executor = get_model_executor()
    engine = SimulationEngine(executor)
    
    # 1. Get Initial State / Weather Forecast
    # We need weather data for the next N hours from config.start_time
    # In a real app, we'd query a weather API or DB.
    # For this twin, we can fetch from our historical/simulated DB.
    
    # Using StateManager to get DB connection would be good
    state_manager = StateManager()
    await state_manager.connect()
    
    # Fetch forecast data from DB
    # We need a method to get range of data. Re-using API logic or direct DB query.
    # We will use a direct query for efficiency.
    
    query = """
        SELECT timestamp, temperature_2m, relative_humidity_2m, windspeed_10m, dew_point_2m,
               region
        FROM digital_twin_states 
        WHERE timestamp >= $1
        ORDER BY timestamp ASC
        LIMIT $2
    """
    # Fix: Use stored weather data. If simulation is in future where no data exists, 
    # we might need to fallback to average or last known.
    # For this exercise, we assume data exists (historical replay).
    
    # However, if start_time is "now" (real-time), we might not have future rows in DB unless proper forecast.
    # We will fetch whatever is available.
    
    rows = []
    if state_manager.db_pool:
        async with state_manager.db_pool.acquire() as conn:
            records = await conn.fetch(query, config.start_time, config.hours)
            for r in records:
                rows.append(dict(r))
    
    if not rows:
        # Fallback for testing/empty DB: generate dummy weather
        current = config.start_time
        for _ in range(config.hours):
            rows.append({
                "timestamp": current,
                "temperature_2m": 25.0,
                "relative_humidity_2m": 50.0,
                "windspeed_10m": 10.0,
                "dew_point_2m": 15.0,
                "region": "India"
            })
            current += pd.Timedelta(hours=1)
            
    df_initial = pd.DataFrame(rows)
    
    # Ensure all time features needed by model are present
    if 'timestamp' in df_initial.columns:
         # Make sure timestamp is datetime
         df_initial['timestamp'] = pd.to_datetime(df_initial['timestamp'])
         dt = df_initial['timestamp'].dt
         df_initial['hour'] = dt.hour
         df_initial['day_of_month'] = dt.day
         df_initial['dayofweek'] = dt.dayofweek
         df_initial['day_of_year'] = dt.dayofyear
         df_initial['month'] = dt.month
         df_initial['year'] = dt.year
         df_initial['week_of_year'] = dt.isocalendar().week.astype(int)
    
    # Run
    try:
        result = await engine.run(config, df_initial)
        # Cache
        SIMULATION_CACHE[result.simulation_id] = result
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/results/{sim_id}", response_model=SimulationResult)
async def get_results(sim_id: str):
    if sim_id not in SIMULATION_CACHE:
        raise HTTPException(status_code=404, detail="Simulation not found")
    return SIMULATION_CACHE[sim_id]

@router.get("/compare")
async def compare_simulations(sim_ids: List[str] = Query(...)):
    """
    Compare multiple simulations. Returns a combined dataset for plotting.
    """
    combined = []
    for sid in sim_ids:
        if sid in SIMULATION_CACHE:
            res = SIMULATION_CACHE[sid]
            for row in res.results:
                entry = row.copy()
                entry['simulation_id'] = sid
                # Add scenario label for easier plotting
                # e.g. "Temp +5"
                label = "Baseline"
                if res.config.scenarios:
                    s = res.config.scenarios[0] # taking first for name
                    label = f"{s.type} {s.magnitude}"
                entry['label'] = label
                combined.append(entry)
                
    return combined

@router.get("/export/{sim_id}")
async def export_results(sim_id: str, format: str = "csv"):
    if sim_id not in SIMULATION_CACHE:
        raise HTTPException(status_code=404, detail="Simulation not found")
    
    result = SIMULATION_CACHE[sim_id]
    df = pd.DataFrame(result.results)
    
    if format.lower() == 'csv':
        csv = df.to_csv(index=False)
        return Response(content=csv, media_type="text/csv", headers={"Content-Disposition": f"attachment; filename=simulation_{sim_id}.csv"})
    elif format.lower() == 'json':
        return Response(content=df.to_json(orient='records'), media_type="application/json")
    else:
        raise HTTPException(status_code=400, detail="Unsupported format. Use csv or json.")
