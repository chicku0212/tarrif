import os
from typing import Optional, Dict, Any, Tuple, Type, List
from pydantic import BaseModel, Field, ValidationError, PostgresDsn, RedisDsn
from pydantic_settings import BaseSettings, SettingsConfigDict, PydanticBaseSettingsSource, YamlConfigSettingsSource

class DatabaseConfig(BaseModel):
    host: str = "localhost"
    port: int = 5432
    name: str = "postgres"
    user: str = "postgres"
    password: str = Field(default="password", description="Database password")

class RedisConfig(BaseModel):
    host: str = "localhost"
    port: int = 6379
    db: int = 0
    username: Optional[str] = None
    password: Optional[str] = None
    ssl: bool = False
    ssl_cert_reqs: str = "none"

class SimulatorConfig(BaseModel):
    speed_multiplier: float = 1.0
    default_speed: float = 1.0
    file_path: str = "india_complete_load_2001_2025.csv"
    tick_seconds: float = 900.0  # Default 15 mins. Used in run_simulation

class APIConfig(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8000
    reload: bool = False

class RegionConfig(BaseModel):
    default_name: str = "India"
    currency: str = "INR"

class AlertConfig(BaseModel):
    load_threshold_mw: float = 50000.0
    temperature_threshold_c: float = 45.0

class AppConfig(BaseSettings):
    env: str = Field(default="dev", alias="ENV")
    frontend_url: str = Field(default="http://localhost:5173", description="Frontend URL for CORS")
    hf_inference_url: Optional[str] = Field(default=None, description="HuggingFace Space URL")
    hf_token: Optional[str] = Field(default=None, description="HuggingFace Token")
    database: DatabaseConfig = DatabaseConfig()
    redis: RedisConfig = RedisConfig()
    simulator: SimulatorConfig = SimulatorConfig()
    simulator_tick_seconds: float = Field(default=900.0, description="Tick every APP_SIMULATOR_TICK_SECONDS seconds (default: 900 = 15 min)")
    api: APIConfig = APIConfig()
    region: RegionConfig = RegionConfig()
    alerts: AlertConfig = AlertConfig()

    model_config = SettingsConfigDict(
        env_prefix='APP_',
        env_nested_delimiter='__',
        env_file='.env',
        env_file_encoding='utf-8',
        case_sensitive=False,
        extra='ignore'
    )

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: Type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> Tuple[PydanticBaseSettingsSource, ...]:
        
        env = os.getenv("APP_ENV", os.getenv("ENV", "dev"))
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        config_dir = os.path.join(base_dir, "config")
        
        yaml_files: List[str] = [
            os.path.join(config_dir, "base.yaml"),
            os.path.join(config_dir, f"{env}.yaml")
        ]
        
        # Determine strict source order: 
        # 1. Defaults (Implicit)
        # 2. YAML Files (Base + Env specific)
        # 3. .env file
        # 4. Environment Variables
        # 5. Init (Runtime override)
        
        return (
            init_settings,
            env_settings,
            dotenv_settings,
            YamlConfigSettingsSource(settings_cls, yaml_file=yaml_files),
        )

    @classmethod
    def load_config(cls):
        """
        Loads configuration using Pydantic Settings.
        ENV is determined from environment variable or default 'dev'.
        """
        return cls()

# Global settings instance
try:
    settings = AppConfig.load_config()
except ValidationError as e:
    print(f"Configuration Validation Error: {e}")
    raise
except Exception as e:
    print(f"Configuration Loading Error: {e}")
    raise
