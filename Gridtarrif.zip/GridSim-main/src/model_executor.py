from typing import Dict, Any, Optional
import torch
import pandas as pd
import numpy as np
import os
import logging
from src.models.lstm import IndiaLSTM
from src.models.transformer import IndiaTransformer
from src.preprocessing.pipeline import TariffPreprocessor
from src.config import settings

logger = logging.getLogger(__name__)

class ModelExecutor:
    def __init__(self):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.models = {}
        self.preprocessors = {}
        self._load_models()

    def _load_models(self):
        # Paths
        MODEL_DIR = "india_models"
        TRANSFORMER_DIR = "transformer_model"
        
        LSTM_PATH = os.path.join(MODEL_DIR, "standard_lstm.pt")
        DEEP_LSTM_PATH = os.path.join(MODEL_DIR, "deep_lstm.pt") 
        TRANSFORMER_PATH = os.path.join(TRANSFORMER_DIR, "best_transformer.pt")
        
        LSTM_SCALER_PATH = os.path.join(MODEL_DIR, "scaler.pkl")
        TRANSFORMER_SCALER_PATH = os.path.join(TRANSFORMER_DIR, "scaler_transformer.pkl")
        
        # Load Preprocessors
        if os.path.exists(LSTM_SCALER_PATH):
            self.preprocessors['LSTM'] = TariffPreprocessor(LSTM_SCALER_PATH)
            # Re-use LSTM scaler for DeepLSTM
            self.preprocessors['DeepLSTM'] = self.preprocessors['LSTM'] 
            
        if os.path.exists(TRANSFORMER_SCALER_PATH):
            self.preprocessors['Transformer'] = TariffPreprocessor(TRANSFORMER_SCALER_PATH)
        # Fallback: use generic scaler for transformer if specific not found but generic exists?
        # Actually logic in main.py used specific scalers. checking transformer dir next.

        # Load LSTM
        if os.path.exists(LSTM_PATH):
            try:
                # Based on checkpoint analysis: hidden_size=64
                model = IndiaLSTM(input_size=11, hidden_size=64, num_layers=1, output_size=1)
                model.load_state_dict(torch.load(LSTM_PATH, map_location=self.device))
                model.to(self.device)
                model.eval()
                self.models['LSTM'] = model
                logger.info("LSTM model loaded.")
            except Exception as e:
                logger.error(f"Error loading LSTM: {e}")

        # Load Deep LSTM
        if os.path.exists(DEEP_LSTM_PATH):
             try:
                # Based on checkpoint analysis: hidden_size=64, num_layers=2
                model = IndiaLSTM(input_size=11, hidden_size=64, num_layers=2, output_size=1)
                model.load_state_dict(torch.load(DEEP_LSTM_PATH, map_location=self.device))
                model.to(self.device)
                model.eval()
                self.models['DeepLSTM'] = model
                logger.info("DeepLSTM model loaded.")
             except Exception as e:
                logger.error(f"Error loading DeepLSTM: {e}")
        else:
             logger.warning("DeepLSTM model file not found. Simulation for DeepLSTM will fail or fallback.")

        # Load Transformer
        if os.path.exists(TRANSFORMER_PATH):
            try:
                # Based on checkpoint analysis: num_encoder_layers=2
                model = IndiaTransformer(input_size=11, d_model=64, nhead=4, num_encoder_layers=2, dim_feedforward=128, output_size=1)
                model.load_state_dict(torch.load(TRANSFORMER_PATH, map_location=self.device))
                model.to(self.device)
                model.eval()
                self.models['Transformer'] = model
                logger.info("Transformer model loaded.")
            except Exception as e:
                logger.error(f"Error loading Transformer: {e}")

    async def predict_batch(self, df: pd.DataFrame, model_type: str) -> np.ndarray:
        """
        Run inference on a batch of data (DataFrame) for the specified model.
        Returns numpy array of predictions.
        """
        if model_type not in self.models:
            raise ValueError(f"Model {model_type} not loaded or unavailable.")
        
        model = self.models[model_type]
        # Use Transformer preprocessor for Transformer, else LSTM (for LSTM/DeepLSTM)
        # Mapping logic:
        # LSTM -> LSTM scaler
        # DeepLSTM -> LSTM scaler (assumed compatible features)
        # Transformer -> Transformer scaler
        
        prep_key = 'Transformer' if model_type == 'Transformer' else 'LSTM'
        if prep_key not in self.preprocessors:
             raise ValueError(f"Preprocessor for {model_type} not available.")
             
        preprocessor = self.preprocessors[prep_key]
        
        # Preprocess
        # The preprocessor expects a DataFrame and returns (batch, 1, features)
        # Here we want (batch, 1, features) where batch = number of hours (rows)
        # preprocess() does exactly this: takes N rows, returns [N, 1, 11]
        
        try:
            tensor_input = preprocessor.preprocess(df).to(self.device)
            
            with torch.no_grad():
                output = model(tensor_input) # Output shape: [N, 1] usually (since seq_len=1 for many-to-one or similiar)
                
            # Inverse transform
            predictions = preprocessor.inverse_transform(output)
            
            return predictions
        except Exception as e:
            logger.error(f"Prediction error for {model_type}: {e}")
            raise
