from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel
import psycopg2
from psycopg2.extras import RealDictCursor
import os
from dotenv import load_dotenv
from typing import List, Optional
from datetime import datetime

load_dotenv()

app = FastAPI(title="IndiaLoadTariff API", description="API for historical energy load data")

from src.config import settings

def get_db_connection():
    try:
        conn = psycopg2.connect(
            host=settings.database.host,
            port=settings.database.port,
            dbname=settings.database.name,
            user=settings.database.user,
            password=settings.database.password
        )
        return conn
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database connection failed: {e}")

class EnergyData(BaseModel):
    timestamp: datetime
    region: str
    load_mw: float
    temperature: Optional[float]
    humidity: Optional[float]
    wind_speed: Optional[float]
    precipitation: Optional[float]

@app.get("/historical-data", response_model=List[EnergyData])
def get_historical_data(
    start_date: datetime,
    end_date: datetime,
    region: Optional[str] = Query(None, description="Region to filter by, e.g., 'India'")
):
    """
    Retrieve historical load and weather data filtered by date range and optional region.
    """
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)
    
    query = """
        SELECT timestamp, region, load_mw, temperature, humidity, wind_speed, precipitation
        FROM energy_data
        WHERE timestamp BETWEEN %s AND %s
    """
    params = [start_date, end_date]
    
    if region:
        query += " AND region = %s"
        params.append(region)
    
    query += " ORDER BY timestamp ASC"
    
    try:
        cursor.execute(query, tuple(params))
        results = cursor.fetchall()
        return results
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Query failed: {e}")
    finally:
        cursor.close()
        conn.close()

@app.get("/health")
def health_check():
    return {"status": "ok"}
