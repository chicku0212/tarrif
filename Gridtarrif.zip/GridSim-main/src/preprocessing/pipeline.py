import pandas as pd
import numpy as np
import pickle
import torch
import os

class TariffPreprocessor:
    def __init__(self, scaler_path: str):
        if not os.path.exists(scaler_path):
             raise FileNotFoundError(f"Scaler not found at {scaler_path}")
        with open(scaler_path, 'rb') as f:
            self.scaler = pickle.load(f)
        
        # Features used in the model
        self.features = ["hour", "day_of_month", "dayofweek", "day_of_year", "month", "year", "week_of_year", "temperature_2m", "relative_humidity_2m", "windspeed_10m", "dew_point_2m"]

    def preprocess(self, data: pd.DataFrame) -> torch.Tensor:
        """
        Preprocesses input dataframe for model inference.
        """
        # Check if all features exist
        missing_features = [f for f in self.features if f not in data.columns]
        if missing_features:
            raise ValueError(f"Missing features: {missing_features}")
            
        data_sorted = data[self.features].copy()
        
        # Add dummy load column for scaler (as it expects 12 features)
        data_sorted['load'] = 0.0
        
        # Scale
        # Note: MinMaxScaler expects 2D array
        scaled_data = self.scaler.transform(data_sorted.values)
        
        # Extract features components (first 11 columns)
        X = scaled_data[:, :-1]
        
        # Reshape for model (batch, seq_len, features) -> (batch, 1, 11)
        X = X.reshape(X.shape[0], 1, len(self.features))
        
        return torch.FloatTensor(X)

    def inverse_transform(self, prediction: torch.Tensor) -> np.ndarray:
        """
        Inverse transforms the predicted load values.
        """
        if isinstance(prediction, torch.Tensor):
            pred_val = prediction.cpu().detach().numpy().flatten()
        else:
            pred_val = prediction.flatten()
            
        # Manually inverse transform only the target column
        # scaler.data_min_ stores min per feature
        # scaler.data_range_ stores (max - min) per feature
        # The target 'load' is the last feature (index -1)
        
        min_val = self.scaler.data_min_[-1]
        range_val = self.scaler.data_range_[-1]
        
        original_target = pred_val * range_val + min_val
        return original_target
