import pandas as pd
import numpy as np
from typing import List, Dict, Any

class DataValidator:
    def __init__(self):
        pass

    def check_missing_values(self, df: pd.DataFrame) -> Dict[str, int]:
        """
        Checks for missing values in the DataFrame.
        Returns a dictionary with column names and the count of missing values.
        """
        missing_counts = df.isnull().sum()
        return missing_counts[missing_counts > 0].to_dict()

    def check_outliers(self, df: pd.DataFrame, columns: List[str], threshold: float = 3.0) -> Dict[str, int]:
        """
        Checks for outliers in specified numeric columns using z-score.
        Returns a dictionary with column names and the count of outliers.
        """
        outliers = {}
        for col in columns:
            if col in df.columns:
                # Calculate z-score
                mean = df[col].mean()
                std = df[col].std()
                if std == 0:
                    continue
                z_scores = (df[col] - mean) / std
                outlier_count = (np.abs(z_scores) > threshold).sum()
                if outlier_count > 0:
                    outliers[col] = int(outlier_count)
        return outliers

    def check_continuity(self, df: pd.DataFrame, timestamp_col: str = 'timestamp', freq: str = 'h') -> List[pd.Timestamp]:
        """
        Checks for missing timestamps in the time series.
        Assumes the DataFrame is sorted by timestamp.
        Returns a list of missing timestamps.
        """
        if timestamp_col not in df.columns:
            raise ValueError(f"Timestamp column '{timestamp_col}' not found in DataFrame.")

        # Ensure timestamp column is datetime type
        if not pd.api.types.is_datetime64_any_dtype(df[timestamp_col]):
             df[timestamp_col] = pd.to_datetime(df[timestamp_col])

        min_time = df[timestamp_col].min()
        max_time = df[timestamp_col].max()
        
        # Generate expected range
        expected_range = pd.date_range(start=min_time, end=max_time, freq=freq)
        
        # Find missing timestamps
        missing_timestamps = expected_range.difference(df[timestamp_col]).tolist()
        
        return missing_timestamps
