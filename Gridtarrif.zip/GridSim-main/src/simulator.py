import asyncio
import logging
import json
import random
import pandas as pd
import numpy as np
from datetime import datetime
from typing import List, Optional
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from logging.handlers import RotatingFileHandler
import os

# Configure logging
# Configure logging
handlers = [logging.StreamHandler()]
try:
    handlers.append(RotatingFileHandler("simulation.log", maxBytes=5*1024*1024, backupCount=3))
except (PermissionError, OSError):
    pass

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=handlers
)
logger = logging.getLogger("DigitalTwinSimulator")

from fastapi import APIRouter

router = APIRouter()


# -----------------------------------------------------------
# Connection Manager
# -----------------------------------------------------------
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info("New client connected")

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)
        logger.info("Client disconnected")

    async def broadcast(self, message: str):
        for connection in self.active_connections:
            try:
                await connection.send_text(message)
            except Exception as e:
                logger.error(f"Error broadcasting message: {e}")

manager = ConnectionManager()

# -----------------------------------------------------------
# Simulator Logic
# -----------------------------------------------------------

def inject_noise(value: float, min_pct: float = 0.001, max_pct: float = 0.005) -> float:
    """Injects random noise between min_pct and max_pct."""
    if value is None:
        return None
    noise_pct = random.uniform(min_pct, max_pct)
    if random.choice([True, False]):
        return value * (1 + noise_pct)
    else:
        return value * (1 - noise_pct)

class Simulator:
    def __init__(self, file_path: str, speed_multiplier: float = 1.0):
        self.file_path = file_path
        self.speed_multiplier = speed_multiplier
        self.data_iterator = None
        self.running = False
        self.current_index = 0
        self.df = None
        self.modifiers = {
            "temperature_adjustment": 0.0,
            "load_multiplier": 1.0
        }
        # Rolling window for metric calculation
        self.metrics_history_actual = []
        self.metrics_history_preds = {
            'lstm': [],
            'deeplstm': [],
            'transformer': []
        }
        
        self.broadcast_history = []  # Store historical simulated points
        
        # Determine strict source order: 
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        # Adjust file path if relative
        if not os.path.isabs(self.file_path):
            self.file_path = os.path.join(base_dir, self.file_path)

    def update_modifiers(self, temp_adj: float = 0.0, load_mult: float = 1.0):
        self.modifiers["temperature_adjustment"] = temp_adj
        self.modifiers["load_multiplier"] = load_mult
        logger.info(f"Updated modifiers: {self.modifiers}")

    async def load_data(self):
        logger.info("Loading data from Supabase table 'energy_data_y2019'")
        try:
            import asyncpg
            from src.config import settings
            
            conn = await asyncpg.connect(
                user=settings.database.user,
                password=settings.database.password,
                database=settings.database.name,
                host=settings.database.host,
                port=settings.database.port
            )
            
            query = "SELECT timestamp, region, load_mw, temperature, humidity, wind_speed, precipitation FROM energy_data_y2019 ORDER BY timestamp ASC;"
            rows = await conn.fetch(query)
            await conn.close()
            
            data = [dict(row) for row in rows]
            self.df = pd.DataFrame(data)
            
            # Rename columns to match existing expectations
            self.df = self.df.rename(columns={
                'timestamp': 'datetime',
                'load_mw': 'load',
                'temperature': 'temperature_2m',
                'humidity': 'relative_humidity_2m',
                'wind_speed': 'windspeed_10m'
            })
            
            if 'datetime' in self.df.columns:
                self.df['datetime'] = pd.to_datetime(self.df['datetime'])
            
            self.start_index = 0
            self.current_index = self.start_index
            self.total_rows = len(self.df)
            logger.info(f"Loaded {self.total_rows} rows from DB. Starting simulation from index {self.start_index}.")
        except Exception as e:
            logger.error(f"Failed to load data: {e}")
            raise

    async def run_simulation(self):
        self.running = True
        logger.info(f"Starting simulation with speed Multiplier: {self.speed_multiplier}x")
        
        import httpx
        
        async with httpx.AsyncClient(timeout=10.0) as client:
            while self.running:
                if self.current_index >= self.total_rows:
                    logger.info("Simulation finished. Restarting loop.")
                    self.current_index = self.start_index
                    self.broadcast_history.clear()

                row = self.df.iloc[self.current_index].to_dict()
                
                simulated_data = row.copy()
                
                # Fix JSON serialization and timezone offset issues
                if 'datetime' in simulated_data and hasattr(simulated_data['datetime'], 'isoformat'):
                    dt_val = simulated_data['datetime']
                    # Strip timezone info so it represents the raw CSV time (naive)
                    if dt_val.tzinfo is not None:
                        dt_val = dt_val.replace(tzinfo=None)
                    simulated_data['datetime'] = dt_val.isoformat()
                
                # Apply Noise and Modifiers
                for key, val in simulated_data.items():
                    if key in ['datetime', 'time', 'latitude', 'longitude']:
                        continue
                    try:
                        f_val = float(val)
                        
                        # Apply Noise
                        f_val = inject_noise(f_val)
                        
                        # Apply Modifiers
                        if key == 'temperature_2m':
                            f_val += self.modifiers["temperature_adjustment"]
                        elif key == 'load':
                            f_val *= self.modifiers["load_multiplier"]
                            
                        simulated_data[key] = f_val
                    except (ValueError, TypeError):
                        pass
                
                simulated_data['simulation_timestamp'] = datetime.now().isoformat()
                
                # Query Real Models Using Current Context (24-hour sequence length)
                # Exact notebook alignment: x = data[i:i+24], y = data[i+23] (target aligns with last input row)
                if self.current_index >= 23:
                    lookback = self.df.iloc[self.current_index - 23 : self.current_index + 1]
                    features = []
                    for _, past_row in lookback.iterrows():
                        dt_val = past_row['datetime']
                        if hasattr(dt_val, 'isoformat'):
                            # Ensure naive format for HF inference to match training
                            if dt_val.tzinfo is not None:
                                dt_val = dt_val.replace(tzinfo=None)
                            dt_val = dt_val.isoformat()
                        features.append({
                            "timestamp": dt_val,
                            "temperature": float(past_row['temperature_2m']),
                            "humidity": float(past_row['relative_humidity_2m']),
                            "wind_speed": float(past_row['windspeed_10m'])
                        })
                    
                    payload = {"features": features}
                    
                    from src.config import settings
                    if settings.hf_inference_url:
                        base_url = settings.hf_inference_url
                        headers = {"Authorization": f"Bearer {settings.hf_token}"} if settings.hf_token else {}
                    else:
                        port = os.environ.get("PORT", "8000")
                        base_url = f"http://127.0.0.1:{port}"
                        headers = {}
                        
                    try:
                        tasks = [
                            client.post(f"{base_url}/predict/lstm", json=payload, headers=headers),
                            client.post(f"{base_url}/predict/deeplstm", json=payload, headers=headers),
                            client.post(f"{base_url}/predict/transformer", json=payload, headers=headers)
                        ]
                        responses = await asyncio.gather(*tasks, return_exceptions=True)
                        
                        if not isinstance(responses[0], Exception) and responses[0].status_code == 200:
                            simulated_data['lstm'] = responses[0].json().get('load')
                        if not isinstance(responses[1], Exception) and responses[1].status_code == 200:
                            simulated_data['deeplstm'] = responses[1].json().get('load')
                        if not isinstance(responses[2], Exception) and responses[2].status_code == 200:
                            simulated_data['transformer'] = responses[2].json().get('load')
                            
                        # Update Metrics History
                        self.metrics_history_actual.append(simulated_data['load'])
                        if len(self.metrics_history_actual) > 24:
                            self.metrics_history_actual.pop(0)

                        metrics_obj = {}
                        actuals_arr = np.array(self.metrics_history_actual)
                        
                        for m_key in ['lstm', 'deeplstm', 'transformer']:
                            pred_val = simulated_data.get(m_key)
                            # Put a fallback if prediction failed
                            if pred_val is None:
                                pred_val = simulated_data['load']
                                
                            self.metrics_history_preds[m_key].append(pred_val)
                            if len(self.metrics_history_preds[m_key]) > 24:
                                self.metrics_history_preds[m_key].pop(0)
                            
                            preds_arr = np.array(self.metrics_history_preds[m_key])
                            
                            # Only calculate metrics if arrays are the same length
                            if len(actuals_arr) > 0 and len(actuals_arr) == len(preds_arr):
                                rmse = float(np.sqrt(((actuals_arr - preds_arr)**2).mean()))
                                mae = float(np.abs(actuals_arr - preds_arr).mean())
                                
                                # Safety for MAPE (avoid divide by zero)
                                non_zero_mask = actuals_arr > 0
                                if non_zero_mask.any():
                                    mape = float(np.mean(np.abs((actuals_arr[non_zero_mask] - preds_arr[non_zero_mask]) / actuals_arr[non_zero_mask])) * 100)
                                    smapes = 200 * np.abs(actuals_arr[non_zero_mask] - preds_arr[non_zero_mask]) / (np.abs(actuals_arr[non_zero_mask]) + np.abs(preds_arr[non_zero_mask]) + 1e-8)
                                    smape = float(np.mean(smapes))
                                else:
                                    mape = 0.0
                                    smape = 0.0
                                
                                # r2 calc
                                ss_res = ((actuals_arr - preds_arr)**2).sum()
                                ss_tot = ((actuals_arr - actuals_arr.mean())**2).sum()
                                r2 = float(1 - (ss_res / ss_tot)) if ss_tot > 0 else 0.0
                                
                                metrics_obj[m_key] = {
                                    'rmse': rmse,
                                    'mae': mae,
                                    'mape': mape,
                                    'smape': smape,
                                    'r2': r2,
                                    'mape_history': [0]*24 # we can pass a dummy array since graph isn't using the full history anymore, or just construct it
                                }
                                
                        if metrics_obj:
                            simulated_data['metrics'] = metrics_obj

                    except Exception as e:
                        logger.error(f"Failed to fetch predictions from AI Engine: {e}")
                
                # Keep history for frontend reloads
                self.broadcast_history.append({
                    "datetime": simulated_data.get("datetime"),
                    "load": simulated_data.get("load"),
                    "lstm": simulated_data.get("lstm"),
                    "deeplstm": simulated_data.get("deeplstm"),
                    "transformer": simulated_data.get("transformer")
                })
                # Cap it at something big but safe so it doesn't crash everything if left running for days
                if len(self.broadcast_history) > 20000:
                    self.broadcast_history = self.broadcast_history[-20000:]
                
                message = json.dumps(simulated_data)
                
                # Broadcast to local websockets
                await manager.broadcast(message)
                
                # Publish to Redis for other services (Dashboard API)
                try:
                    if not hasattr(self, 'redis_client'):
                        import redis.asyncio as aioredis
                        from src.config import settings
                        redis_url = os.environ.get("REDIS_URL")
                        if redis_url:
                            self.redis_client = aioredis.from_url(
                                redis_url, 
                                decode_responses=True,
                                health_check_interval=30,
                                socket_keepalive=True
                            )
                        else:
                            self.redis_client = aioredis.Redis(
                                host=settings.redis.host,
                                port=settings.redis.port,
                                db=settings.redis.db,
                                password=settings.redis.password,
                                ssl=settings.redis.ssl or "upstash.io" in settings.redis.host,
                                ssl_cert_reqs="none",
                                decode_responses=True,
                                health_check_interval=30,
                                socket_keepalive=True
                            )
                    
                    await self.redis_client.publish("digital_twin:updates", message)
                    await self.redis_client.set("digital_twin:current_state", message)
                    
                    # Cache last 24hr predictions
                    if len(self.broadcast_history) > 0:
                        last_24 = self.broadcast_history[-24:]
                        # Fix json serialization of pandas timestamps in cache
                        for item in last_24:
                            if 'datetime' in item and hasattr(item['datetime'], 'isoformat'):
                                item['datetime'] = item['datetime'].isoformat()
                        await self.redis_client.set("digital_twin:last_24hr_predictions", json.dumps(last_24))
                        
                except Exception as e:
                    logger.error(f"Failed to publish to Redis: {e}")
                
                self.current_index += 1
                
                # Fetch config sleep delay mapping to APP_SIMULATOR_TICK_SECONDS
                # Tick every APP_SIMULATOR_TICK_SECONDS seconds (default: 900 = 15 min)
                # Set APP_SIMULATOR_TICK_SECONDS=60 for faster testing
                delay = settings.simulator_tick_seconds / self.speed_multiplier
                if delay < 0.1: delay = 0.1
                
                try:
                    await asyncio.sleep(delay)
                except asyncio.CancelledError:
                    self.running = False
                    logger.info("Simulation cancelled")
                    break

from src.config import settings

# Global simulator instance
simulator = Simulator(
    file_path=settings.simulator.file_path,
    speed_multiplier=settings.simulator.speed_multiplier
)

async def start_simulator_task():
    """Function to start the simulation loop, called from main app lifespan."""
    await simulator.load_data()
    asyncio.create_task(simulator.run_simulation())

from pydantic import BaseModel

class WhatIfRequest(BaseModel):
    temperature_adjustment: float = 0.0
    load_multiplier: float = 1.0

@router.post("/what-if")
async def set_what_if(request: WhatIfRequest):
    """
    Apply 'What-If' scenarios to the running simulation.
    - temperature_adjustment: Add/Subtract degrees Celsius (e.g., +5.0)
    - load_multiplier: Multiply load by factor (e.g., 1.1 for 10% increase)
    """
    simulator.update_modifiers(request.temperature_adjustment, request.load_multiplier)
    return {"status": "updated", "modifiers": simulator.modifiers}

@router.get("/history")
async def get_history():
    """
    Returns the historical data generated by the simulator so far (up to 20k points).
    """
    return simulator.broadcast_history

@router.get("/simulation/tick-info")
async def get_tick_info():
    """
    Returns the update interval of the simulator.
    """
    return {
        "tick_seconds": settings.simulator_tick_seconds,
        "tick_minutes": settings.simulator_tick_seconds / 60.0
    }

@router.get("/")
def read_root():
    """
    Returns the current status of the Digital Twin Simulator.
    """
    return {
        "status": "running", 
        "simulator": "IndiaLoadTariff Digital Twin Simulator",
        "speed_multiplier": simulator.speed_multiplier,
        "current_index": simulator.current_index,
        "total_rows": simulator.total_rows,
        "ws_endpoint": "/ws/simulation",
        "modifiers": simulator.modifiers
    }

@router.websocket("/ws/simulation")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            # Keep the connection open
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket)

# Support standalone execution
if __name__ == "__main__":
    import uvicorn
    # Create a temporary app for standalone run
    app = FastAPI(title="Digital Twin Data Simulator")
    
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    app.include_router(router)
    
    @app.on_event("startup")
    async def startup():
        await start_simulator_task()
        
    uvicorn.run(app, host="0.0.0.0", port=8001)

