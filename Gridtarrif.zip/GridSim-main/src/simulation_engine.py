from enum import Enum
from typing import List, Optional, Dict, Any, Union
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import logging

# Setup Logger
logger = logging.getLogger(__name__)

class ScenarioType(str, Enum):
    TEMPERATURE = "temperature"
    FESTIVAL = "festival"
    RENEWABLE = "renewable"

class ScenarioConfig(BaseModel):
    type: ScenarioType
    magnitude: float = Field(..., description="Magnitude of the scenario effect (e.g., +5.0 deg C, +10% demand)")
    start_offset_hours: int = Field(0, description="Hours from simulation start to apply scenario")
    duration_hours: Optional[int] = Field(None, description="Duration in hours. If None, applies until end.")

class SimulationConfig(BaseModel):
    start_time: datetime
    hours: int = Field(24, ge=1, le=168, description="Simulation horizon in hours")
    scenarios: List[ScenarioConfig] = []
    model_type: str = Field("LSTM", description="Model to use: LSTM, DeepLSTM, Transformer")
    speed_multiplier: float = Field(1.0, description="Speed multiplier for real-time simulation (not used in fast-forward)")

class SimulationResult(BaseModel):
    simulation_id: str
    timestamp: datetime
    config: SimulationConfig
    execution_time_ms: float
    results: List[Dict[str, Any]] # List of {timestamp, load, etc.}

# --- Scenario Generators ---

class ScenarioGenerator:
    def __init__(self, config: ScenarioConfig):
        self.config = config

    def apply_pre_prediction(self, df: pd.DataFrame, start_time: datetime) -> pd.DataFrame:
        """Modify input features before prediction (e.g., temperature)."""
        return df

    def apply_post_prediction(self, predictions: np.ndarray, start_time: datetime, time_index: pd.DatetimeIndex) -> np.ndarray:
        """Modify output load after prediction (e.g., demand surge)."""
        return predictions
    
    def _is_active(self, current_time: datetime, start_time: datetime) -> bool:
        sim_start = start_time + timedelta(hours=self.config.start_offset_hours)
        if current_time < sim_start:
            return False
        if self.config.duration_hours is not None:
            sim_end = sim_start + timedelta(hours=self.config.duration_hours)
            if current_time >= sim_end:
                 return False
        return True

class TemperatureScenario(ScenarioGenerator):
    def apply_pre_prediction(self, df: pd.DataFrame, start_time: datetime) -> pd.DataFrame:
        # Check if 'temperature_2m' or similar exists
        col_name = 'temperature_2m'
        if col_name not in df.columns:
            return df
        
        # We need identifying time to apply correctly, but here we assume df is the whole simulation window
        # If df has datetime index or column, use it.
        # For vectorization, df covers the whole range.
        
        # Naive implementation: apply to all rows for now (or filter by time if column exists)
        # Assuming df is sorted by time and starts at start_time
        
        # Apply magnitude
        # Create a mask for valid times
        # For simplicity in this version, apply to all rows if no duration specified, 
        # or calculate indices if we know the frequency (hourly).
        
        updated_df = df.copy()
        
        # Calculate start/end indices assuming hourly data and df starts at start_time
        start_idx = self.config.start_offset_hours
        end_idx = len(df)
        if self.config.duration_hours:
            end_idx = min(start_idx + self.config.duration_hours, len(df))
            
        if start_idx < len(df):
             updated_df.iloc[start_idx:end_idx, updated_df.columns.get_loc(col_name)] += self.config.magnitude
             
        return updated_df

class FestivalScenario(ScenarioGenerator):
    def apply_post_prediction(self, predictions: np.ndarray, start_time: datetime, time_index: pd.DatetimeIndex) -> np.ndarray:
        # Increase load by X%
        # magnitude 10.0 means +10% -> factor 1.10
        factor = 1.0 + (self.config.magnitude / 100.0)
        
        updated_preds = predictions.copy()
        
        # Simple index-based application
        start_idx = self.config.start_offset_hours
        end_idx = len(predictions)
        if self.config.duration_hours:
            end_idx = min(start_idx + self.config.duration_hours, len(predictions))
            
        if start_idx < len(predictions):
            updated_preds[start_idx:end_idx] *= factor
            
        return updated_preds

class RenewableScenario(ScenarioGenerator):
    def apply_post_prediction(self, predictions: np.ndarray, start_time: datetime, time_index: pd.DatetimeIndex) -> np.ndarray:
        # Reduce load (injection) by Y%
        # magnitude 20.0 means -20% -> factor 0.80
        factor = 1.0 - (self.config.magnitude / 100.0)
        
        updated_preds = predictions.copy()
        
        start_idx = self.config.start_offset_hours
        end_idx = len(predictions)
        if self.config.duration_hours:
            end_idx = min(start_idx + self.config.duration_hours, len(predictions))
        
        if start_idx < len(predictions):
            updated_preds[start_idx:end_idx] *= factor
            
        return updated_preds


class SimulationEngine:
    def __init__(self, model_executor=None):
        self.model_executor = model_executor 
    
    def _create_scenarios(self, configs: List[ScenarioConfig]) -> List[ScenarioGenerator]:
        generators = []
        for cfg in configs:
            if cfg.type == ScenarioType.TEMPERATURE:
                generators.append(TemperatureScenario(cfg))
            elif cfg.type == ScenarioType.FESTIVAL:
                generators.append(FestivalScenario(cfg))
            elif cfg.type == ScenarioType.RENEWABLE:
                generators.append(RenewableScenario(cfg))
        return generators

    async def run(self, config: SimulationConfig, initial_state: pd.DataFrame) -> SimulationResult:
        """
        Runs the simulation.
        
        Args:
            config: Simulation configuration.
            initial_state: DataFrame containing initial environmental conditions 
                           for the simulation period (weather forecast).
                           Must cover config.start_time to config.start_time + hours.
        """
        import time
        import uuid
        
        start_time = time.time()
        sim_id = str(uuid.uuid4())
        
        # 1. Prepare Data
        # Ensure initial_state covers the required hours
        # In a real system, we'd fetch weather forecast here if not provided.
        # For now, we assume initial_state has 'temperature_2m' etc. for the horizon.
        
        if len(initial_state) < config.hours:
             # Extend or error? For now, slice or error if too short
             raise ValueError(f"Initial state data length {len(initial_state)} is less than requested simulation hours {config.hours}")
        
        simulation_df = initial_state.head(config.hours).copy()
        
        # 2. Initialize Scenarios
        scenario_generators = self._create_scenarios(config.scenarios)
        
        # 3. Apply Pre-Prediction Scenarios (Weather modifictions)
        for gen in scenario_generators:
            simulation_df = gen.apply_pre_prediction(simulation_df, config.start_time)
            
        # 4. Execute Model (Vectorized)
        if self.model_executor:
            predictions = await self.model_executor.predict_batch(simulation_df, config.model_type)
        else:
            # Fallback for testing without executor
            predictions = np.zeros(config.hours) 
            
        # 5. Apply Post-Prediction Scenarios (Load modifications)
        # Create time index for scenarios to use if needed
        time_index = pd.date_range(start=config.start_time, periods=config.hours, freq='h')
        
        for gen in scenario_generators:
            predictions = gen.apply_post_prediction(predictions, config.start_time, time_index)
            
        # 6. Format Results
        results = []
        for i, (ts, load) in enumerate(zip(time_index, predictions)):
            row = simulation_df.iloc[i].to_dict()
            row['timestamp'] = ts
            row['predicted_load'] = float(load) # Ensure float
            results.append(row)
            
        execution_time = (time.time() - start_time) * 1000
        
        return SimulationResult(
            simulation_id=sim_id,
            timestamp=datetime.now(),
            config=config,
            execution_time_ms=execution_time,
            results=results
        )
