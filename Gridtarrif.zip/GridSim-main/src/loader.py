import pandas as pd
import psycopg2
from psycopg2.extras import execute_values
import os
import sys

# Add project root to sys.path to allow imports from src
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from dotenv import load_dotenv
from src.validator import DataValidator
import logging
from typing import Optional

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

from src.config import settings

def get_db_connection():
    """Establishes a connection to the PostgreSQL database."""
    try:
        conn = psycopg2.connect(
            host=settings.database.host,
            port=settings.database.port,
            dbname=settings.database.name,
            user=settings.database.user,
            password=settings.database.password
        )
        return conn
    except Exception as e:
        logger.error(f"Failed to connect to database: {e}")
        raise

def ingest_data(file_path: str, region: str = "India"):
    """
    Ingests data from a CSV file into the TimescaleDB database.
    Performs validation before insertion.
    """
    logger.info(f"Starting ingestion for file: {file_path}")
    
    if not os.path.exists(file_path):
        logger.error(f"File not found: {file_path}")
        return

    try:
        df = pd.read_csv(file_path)
    except Exception as e:
        logger.error(f"Failed to read CSV: {e}")
        return

    # Column mapping
    column_mapping = {
        'datetime': 'timestamp',
        'load': 'load_mw',
        'temperature_2m': 'temperature',
        'relative_humidity_2m': 'humidity',
        'windspeed_10m': 'wind_speed',
        'precipitation': 'precipitation'
    }

    # Verify required columns exist
    missing_cols = [col for col in column_mapping.keys() if col not in df.columns]
    if missing_cols:
        logger.error(f"Missing required columns in CSV: {missing_cols}")
        return

    # Rename columns and select relevant ones
    df = df.rename(columns=column_mapping)
    df['region'] = region
    
    required_schema_cols = ['timestamp', 'region', 'load_mw', 'temperature', 'humidity', 'wind_speed', 'precipitation']
    df = df[required_schema_cols]

    # Convert timestamp
    df['timestamp'] = pd.to_datetime(df['timestamp'])

    # Validation
    validator = DataValidator()
    
    # 1. Check missing values
    missing = validator.check_missing_values(df)
    if missing:
        logger.warning(f"Found missing values: {missing}. Rows with NaNs will be dropped.")
        df = df.dropna()

    # 2. Check outliers (logging only, not dropping usually unless specified)
    numeric_cols = ['load_mw', 'temperature', 'humidity', 'wind_speed', 'precipitation']
    outliers = validator.check_outliers(df, numeric_cols)
    if outliers:
        logger.warning(f"Found potential outliers (>3 std dev): {outliers}")

    # 3. Check continuity
    missing_timestamps = validator.check_continuity(df, 'timestamp')
    if missing_timestamps:
        logger.warning(f"Found {len(missing_timestamps)} missing timestamps in the sequence.")

    # Database insertion
    try:
        conn = get_db_connection()
        cur = conn.cursor()

        # Prepare data for insertion
        data_tuples = list(df.itertuples(index=False, name=None))
        
        insert_query = """
            INSERT INTO energy_data (timestamp, region, load_mw, temperature, humidity, wind_speed, precipitation)
            VALUES %s
            ON CONFLICT (timestamp, region) DO NOTHING;
        """
        
        execute_values(cur, insert_query, data_tuples)
        conn.commit()
        
        logger.info(f"Successfully ingested {len(data_tuples)} rows into energy_data.")
        
        cur.close()
        conn.close()

    except Exception as e:
        logger.error(f"Database insertion failed: {e}")
        if conn:
            conn.rollback()
            conn.close()

if __name__ == "__main__":
    # Default execution
    csv_file = "INDIAmerged_hourly_load_weather.csv"
    ingest_data(csv_file)
