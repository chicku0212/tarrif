
import json
import logging
import asyncio
from datetime import datetime, timedelta
from typing import Dict, Optional, List
import pandas as pd
from pydantic import BaseModel, root_validator, Field
import redis.asyncio as redis
import asyncpg
from src.config import settings

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("DigitalTwinStateManager")

class DigitalTwinState(BaseModel):
    timestamp: datetime
    # Target and Prediction
    load: float
    prediction: Optional[float] = None
    variance: Optional[float] = None
    
    # Weather Features
    temperature_2m: float
    relative_humidity_2m: float
    windspeed_10m: float
    dew_point_2m: float
    
    # Time Features
    hour: int
    day_of_month: int
    dayofweek: int
    day_of_year: int
    month: int
    year: int
    week_of_year: int
    
    # Metadata
    region: str = "India"
    
    @root_validator(pre=True)
    def calculate_variance(cls, values):
        # Auto-calculate variance if prediction is present
        load = values.get('load')
        prediction = values.get('prediction')
        if load is not None and prediction is not None:
            values['variance'] = float(prediction) - float(load)
        return values

class StateManager:
    def __init__(self):
        self.redis_client = None
        self.db_pool = None
        self.alert_threshold_minutes = 15
        
    async def connect(self):
        """Initialize Redis and TimescaleDB connections."""
        try:
            # Connect to Redis
            self.redis_client = redis.Redis(
                host=settings.redis.host,
                port=settings.redis.port,
                db=settings.redis.db,
                password=settings.redis.password,
                decode_responses=True
            )
            await self.redis_client.ping()
            logger.info("Connected to Redis.")
            
            # Connect to TimescaleDB (PostgreSQL)
            dsn = f"postgresql://{settings.database.user}:{settings.database.password}@{settings.database.host}:{settings.database.port}/{settings.database.name}"
            self.db_pool = await asyncpg.create_pool(dsn)
            logger.info("Connected to TimescaleDB.")
            
            # Ensure tables exist
            await self.init_db()
            
        except Exception as e:
            logger.error(f"Failed to connect to infrastructure: {e}")
            raise

    async def init_db(self):
        """Create necessary tables in TimescaleDB."""
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS digital_twin_states (
                    timestamp TIMESTAMPTZ NOT NULL,
                    load DOUBLE PRECISION,
                    prediction DOUBLE PRECISION,
                    variance DOUBLE PRECISION,
                    temperature_2m DOUBLE PRECISION,
                    relative_humidity_2m DOUBLE PRECISION,
                    windspeed_10m DOUBLE PRECISION,
                    dew_point_2m DOUBLE PRECISION,
                    region TEXT
                ) PARTITION BY RANGE (timestamp);
            """)
            
            # Setup native partitions (2019 to 2025)
            try:
                await conn.execute("""
                    DO $$
                    DECLARE
                        y INT;
                    BEGIN
                        FOR y IN 2019..2025 LOOP
                            EXECUTE format('CREATE TABLE IF NOT EXISTS digital_twin_states_y%s PARTITION OF digital_twin_states FOR VALUES FROM (%L) TO (%L)', y, y||'-01-01', (y+1)||'-01-01');
                        END LOOP;
                    END;
                    $$;
                """)
            except Exception as e:
                logger.warning(f"Partition bounds already exist, skipping creation: {e}")

    async def save_state(self, state: DigitalTwinState):
        """Save state to Redis (hot) and TimescaleDB (historical)."""
        if not self.redis_client or not self.db_pool:
            raise RuntimeError("StateManager not connected.")

        # 1. Save to Redis (Current State)
        state_json = state.json()
        await self.redis_client.set("digital_twin:current_state", state_json)
        await self.redis_client.set("digital_twin:last_update", datetime.now().isoformat())
        
        # 2. Archive to TimescaleDB
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO digital_twin_states (
                    timestamp, load, prediction, variance, 
                    temperature_2m, relative_humidity_2m, windspeed_10m, dew_point_2m, region
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
            """, 
            state.timestamp, state.load, state.prediction, state.variance,
            state.temperature_2m, state.relative_humidity_2m, state.windspeed_10m, state.dew_point_2m, state.region
            )
        logger.info(f"State saved for {state.timestamp}")

    async def get_current_state(self) -> Optional[DigitalTwinState]:
        """Retrieve current state from Redis."""
        data = await self.redis_client.get("digital_twin:current_state")
        if data:
            return DigitalTwinState.parse_raw(data)
        return None

    async def check_staleness(self):
        """Check if data is stale and raise alert."""
        last_update = await self.redis_client.get("digital_twin:last_update")
        if not last_update:
            logger.warning("No state data found.")
            return

        last_update_dt = datetime.fromisoformat(last_update)
        diff = datetime.now() - last_update_dt
        
        if diff > timedelta(minutes=self.alert_threshold_minutes):
            logger.error(f"ALERT: Data Stale! Last update was {diff.total_seconds() / 60:.1f} minutes ago.")
            # In a real system, send email/Slack/PagerDuty here
            
    async def create_snapshot(self):
        """Create a persistent snapshot of the current state."""
        state = await self.get_current_state()
        if state:
            key = f"digital_twin:snapshot:{state.timestamp.isoformat()}"
            await self.redis_client.set(key, state.json())
            logger.info(f"Snapshot created: {key}")

    async def update_state(self, raw_data: Dict):
        """Process incoming raw data, enrich it, and save."""
        # raw_data might need parsing if it comes from Simulator as strings
        # or if it lacks derived fields.
        
        # 1. Parse Timestamp
        ts = raw_data.get('datetime', raw_data.get('timestamp'))
        if isinstance(ts, str):
            ts = pd.to_datetime(ts).to_pydatetime() if 'pd' in globals() else datetime.fromisoformat(ts)
            
        # 2. Extract Fields
        try:
            state = DigitalTwinState(
                timestamp=ts,
                load=float(raw_data['load']),
                prediction=raw_data.get('prediction'),
                variance=None,
                temperature_2m=float(raw_data['temperature_2m']),
                relative_humidity_2m=float(raw_data['relative_humidity_2m']),
                windspeed_10m=float(raw_data.get('windspeed_10m', 0.0)),
                dew_point_2m=float(raw_data.get('dew_point_2m', 0.0)),
                
                # Derived Time Features
                hour=ts.hour,
                day_of_month=ts.day,
                dayofweek=ts.weekday(),
                day_of_year=ts.timetuple().tm_yday,
                month=ts.month,
                year=ts.year,
                week_of_year=ts.isocalendar()[1]
            )
            
            await self.save_state(state)
            
        except Exception as e:
            logger.error(f"Error processing state update: {e}")
