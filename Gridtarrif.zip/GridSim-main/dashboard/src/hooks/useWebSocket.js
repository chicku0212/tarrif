import { useState, useEffect, useRef, useCallback } from "react";

export function useWebSocket(url, options = {}) {
  const { maxReconnectAttempts = 10, reconnectDelay = 3000 } = options;

  const [liveData, setLiveData] = useState(null);
  const [wsStatus, setWsStatus] = useState("disconnected"); // 'connected', 'reconnecting', 'disconnected'
  const reconnectCountRef = useRef(0);
  const wsRef = useRef(null);

  const connect = useCallback(() => {
    if (
      wsRef.current?.readyState === WebSocket.OPEN ||
      wsRef.current?.readyState === WebSocket.CONNECTING
    ) {
      return;
    }

    try {
      const socket = new WebSocket(url);

      socket.onopen = () => {
        setWsStatus("connected");
        reconnectCountRef.current = 0; // reset
      };

      socket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          setLiveData((prevData) => {
            // Can merge logic here or just replace
            return data;
          });
        } catch (e) {
          console.error("Failed to parse WebSocket message:", e);
        }
      };

      socket.onclose = () => {
        if (reconnectCountRef.current < maxReconnectAttempts) {
          setWsStatus("reconnecting");
          setTimeout(() => {
            reconnectCountRef.current += 1;
            connect();
          }, reconnectDelay);
        } else {
          setWsStatus("disconnected");
        }
        wsRef.current = null;
      };

      socket.onerror = (err) => {
        console.error("WebSocket encountered an error:", err);
        socket.close(); // forces trigger of onclose which handles reconnect
      };

      wsRef.current = socket;
    } catch (e) {
      console.error("WebSocket connection failed:", e);
      setWsStatus("disconnected");
    }
  }, [url, maxReconnectAttempts, reconnectDelay]);

  // Connect on mount
  useEffect(() => {
    connect();

    return () => {
      // Cleanup on unmount
      if (wsRef.current) {
        // Prevent reconnect handling during unmount logic
        wsRef.current.onclose = null;
        wsRef.current.close();
      }
    };
  }, [connect]);

  const reconnect = useCallback(() => {
    if (wsStatus === "disconnected") {
      reconnectCountRef.current = 0;
      connect();
    }
  }, [wsStatus, connect]);

  return { liveData, wsStatus, reconnect };
}
