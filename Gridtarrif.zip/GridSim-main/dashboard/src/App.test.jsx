import { render, screen } from '@testing-library/react';
import App from './App';
import { describe, it, expect } from 'vitest';

describe('App Component', () => {
    it('renders dashboard title', () => {
        render(<App />);
        // Check for the main title in Layout
        expect(screen.getByText(/Digital Twin/i)).toBeInTheDocument();
    });

    it('renders simulation controls placeholder/component', () => {
        render(<App />);
        // Check for "Simulation Controls" text which is in the SimulationControlPanel component
        expect(screen.getByText(/Simulation Controls/i)).toBeInTheDocument();
    });
});
