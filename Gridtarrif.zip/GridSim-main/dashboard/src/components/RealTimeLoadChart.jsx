import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  TimeScale,
  Filler,
} from "chart.js";
import { Line } from "react-chartjs-2";
import "chartjs-adapter-date-fns";
import { subDays } from "date-fns";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  TimeScale,
  Filler,
);

import { API_BASE_URL, WS_BASE_URL } from "../config";

// Constants
const DATA_LIMITS = {
  "1H": 12, // 5-min intervals
  "6H": 72,
  "24H": 24, // 1-hour intervals
  "7D": 168,
  "30D": 720,
};

const URLS = {
  HTTP_BASE: API_BASE_URL,
  WS_BASE: `${WS_BASE_URL}/ws/dashboard`,
};

const NUM_FORMATTER = new Intl.NumberFormat("en-US", {
  maximumFractionDigits: 0,
});

function formatK(num) {
  if (num === null || num === undefined) return "";
  return Math.abs(num) >= 1000 ? Math.round(num / 1000) + "k" : num;
}

// Hook to detect dark mode via HTML attribute
function useDarkMode() {
  const [isDark, setIsDark] = useState(true); // default to dark since that's what Header defaults to

  useEffect(() => {
    const htmlElement = document.documentElement;

    // Check both class and data-theme to be robust
    const checkDark = () => {
      const isHtmlDark =
        htmlElement.classList.contains("dark") ||
        htmlElement.getAttribute("data-theme") === "dark";

      // Also check body since Tailwind sometimes relies on body
      const isBodyDark =
        document.body.classList.contains("dark") ||
        document.body.getAttribute("data-theme") === "dark";

      setIsDark(isHtmlDark || isBodyDark);
    };

    checkDark();

    const observer = new MutationObserver(checkDark);
    observer.observe(htmlElement, {
      attributes: true,
      attributeFilter: ["class", "data-theme"],
    });

    return () => observer.disconnect();
  }, []);

  return isDark;
}

export default function RealTimeLoadChart({
  liveData,
  initialGridStatus,
  historyData,
  predictions24h,
}) {
  const isDark = useDarkMode();
  const [timeRange, setTimeRange] = useState("ALL");
  const [currentLoad, setCurrentLoad] = useState(0);
  const [isConnected, setIsConnected] = useState(true);

  const [chartData, setChartData] = useState([]);
  const [historicalLines, setHistoricalLines] = useState({
    lstm: [],
    deeplstm: [],
    transformer: [],
  });

  const historyLoaded = useRef(false);

  // Helper to parse dates as local time to avoid the +5:30 offset shift
  const parseLocalTime = (dtString) => {
    if (!dtString) return Date.now();
    let cleanStr = dtString.replace("Z", "").replace("+00:00", "");
    return new Date(cleanStr).getTime();
  };

  // Handle Initial & Historical Data
  useEffect(() => {
    if (historyData && historyData.length > 0 && !historyLoaded.current) {
      historyLoaded.current = true;
      let initPoints = historyData.map((pt) => ({
        x: parseLocalTime(pt.datetime),
        actual: pt.load,
        lstm: pt.lstm,
        deeplstm: pt.deeplstm,
        transformer: pt.transformer,
      }));

      setChartData((prev) => {
        const existingXs = new Set(prev.map((p) => p.x));
        const toAdd = initPoints.filter((p) => !existingXs.has(p.x));
        let updated = [...toAdd, ...prev].sort((a, b) => a.x - b.x);
        if (updated.length > 5000) {
          updated = updated.slice(updated.length - 5000);
        }
        return updated;
      });
      // Set current load to the very last historical point
      setCurrentLoad(initPoints[initPoints.length - 1].actual);
    } else if (
      initialGridStatus &&
      chartData.length === 0 &&
      !historyData?.length
    ) {
      // Fallback to single point if no history
      setCurrentLoad(initialGridStatus.load);
      setChartData([
        {
          x: parseLocalTime(initialGridStatus.datetime),
          actual: initialGridStatus.load,
          lstm: initialGridStatus.lstm,
          deeplstm: initialGridStatus.deeplstm,
          transformer: initialGridStatus.transformer,
        },
      ]);
    }
  }, [initialGridStatus, historyData]);

  // Handle Predictions Prop
  useEffect(() => {
    if (predictions24h) {
      setHistoricalLines(predictions24h);
    }
  }, [predictions24h]);

  // Handle Live Data Streaming
  useEffect(() => {
    if (liveData) {
      const t = parseLocalTime(liveData.datetime);

      if (liveData.load !== undefined) {
        setCurrentLoad(liveData.load);
      }

      setChartData((prev) => {
        // Check if this point already exists to avoid duplicates
        const exists = prev.some((pt) => pt.x === t);
        if (exists) return prev;

        const newPt = {
          x: t,
          actual: liveData.load,
          lstm: liveData.lstm,
          deeplstm: liveData.deeplstm,
          transformer: liveData.transformer,
        };
        const updated = [...prev, newPt];

        // Only enforce a max item count
        // Do not permanently slice it by the currently selected timeRange!
        if (updated.length > 5000) {
          return updated.slice(updated.length - 5000);
        }
        return updated;
      });
    }
  }, [liveData]);

  // Chart UI Data mapping
  const datasetConf = useMemo(() => {
    const mkData = (field) => {
      // For this spec, we map live streaming data to `chartData`.
      return chartData.map((d) => ({ x: d.x, y: d[field] }));
    };

    return {
      datasets: [
        {
          label: "ACTUAL",
          data: chartData.map((d) => ({ x: d.x, y: d.actual })),
          borderColor: "#14b8a6", // teal
          backgroundColor: (context) => {
            const ctx = context.chart.ctx;
            const gradient = ctx.createLinearGradient(
              0,
              0,
              0,
              context.chart.height,
            );
            gradient.addColorStop(0, "rgba(20, 184, 166, 0.12)");
            gradient.addColorStop(1, "rgba(20, 184, 166, 0)");
            return gradient;
          },
          borderWidth: 2,
          fill: true,
          tension: 0.1,
          pointRadius: 0,
          pointHoverRadius: 4,
          order: 1,
        },
        {
          label: "LSTM",
          data: mkData("lstm"),
          borderColor: "#f59e0b",
          borderWidth: 1.5,
          borderDash: [5, 4],
          pointRadius: 0,
          pointHoverRadius: 4,
          fill: false,
          tension: 0.1,
          order: 2,
        },
        {
          label: "DEEP LSTM",
          data: mkData("deeplstm"),
          borderColor: "#8b5cf6",
          borderWidth: 1.5,
          borderDash: [5, 4],
          pointRadius: 0,
          pointHoverRadius: 4,
          fill: false,
          tension: 0.1,
          order: 3,
        },
        {
          label: "TRANSFORMER",
          data: mkData("transformer"),
          borderColor: "#f43f5e",
          borderWidth: 1.5,
          borderDash: [5, 4],
          pointRadius: 0,
          pointHoverRadius: 4,
          fill: false,
          tension: 0.1,
          order: 4,
        },
      ],
    };
  }, [chartData, historicalLines]);

  const chartOptions = useMemo(() => {
    // Generate rigid time boundaries for the x-axis based on the selected timeRange
    const latestTime =
      chartData.length > 0 ? chartData[chartData.length - 1].x : Date.now();
    let windowMs = 24 * 60 * 60 * 1000;
    let timeUnit = "hour";
    let stepSize = 1;

    if (timeRange === "1H") {
      windowMs = 60 * 60 * 1000;
      timeUnit = "minute";
      stepSize = 10;
    } else if (timeRange === "6H") {
      windowMs = 6 * 60 * 60 * 1000;
      timeUnit = "hour";
      stepSize = 1;
    } else if (timeRange === "24H") {
      windowMs = 24 * 60 * 60 * 1000;
      timeUnit = "hour";
      stepSize = 3;
    } else if (timeRange === "7D") {
      windowMs = 7 * 24 * 60 * 60 * 1000;
      timeUnit = "day";
      stepSize = 1;
    } else if (timeRange === "30D") {
      windowMs = 30 * 24 * 60 * 60 * 1000;
      timeUnit = "day";
      stepSize = 5;
    } else if (timeRange === "ALL") {
      windowMs =
        chartData.length > 0
          ? latestTime - chartData[0].x
          : 24 * 60 * 60 * 1000;
      // Provide a fallback window just in case
      if (windowMs === 0) windowMs = 24 * 60 * 60 * 1000;

      // Auto-scale timeUnit appropriately based on data span
      const days = windowMs / (24 * 60 * 60 * 1000);
      if (days < 2) {
        timeUnit = "hour";
        stepSize = 3;
      } else if (days < 14) {
        timeUnit = "day";
        stepSize = 1;
      } else {
        timeUnit = "day";
        stepSize = 7;
      }
    }

    return {
      responsive: true,
      maintainAspectRatio: false,
      animation: {
        duration: 200,
      },
      scales: {
        x: {
          type: "time",
          min: latestTime - windowMs,
          max: latestTime,
          time: {
            unit: timeUnit,
            stepSize: stepSize,
            displayFormats: {
              hour: "HH:mm dd MMM",
              minute: "HH:mm dd MMM",
              day: "MMM dd",
            },
            tooltipFormat: "HH:mm dd MMM yyyy",
          },
          ticks: {
            maxRotation: 0,
            autoSkip: true,
            maxTicksLimit: 12,
            color: isDark ? "#6b7280" : "#6b7280",
            font: {
              family: "Inter",
              size: 11,
            },
          },
          grid: {
            color: isDark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.05)",
            drawBorder: false,
          },
        },
        y: {
          ticks: {
            color: isDark ? "#6b7280" : "#6b7280",
            font: {
              family: "Inter",
              size: 11,
            },
            callback: function (value) {
              return formatK(value);
            },
          },
          grid: {
            color: isDark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.05)",
            drawBorder: false,
          },
        },
      },
      plugins: {
        legend: {
          position: "bottom",
          labels: {
            boxWidth: 12,
            boxHeight: 12,
            usePointStyle: false, // Ensures square boxes
            color: isDark ? "#f1f5f9" : "#111827",
            font: {
              family: "Inter",
              size: 11,
              weight: "500",
            },
            padding: 24,
          },
        },
        tooltip: {
          backgroundColor: isDark ? "#161b27" : "#ffffff",
          titleColor: isDark ? "#f1f5f9" : "#111827",
          bodyColor: isDark ? "#f1f5f9" : "#111827",
          borderColor: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.06)",
          borderWidth: 1,
          titleFont: { family: "Inter", size: 12, weight: "600" },
          bodyFont: { family: "Inter", size: 12 },
          padding: 12,
          boxPadding: 6,
          usePointStyle: true,
          callbacks: {
            label: (ctx) => {
              const val = ctx.parsed.y;
              return `${ctx.dataset.label}: ${NUM_FORMATTER.format(val)} MW`;
            },
          },
        },
      },
      interaction: {
        mode: "index",
        intersect: false,
      },
    };
  }, [timeRange, isDark, chartData]);

  // UI Theme classes
  const cardBg = "bg-white dark:bg-[#161b27]";
  const cardBorder =
    "border border-transparent dark:border-white/5 shadow-[0_2px_8px_rgba(0,0,0,0.06)] dark:shadow-none";
  const textPrimary = "text-gray-900 dark:text-slate-100";
  const textMuted = "text-gray-500 dark:text-slate-400";

  return (
    <div
      className={`rounded-xl p-5 flex flex-col w-full h-full ${cardBg} ${cardBorder}`}
      style={{ minHeight: "400px" }}
    >
      {/* Header */}
      <div className="flex flex-row items-start justify-between mb-6">
        <div>
          <div className="flex items-center space-x-2 mb-1">
            <h2
              className={`font-semibold text-[14px] uppercase tracking-wide ${textPrimary}`}
            >
              Real-Time Grid Load
            </h2>
            <div className="flex items-center space-x-1 bg-green-500/10 px-2 py-0.5 rounded-full">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-500 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
              </span>
              <span className="text-[10px] font-medium text-green-600 dark:text-green-500 uppercase tracking-wider">
                Live
              </span>
            </div>
          </div>
          <div
            key={currentLoad}
            className={`text-[28px] font-bold tabular-nums transition-opacity duration-400 ${textPrimary}`}
          >
            {NUM_FORMATTER.format(currentLoad)}{" "}
            <span className={`text-[16px] font-medium ${textMuted}`}>MW</span>
          </div>
        </div>

        {/* Time Ranges */}
        <div className="flex space-x-1 p-1 bg-gray-100 dark:bg-[#0f1117] rounded-lg">
          {["1H", "6H", "24H", "7D", "30D", "ALL"].map((tr) => (
            <button
              key={tr}
              onClick={() => setTimeRange(tr)}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                timeRange === tr
                  ? "bg-blue-600 text-white"
                  : "text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"
              }`}
            >
              {tr}
            </button>
          ))}
        </div>
      </div>

      {/* Disconnect Banner */}
      {!isConnected && (
        <div className="mb-4 text-xs font-medium text-amber-600 bg-amber-50 dark:bg-amber-900/20 dark:text-amber-400 px-3 py-2 rounded-md border border-amber-200 dark:border-amber-900/50 flex flex-row items-center">
          <svg
            className="w-4 h-4 mr-2 animate-spin"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <circle
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
              strokeDasharray="30"
              strokeLinecap="round"
            ></circle>
          </svg>
          Reconnecting to data stream...
        </div>
      )}

      {/* Chart */}
      <div className="grow w-full relative min-h-75">
        <Line
          id={`main-realtime-chart-${Math.random()}`}
          data={datasetConf}
          options={chartOptions}
        />
      </div>
    </div>
  );
}
