import React from "react";
import { render, screen, act } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import SystemAlertsPanel from "./SystemAlertsPanel";

// Mock Date.now() for predictable timestamp testing
const realDateNow = Date.now.bind(global.Date);
let mockNow;

beforeEach(() => {
  mockNow = new Date("2026-04-10T12:00:00Z").getTime();
  global.Date.now = jest.fn(() => mockNow);
});

afterEach(() => {
  global.Date.now = realDateNow;
});

describe("SystemAlertsPanel Core logic", () => {
  test("renders empty state correctly (All systems operational)", () => {
    render(
      <SystemAlertsPanel liveData={{}} wsStatus="connected" loadHistory={[]} />,
    );
    expect(screen.getByText("All systems operational")).toBeInDocument();
    expect(screen.queryByText("System Alerts")).toBeInDocument();
  });

  test("triggers SYSTEM FAULT when disconnected", () => {
    render(<SystemAlertsPanel liveData={null} wsStatus="disconnected" />);
    expect(screen.getByText("SYSTEM FAULT")).toBeInDocument();
    expect(screen.getByText("Live Data Stream Lost")).toBeInDocument();
    expect(
      screen.getByRole("button", { name: "Reconnect →" }),
    ).toBeInDocument();
  });

  test("triggers Heatwave Warning when temp > 40", () => {
    render(
      <SystemAlertsPanel
        liveData={{ temperature_2m: 41 }}
        wsStatus="connected"
      />,
    );
    expect(screen.getByText("Heatwave Warning")).toBeInDocument();
    expect(
      screen.getByText(/Temperature at 41.0°C exceeds 40°C threshold/),
    ).toBeInDocument();
  });

  test("triggers Data Gap Detected (DATA DELAY) correctly", () => {
    const oldDate = new Date(mockNow - 900001).toISOString(); // > 15 mins ago
    render(
      <SystemAlertsPanel
        liveData={{ simulation_timestamp: oldDate }}
        wsStatus="connected"
      />,
    );
    expect(screen.getByText("DATA DELAY")).toBeInDocument();
    expect(screen.getByText("Data Gap Detected")).toBeInDocument();
  });

  test("triggers Storm Warning suppressing High Wind", () => {
    render(
      <SystemAlertsPanel
        liveData={{ windspeed_10m: 100 }}
        wsStatus="connected"
      />,
    );
    expect(screen.getByText("Storm Warning")).toBeInDocument();
    expect(screen.queryByText("High Wind Alert")).not.toBeInDocument();
  });

  test("triggers Grid Fault logic correctly", () => {
    // Avg target = 100
    render(
      <SystemAlertsPanel
        liveData={{ load: 125, lstm: 100, deeplstm: 100, transformer: 100 }}
        wsStatus="connected"
      />,
    );
    expect(screen.getByText("GRID FAULT RISK")).toBeInDocument();
    expect(screen.getByText(/25.0% deviation/)).toBeInDocument();
    expect(screen.queryByText("GRID ANOMALY")).not.toBeInDocument(); // Suppressed
  });

  test("triggers Demand Spike correctly (>20% increase in 12 ticks)", () => {
    const hist = new Array(13).fill(100);
    const currentLoad = 125; // 25% spike
    render(
      <SystemAlertsPanel
        liveData={{ load: currentLoad }}
        wsStatus="connected"
        loadHistory={hist}
      />,
    );
    expect(screen.getByText("DEMAND SPIKE")).toBeInDocument();
  });
});
