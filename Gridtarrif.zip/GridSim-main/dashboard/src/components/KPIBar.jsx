import React, { useState, useEffect } from "react";

const Skeleton = () => (
  <div className="h-8 bg-slate-200 dark:bg-slate-700 rounded w-24 animate-[shimmer_1.5s_infinite]"></div>
);

const KPIBar = ({ liveData }) => {
  // Peak Today state
  const [peakToday, setPeakToday] = useState(0);
  const [currentDateString, setCurrentDateString] = useState("");

  // Grid Frequency state
  const [gridFreq, setGridFreq] = useState(50.0);

  // Active Model state
  const [activeModel, setActiveModel] = useState(null);

  // Handle Live Data (Current Load & Peak Today)
  useEffect(() => {
    if (liveData && liveData.load && liveData.datetime) {
      const msgDate = new Date(liveData.datetime).toDateString();

      if (msgDate !== currentDateString) {
        // Reset at midnight or first load
        setCurrentDateString(msgDate);
        setPeakToday(liveData.load);
      } else {
        // Update peak
        if (liveData.load > peakToday) {
          setPeakToday(liveData.load);
        }
      }
    }
  }, [liveData, currentDateString, peakToday]);

  // Determine Active/Best Model from Live Metrics
  useEffect(() => {
    if (liveData && liveData.metrics) {
      let best = null;
      let minError = Infinity;
      for (const [modelKey, metrics] of Object.entries(liveData.metrics)) {
        if (metrics) {
          // Prefer sMAPE if available, fallback to MAPE
          const errorVal =
            metrics.smape !== undefined ? metrics.smape : metrics.mape;
          if (errorVal !== undefined && errorVal < minError) {
            minError = errorVal;
            best = modelKey;
          }
        }
      }
      if (best) {
        setActiveModel(best);
      }
    }
  }, [liveData]);

  // Simulate Grid Frequency
  useEffect(() => {
    const interval = setInterval(() => {
      let nextFreq = 50.0 + (Math.random() - 0.5) * 0.06;
      // Clamp to [49.95, 50.05]
      if (nextFreq < 49.95) nextFreq = 49.95;
      if (nextFreq > 50.05) nextFreq = 50.05;
      setGridFreq(nextFreq);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getFreqColor = (freq) => {
    if (freq >= 49.98 && freq <= 50.02) {
      return "text-[#16a34a] dark:text-[#22c55e]"; // Success
    } else if (freq >= 49.9 && freq <= 50.1) {
      return "text-[#d97706] dark:text-[#f59e0b]"; // Warning
    } else {
      return "text-[#dc2626] dark:text-[#ef4444]"; // Error
    }
  };

  const formatLoad = (val) => {
    if (val == null) return null;
    return val.toLocaleString("en-US", { maximumFractionDigits: 0 });
  };

  const modelLabels = {
    lstm: "LSTM",
    deeplstm: "Deep LSTM",
    transformer: "Transformer",
  };

  const modelAccentStyles = {
    lstm: "border-t-[#f59e0b] dark:border-t-[#f59e0b]",
    deeplstm: "border-t-[#8b5cf6] dark:border-t-[#8b5cf6]",
    transformer: "border-t-[#f43f5e] dark:border-t-[#f43f5e]",
  };

  const modelBorderTop =
    activeModel && modelAccentStyles[activeModel]
      ? modelAccentStyles[activeModel]
      : "border-t-transparent dark:border-t-transparent";

  const cardBaseClasses = `
    bg-[#ffffff] shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-[#e5e7eb] border-t-[3px]
    dark:bg-[#161b27] dark:shadow-none dark:border-[rgba(255,255,255,0.06)] dark:border-t-[3px] 
    rounded-[12px] p-[20px] flex flex-col justify-center
  `;

  // Without the 3px explicit top border for the first 3 cards unless required
  const standardCardClasses = `
    bg-[#ffffff] shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-[#e5e7eb]
    dark:bg-[#161b27] dark:shadow-none dark:border-[rgba(255,255,255,0.06)]
    rounded-[12px] p-[20px] flex flex-col justify-center
  `;

  const labelClasses =
    "text-[11px] font-medium uppercase tracking-[0.08em] text-[#6b7280] mb-2";
  const valueBaseClasses = "text-[28px] font-bold tabular-nums font-sans";
  const unitClasses = "text-[14px] font-semibold ml-1 text-[#6b7280]";

  const standardTextClasses = "text-[#111827] dark:text-[#f1f5f9]";
  const amberTextClasses = "text-[#d97706] dark:text-[#f59e0b]";

  return (
    <>
      <style>{`
        @keyframes shimmer {
          0%, 100% { opacity: 0.4; }
          50% { opacity: 1; }
        }
      `}</style>
      <div className="grid grid-cols-4 gap-4 w-full font-['Inter']">
        {/* 1. CURRENT LOAD */}
        <div className={standardCardClasses}>
          <h3 className={labelClasses}>Current Load</h3>
          <div className={`${valueBaseClasses} ${standardTextClasses}`}>
            {liveData?.load ? (
              <>
                {formatLoad(liveData.load)}
                <span className={unitClasses}>MW</span>
              </>
            ) : (
              <Skeleton />
            )}
          </div>
        </div>

        {/* 2. PEAK TODAY */}
        <div className={standardCardClasses}>
          <h3 className={labelClasses}>Peak Today</h3>
          <div className={`${valueBaseClasses} ${amberTextClasses}`}>
            {peakToday ? (
              <>
                {formatLoad(peakToday)}
                <span className={unitClasses}>MW</span>
              </>
            ) : (
              <Skeleton />
            )}
          </div>
        </div>

        {/* 3. GRID FREQUENCY */}
        <div className={standardCardClasses}>
          <h3 className={labelClasses}>Grid Frequency</h3>
          <div className={`${valueBaseClasses} ${getFreqColor(gridFreq)}`}>
            {gridFreq ? (
              <>
                {gridFreq.toFixed(2)}
                <span className={unitClasses}>Hz</span>
              </>
            ) : (
              <Skeleton />
            )}
          </div>
        </div>

        {/* 4. ACTIVE MODEL */}
        <div className={`${cardBaseClasses} ${modelBorderTop}`}>
          <h3 className={labelClasses}>Active Model</h3>
          <div className={`${valueBaseClasses} ${standardTextClasses}`}>
            {activeModel ? (
              modelLabels[activeModel] || activeModel
            ) : (
              <Skeleton />
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default KPIBar;
