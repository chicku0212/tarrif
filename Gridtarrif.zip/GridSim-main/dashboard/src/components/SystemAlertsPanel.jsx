import React from "react";

// Severity Enum for priority sorting
const SEVERITY = {
  CRITICAL: 3,
  WARNING: 2,
  INFO: 1,
};

const formatAlertTime = (timestamp) => {
  if (!timestamp) return "active";
  const d = new Date(timestamp);
  return d.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
};

const SystemAlertsPanel = ({
  liveData,
  wsStatus,
  loadHistory = [],
  onReconnect,
}) => {
  const triggeredAt =
    (liveData?.simulation_timestamp &&
      Number.isFinite(Date.parse(liveData.simulation_timestamp)) &&
      Date.parse(liveData.simulation_timestamp)) ||
    (liveData?.datetime &&
      Number.isFinite(Date.parse(liveData.datetime)) &&
      Date.parse(liveData.datetime)) ||
    0;

  // Derived Alerts Engine
  const generateAlerts = () => {
    const currentAlerts = [];

    const addAlert = (
      key,
      severity,
      badge,
      title,
      body,
      actionText = null,
      onAction = null,
    ) => {
      currentAlerts.push({
        id: key,
        severity,
        badge,
        title,
        body,
        actionText,
        onAction,
        triggeredAt,
      });
    };

    // --- SYSTEM ALERTS ---
    if (wsStatus === "disconnected") {
      addAlert(
        "disconnected",
        SEVERITY.CRITICAL,
        "SYSTEM FAULT",
        "Live Data Stream Lost",
        "WebSocket connection lost. Displayed data may be stale.",
        "Reconnect →",
        onReconnect,
      );
    }

    if (liveData) {
      // --- WEATHER ALERTS ---
      const t = liveData.temperature_2m;
      if (t !== undefined) {
        if (t > 40) {
          addAlert(
            "heatwave",
            SEVERITY.WARNING,
            "WEATHER EVENT",
            "Heatwave Warning",
            `Temperature at ${t.toFixed(1)}°C exceeds 40°C threshold. Expect elevated cooling demand across the grid.`,
          );
        } else if (t < 10) {
          addAlert(
            "coldwave",
            SEVERITY.WARNING,
            "WEATHER EVENT",
            "Cold Wave Warning",
            `Temperature at ${t.toFixed(1)}°C below 10°C threshold. Heating demand surge expected.`,
          );
        }
      }

      // HIGH HUMIDITY
      const rh = liveData.relative_humidity_2m;
      if (rh !== undefined && rh > 90) {
        addAlert(
          "high_humidity",
          SEVERITY.WARNING,
          "WEATHER EVENT",
          "High Humidity Alert",
          `Relative humidity at ${rh.toFixed(1)}%. High moisture levels may affect grid equipment performance.`,
        );
      }

      // WIND
      const wind = liveData.windspeed_10m;
      if (wind !== undefined) {
        if (wind > 90) {
          addAlert(
            "storm",
            SEVERITY.CRITICAL,
            "WEATHER EVENT",
            "Storm Warning",
            `Severe wind speed at ${wind.toFixed(1)} km/h. Risk of transmission line damage and outages.`,
          );
        } else if (wind > 60) {
          // Suppressed by storm condition due to else if
          addAlert(
            "high_wind",
            SEVERITY.WARNING,
            "WEATHER EVENT",
            "High Wind Alert",
            `Wind speed at ${wind.toFixed(1)} km/h. Monitor overhead transmission lines for instability.`,
          );
        }
      }

      // --- GRID ALERTS ---
      const load = liveData.load;
      const preds = [];
      if (liveData.lstm !== undefined) preds.push(liveData.lstm);
      if (liveData.deeplstm !== undefined) preds.push(liveData.deeplstm);
      if (liveData.transformer !== undefined) preds.push(liveData.transformer);

      if (load !== undefined && preds.length > 0) {
        const avgPred = preds.reduce((a, b) => a + b, 0) / preds.length;
        const deviationPct = Math.abs(load - avgPred) / avgPred;

        if (deviationPct > 0.2) {
          addAlert(
            "grid_fault",
            SEVERITY.CRITICAL,
            "GRID FAULT RISK",
            "Grid Fault Risk",
            `Critical ${(deviationPct * 100).toFixed(1)}% deviation between actual load and model consensus. Immediate review required.`,
          );
        } else if (deviationPct > 0.15) {
          // Suppressed if fault risk is active
          addAlert(
            "grid_anomaly",
            SEVERITY.WARNING,
            "GRID ANOMALY",
            "Grid Load Anomaly",
            `Actual load deviates ${(deviationPct * 100).toFixed(1)}% from average model prediction. Investigate sensor telemetry.`,
          );
        }
      }

      // DEMAND SPIKE / DROP (Requires 12 ticks of history = 1 hour)
      if (load !== undefined && loadHistory && loadHistory.length >= 13) {
        const load12TicksAgo = loadHistory[loadHistory.length - 13];
        const changeRatio = (load - load12TicksAgo) / load12TicksAgo;

        if (changeRatio > 0.2) {
          addAlert(
            "demand_spike",
            SEVERITY.CRITICAL,
            "DEMAND SPIKE",
            "Demand Spike Detected",
            `Grid load increased ${(changeRatio * 100).toFixed(1)}% in the last hour. ${Math.round(load)} MW — monitor for overload risk.`,
          );
        } else if (changeRatio < -0.2) {
          addAlert(
            "demand_drop",
            SEVERITY.CRITICAL,
            "DEMAND DROP",
            "Sudden Demand Drop",
            `Grid load decreased ${(-changeRatio * 100).toFixed(1)}% in the last hour. ${Math.round(load)} MW — possible generation fault or feeder outage.`,
          );
        }
      }

      // --- EXISTING ALERTS ---
      // HIGH MAPE
      if (liveData.metrics) {
        const hasHighMape = Object.entries(liveData.metrics).find(
          ([modelName, m]) => Boolean(modelName) && m.mape && m.mape > 25.0,
        );
        if (hasHighMape) {
          addAlert(
            "high_mape",
            SEVERITY.WARNING,
            "MODEL ACCURACY",
            "Prediction Accuracy Degraded",
            `${hasHighMape[0].toUpperCase()} MAPE at ${hasHighMape[1].mape.toFixed(2)}%. Forecasts less reliable.`,
          );
        }
      }

      // PEAK LOAD
      if (load !== undefined && load > 180000) {
        addAlert(
          "peak_load",
          SEVERITY.WARNING,
          "PEAK LOAD",
          "Peak Load Threshold Exceeded",
          `Grid load at ${(load / 1000).toFixed(1)} GW exceeds 180 GW threshold.`,
        );
      }
    }

    return currentAlerts;
  };

  // Sort & Paginate Alerts
  const activeAlerts = generateAlerts().sort((a, b) => {
    if (a.severity !== b.severity) return b.severity - a.severity; // CRITICAL first
    return b.triggeredAt - a.triggeredAt; // Recently triggered first
  });

  const visibleAlerts = activeAlerts.slice(0, 6);
  const hiddenCount = Math.max(0, activeAlerts.length - 6);

  return (
    <div className="flex flex-col flex-1 overflow-hidden rounded-xl p-5 bg-[#ffffff] dark:bg-[#161b27] shadow-[0_2px_8px_rgba(0,0,0,0.06)] dark:shadow-none border border-transparent dark:border-[rgba(255,255,255,0.06)] font-sans min-h-20">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#111827] dark:text-[#f1f5f9]">
          System Alerts
        </h2>
        {activeAlerts.length > 0 && (
          <span className="flex items-center justify-center bg-[#dc2626] dark:bg-[#ef4444] text-white text-[10px] font-bold rounded-full w-4 h-4 tabular-nums">
            {activeAlerts.length}
          </span>
        )}
      </div>

      <div className="flex flex-col flex-1 overflow-y-auto space-y-2">
        {activeAlerts.length === 0 ? (
          <div className="flex flex-col flex-1 h-full items-center justify-center text-center py-6 space-y-2 opacity-0 -translate-y-1.5 animate-[slideIn_250ms_ease-out_forwards]">
            <svg
              className="w-6 h-6 text-[#16a34a] dark:text-[#22c55e]"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M5 13l4 4L19 7"
              />
            </svg>
            <p className="text-[13px] font-medium text-[#16a34a] dark:text-[#22c55e]">
              All systems operational
            </p>
          </div>
        ) : (
          visibleAlerts.map((alert) => (
            <AlertItem key={alert.id} alert={alert} />
          ))
        )}

        {hiddenCount > 0 && (
          <div className="text-center pt-2">
            <span className="text-[11px] font-medium text-[#6b7280]">
              + {hiddenCount} more alerts
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

const AlertItem = ({ alert }) => {
  const isCritical = alert.severity === SEVERITY.CRITICAL;
  const isInfo = alert.severity === SEVERITY.INFO;

  // Base off "Kinetic Observatory" design system map
  // Alert Card Border Radius: 8px. Padding: 12px. Margins handled by parent space-y-2.
  const colors = {
    border: isCritical
      ? "border-l-4 border-[#dc2626] dark:border-[#ef4444]"
      : isInfo
        ? "border-l-4 border-[#2563eb] dark:border-[#3b82f6]"
        : "border-l-4 border-[#d97706] dark:border-[#f59e0b]",

    bg: isCritical
      ? "bg-[rgba(239,68,68,0.06)]"
      : isInfo
        ? "bg-[rgba(59,130,246,0.06)]"
        : "bg-[rgba(245,158,11,0.06)]",

    badge: isCritical
      ? "text-[#dc2626] dark:text-[#ef4444]"
      : isInfo
        ? "text-[#2563eb] dark:text-[#3b82f6]"
        : "text-[#d97706] dark:text-[#f59e0b]",

    title: "text-[#111827] dark:text-[#f1f5f9]",
    body: "text-[#6b7280]",
  };

  return (
    <div
      className={`relative p-3 rounded-lg ${colors.border} ${colors.bg} opacity-0 -translate-y-1.5 animate-[slideIn_250ms_ease-out_forwards] transition-all duration-200`}
      style={{ animationFillMode: "forwards" }}
    >
      <div className="flex justify-between items-start mb-1">
        <span
          className={`text-[10px] font-semibold uppercase tracking-[0.06em] ${colors.badge}`}
        >
          {alert.badge}
        </span>
        <span className="text-[11px] text-[#6b7280] tabular-nums whitespace-nowrap ml-2">
          {formatAlertTime(alert.triggeredAt)}
        </span>
      </div>
      <h3 className={`text-[13px] font-semibold mb-0.5 ${colors.title}`}>
        {alert.title}
      </h3>
      <p className={`text-[12px] font-normal leading-relaxed ${colors.body}`}>
        {alert.body}
      </p>
      {alert.actionText && (
        <button
          onClick={alert.onAction}
          className="mt-2 text-[12px] font-medium text-[#2563eb] dark:text-[#3b82f6] hover:underline"
        >
          {alert.actionText}
        </button>
      )}
    </div>
  );
};

export default SystemAlertsPanel;

// Required for the manual slide-in animation adhering to prefers-reduced-motion
if (typeof document !== "undefined") {
  const styleId = "system-alerts-animations";
  if (!document.getElementById(styleId)) {
    const style = document.createElement("style");
    style.id = styleId;
    style.textContent = `
      @keyframes slideIn {
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }
      @media (prefers-reduced-motion: reduce) {
        .animate-\\[slideIn_250ms_ease-out_forwards\\] {
          animation: none !important;
          opacity: 1 !important;
          transform: none !important;
        }
      }
    `;
    document.head.appendChild(style);
  }
}
