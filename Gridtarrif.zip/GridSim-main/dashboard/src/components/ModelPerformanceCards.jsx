import React, { useState, useEffect, useMemo } from "react";
import { AreaChart, Area, ResponsiveContainer } from "recharts";

// Format helpers
const formatNum = (num, decimals = 2) =>
  num !== undefined && num !== null ? Number(num).toFixed(decimals) : "0.00";

const SkeletonCard = () => (
  <div className="flex-1 rounded-xl bg-white dark:bg-[#161b27] p-5 shadow-[0_2px_8px_rgba(0,0,0,0.06)] dark:shadow-none border border-transparent dark:border-white/5 relative overflow-hidden">
    <div className="absolute inset-0 -translate-x-full animate-[shimmer_1.5s_infinite] bg-linear-to-r from-transparent via-black/5 dark:via-white/5 to-transparent border-t-[3px] border-gray-200 dark:border-gray-800" />
    <div className="h-4 w-24 bg-gray-200 dark:bg-gray-800 rounded mb-4"></div>
    <div className="grid grid-cols-2 gap-4 mb-4">
      <div>
        <div className="h-3 w-12 bg-gray-200 dark:bg-gray-800 rounded mb-1"></div>
        <div className="h-5 w-20 bg-gray-200 dark:bg-gray-800 rounded"></div>
      </div>
      <div>
        <div className="h-3 w-12 bg-gray-200 dark:bg-gray-800 rounded mb-1"></div>
        <div className="h-5 w-20 bg-gray-200 dark:bg-gray-800 rounded"></div>
      </div>
      <div>
        <div className="h-3 w-12 bg-gray-200 dark:bg-gray-800 rounded mb-1"></div>
        <div className="h-5 w-20 bg-gray-200 dark:bg-gray-800 rounded"></div>
      </div>
      <div>
        <div className="h-3 w-12 bg-gray-200 dark:bg-gray-800 rounded mb-1"></div>
        <div className="h-5 w-20 bg-gray-200 dark:bg-gray-800 rounded"></div>
      </div>
      <div>
        <div className="h-3 w-12 bg-gray-200 dark:bg-gray-800 rounded mb-1"></div>
        <div className="h-5 w-20 bg-gray-200 dark:bg-gray-800 rounded"></div>
      </div>
    </div>
    <div className="h-11 w-full bg-gray-200 dark:bg-gray-800 rounded"></div>
  </div>
);

const IndicatorDot = ({ isWorst, isCritical }) => {
  if (!isWorst) return null;
  const color = isCritical
    ? "bg-red-500 dark:bg-[#ef4444]"
    : "bg-amber-500 dark:bg-[#f59e0b]";
  return (
    <span
      className={`inline-block w-1.5 h-1.5 rounded-full ml-1.5 mb-0.5 ${color}`}
    />
  );
};

const PerformanceCard = ({
  modelId,
  title,
  data,
  isBest,
  accentColor,
  worstMetric,
  executionTime,
}) => {
  const { rmse, mae, mape, smape, r2, mape_history = [] } = data;

  const chartData = mape_history.map((val, i) => ({ index: i, value: val }));

  let mapeColor = "text-green-600 dark:text-[#22c55e]";
  if (mape >= 5 && mape <= 10) mapeColor = "text-amber-600 dark:text-[#f59e0b]";
  if (mape > 10) mapeColor = "text-red-600 dark:text-[#ef4444]";

  let smapeColor = "text-green-600 dark:text-[#22c55e]";
  if (smape >= 5 && smape <= 10)
    smapeColor = "text-amber-600 dark:text-[#f59e0b]";
  if (smape > 10) smapeColor = "text-red-600 dark:text-[#ef4444]";

  const showLatencyBadge = executionTime && executionTime > 100;

  return (
    <div
      className="flex-1 flex flex-col rounded-xl bg-white dark:bg-[#161b27] p-5 shadow-[0_2px_8px_rgba(0,0,0,0.06)] dark:shadow-none border border-transparent dark:border-white/5 relative"
      style={{ borderTop: `3px solid ${accentColor}` }}
    >
      <div className="flex justify-between items-start mb-5">
        <h3 className="font-semibold text-[14px] text-gray-900 dark:text-[#f1f5f9]">
          {title}
        </h3>
        <div className="flex gap-2">
          {showLatencyBadge && (
            <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-[#ef4444]">
              High Latency
            </span>
          )}
          {isBest && (
            <span className="px-2 py-0.5 rounded bg-green-500 dark:bg-[#22c55e] text-white text-[10px] uppercase font-bold tracking-wider">
              Best
            </span>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-y-4 gap-x-2 mb-4 grow">
        <div>
          <div className="font-medium text-[11px] uppercase tracking-[0.08em] text-gray-500 dark:text-[#6b7280] flex items-center">
            RMSE
            <IndicatorDot isWorst={worstMetric === "rmse"} isCritical={false} />
          </div>
          <div className="font-semibold text-[15px] tabular-nums text-gray-900 dark:text-[#f1f5f9]">
            {formatNum(rmse)}{" "}
            <span className="text-[11px] text-gray-500 dark:text-[#6b7280]">
              MW
            </span>
          </div>
        </div>
        <div>
          <div className="font-medium text-[11px] uppercase tracking-[0.08em] text-gray-500 dark:text-[#6b7280] flex items-center">
            MAE
            <IndicatorDot isWorst={worstMetric === "mae"} isCritical={false} />
          </div>
          <div className="font-semibold text-[15px] tabular-nums text-gray-900 dark:text-[#f1f5f9]">
            {formatNum(mae)}{" "}
            <span className="text-[11px] text-gray-500 dark:text-[#6b7280]">
              MW
            </span>
          </div>
        </div>
        <div>
          <div className="font-medium text-[11px] uppercase tracking-[0.08em] text-gray-500 dark:text-[#6b7280] flex items-center">
            MAPE
            <IndicatorDot
              isWorst={worstMetric === "mape"}
              isCritical={mape > 10}
            />
          </div>
          <div
            className={`font-semibold text-[15px] tabular-nums ${mapeColor}`}
          >
            {formatNum(mape)}%
          </div>
        </div>
        <div>
          <div className="font-medium text-[11px] uppercase tracking-[0.08em] text-gray-500 dark:text-[#6b7280] flex items-center">
            sMAPE
            <IndicatorDot
              isWorst={worstMetric === "smape"}
              isCritical={smape > 10}
            />
          </div>
          <div
            className={`font-semibold text-[15px] tabular-nums ${smapeColor}`}
          >
            {formatNum(smape)}%
          </div>
        </div>
        <div>
          <div className="font-medium text-[11px] uppercase tracking-[0.08em] text-gray-500 dark:text-[#6b7280] flex items-center">
            R² Score
            <IndicatorDot isWorst={worstMetric === "r2"} isCritical={r2 < 0} />
          </div>
          <div className="font-semibold text-[15px] tabular-nums text-gray-900 dark:text-[#f1f5f9]">
            {formatNum(r2, 4)}
          </div>
        </div>
      </div>

      <div className="h-11 w-full mt-auto -mx-1">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData}>
            <defs>
              <linearGradient
                id={`color-${modelId}`}
                x1="0"
                y1="0"
                x2="0"
                y2="1"
              >
                <stop offset="5%" stopColor={accentColor} stopOpacity={0.25} />
                <stop offset="95%" stopColor={accentColor} stopOpacity={0} />
              </linearGradient>
            </defs>
            <Area
              type="monotone"
              dataKey="value"
              stroke={accentColor}
              strokeWidth={1.5}
              fillOpacity={1}
              fill={`url(#color-${modelId})`}
              isAnimationActive={false}
              activeDot={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default function ModelPerformanceCards({ liveMetrics }) {
  const [sparklineHistory, setSparklineHistory] = useState({
    lstm: [],
    deeplstm: [],
    transformer: [],
  });

  useEffect(() => {
    if (liveMetrics) {
      setSparklineHistory((prev) => {
        let changed = false;
        const next = { ...prev };
        ["lstm", "deeplstm", "transformer"].forEach((mod) => {
          const liveMape = liveMetrics[mod]?.mape;
          if (liveMape !== undefined && prev[mod]) {
            const currentArr = prev[mod];
            if (currentArr[currentArr.length - 1] !== liveMape) {
              next[mod] = [...currentArr, liveMape].slice(-24);
              changed = true;
            }
          }
        });
        return changed ? next : prev;
      });
    }
  }, [liveMetrics]);

  const mergedData = useMemo(() => {
    if (!liveMetrics) return null;
    
    const base = {};

    ["lstm", "deeplstm", "transformer"].forEach((mod) => {
      if (liveMetrics[mod]) {
        const liveMod = liveMetrics[mod];
        base[mod] = {
          ...liveMod,
          mape_history: sparklineHistory[mod]?.length > 0 ? sparklineHistory[mod] : [0],
        };
      } else {
        base[mod] = { rmse: 0, mae: 0, mape: 0, smape: 0, r2: 0, mape_history: [0] };
      }
    });

    return base;
  }, [liveMetrics, sparklineHistory]);

  const bestModel = useMemo(() => {
    if (!mergedData) return null;
    let best = null;
    let minMape = Infinity;
    Object.entries(mergedData).forEach(([key, data]) => {
      if (data.mape > 0 && data.mape < minMape) {
        minMape = data.mape;
        best = key;
      }
    });
    return best;
  }, [mergedData]);

  const worstMetrics = useMemo(() => {
    if (!mergedData) return {};

    // Find best values across all models
    let bestRmse = Infinity;
    let bestMae = Infinity;
    let bestMape = Infinity;
    let bestSmape = Infinity;
    let bestR2 = -Infinity;

    Object.values(mergedData).forEach((d) => {
      if (d.rmse < bestRmse) bestRmse = d.rmse;
      if (d.mae < bestMae) bestMae = d.mae;
      if (d.mape < bestMape) bestMape = d.mape;
      if (d.smape && d.smape < bestSmape) bestSmape = d.smape;
      if (d.r2 > bestR2) bestR2 = d.r2;
    });

    const result = {};

    Object.entries(mergedData).forEach(([mod, d]) => {
      const devRmse = bestRmse > 0 ? (d.rmse - bestRmse) / bestRmse : 0;
      const devMae = bestMae > 0 ? (d.mae - bestMae) / bestMae : 0;
      const devMape = bestMape > 0 ? (d.mape - bestMape) / bestMape : 0;
      const devSmape =
        bestSmape > 0 && d.smape ? (d.smape - bestSmape) / bestSmape : 0;
      const devR2 = Math.max(0, bestR2 - d.r2);

      let maxDev = -Infinity; // Find largest deviation
      let worst = null;

      if (devRmse > maxDev) {
        maxDev = devRmse;
        worst = "rmse";
      }
      if (devMae > maxDev) {
        maxDev = devMae;
        worst = "mae";
      }
      if (devMape > maxDev) {
        maxDev = devMape;
        worst = "mape";
      }
      if (devSmape > maxDev) {
        maxDev = devSmape;
        worst = "smape";
      }
      if (devR2 > maxDev) {
        maxDev = devR2;
        worst = "r2";
      }

      // Only assign if it's deviating meaningfully (>0.5%)
      if (maxDev > 0.005) {
        result[mod] = worst;
      } else {
        result[mod] = null;
      }
    });

    return result;
  }, [mergedData]);

  if (!mergedData) {
    return (
      <div className="flex flex-col md:flex-row gap-6 w-full">
        <SkeletonCard />
        <SkeletonCard />
        <SkeletonCard />
      </div>
    );
  }

  return (
    <div className="flex flex-col md:flex-row gap-6 w-full">
      <PerformanceCard
        modelId="lstm"
        title="LSTM"
        data={mergedData.lstm}
        isBest={bestModel === "lstm"}
        accentColor="#f59e0b"
        worstMetric={worstMetrics.lstm}
        executionTime={mergedData.lstm.executionTime}
      />

      <PerformanceCard
        modelId="deeplstm"
        title="Deep LSTM"
        data={mergedData.deeplstm}
        isBest={bestModel === "deeplstm"}
        accentColor="#8b5cf6"
        worstMetric={worstMetrics.deeplstm}
        executionTime={mergedData.deeplstm.executionTime}
      />

      <PerformanceCard
        modelId="transformer"
        title="Transformer"
        data={mergedData.transformer}
        isBest={bestModel === "transformer"}
        accentColor="#f43f5e"
        worstMetric={worstMetrics.transformer}
        executionTime={mergedData.transformer.executionTime}
      />
    </div>
  );
}
