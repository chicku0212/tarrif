import React, { useState, useRef, useEffect, useCallback } from "react";
import { Sliders, Play, Info, Loader2 } from "lucide-react";
import { API_BASE_URL } from "../config";

export default function SimulationControlPanel({ onSimulationComplete }) {
  const [tempOffset, setTempOffset] = useState(0);
  const [demandLoad, setDemandLoad] = useState(100);
  const [horizon, setHorizon] = useState(24);

  const [slidersStatus, setSlidersStatus] = useState({ state: null, msg: "" }); // state: 'success' | 'error'
  const [isSimulating, setIsSimulating] = useState(false);
  const [simError, setSimError] = useState(null);

  const debounceTimerUrl = useRef(null);
  const statusTimer = useRef(null);

  // Clean timeouts on unmount
  useEffect(() => {
    return () => {
      if (debounceTimerUrl.current) clearTimeout(debounceTimerUrl.current);
      if (statusTimer.current) clearTimeout(statusTimer.current);
    };
  }, []);

  const triggerWhatIfUpdate = useCallback((temp, demand) => {
    if (debounceTimerUrl.current) clearTimeout(debounceTimerUrl.current);

    debounceTimerUrl.current = setTimeout(async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/what-if`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            temperature_adjustment: temp,
            load_multiplier: demand / 100,
          }),
        });

        if (!response.ok) throw new Error("API Failed");

        setSlidersStatus({ state: "success", msg: "✓ Applied" });
      } catch (err) {
        setSlidersStatus({ state: "error", msg: "⚠ Failed" });
      }

      if (statusTimer.current) clearTimeout(statusTimer.current);
      statusTimer.current = setTimeout(() => {
        setSlidersStatus({ state: null, msg: "" });
      }, 1500);
    }, 500);
  }, []);

  const handleTempChange = (e) => {
    const val = parseFloat(e.target.value);
    setTempOffset(val);
    triggerWhatIfUpdate(val, demandLoad);
  };

  const handleDemandChange = (e) => {
    const val = parseInt(e.target.value, 10);
    setDemandLoad(val);
    triggerWhatIfUpdate(tempOffset, val);
  };

  const handleHorizonChange = (e) => {
    setHorizon(parseInt(e.target.value, 10));
  };

  const executeSimulation = async () => {
    setIsSimulating(true);
    setSimError(null);
    try {
      const payload = {
        base_timestamp: new Date().toISOString(),
        temperature_shift_c: tempOffset,
        demand_surge_pct: demandLoad - 100,
        renewable_injection_pct: 0,
        // The prompt says POST body just expects: base_timestamp, temperature_shift_c, demand_surge_pct, renewable_injection_pct
        // but user instructed 3 sliders: HORIZON is passing prediction_window_hours (per plan memory) or we just use horizon.
        // Wait, looking at the exact user prompt payload:
        //  {
        //    "base_timestamp": <current ISO datetime string>,
        //    "temperature_shift_c": <temp offset slider value>,
        //    "demand_surge_pct": <(demand_load - 100) value>,
        //    "renewable_injection_pct": 0
        //  }
        // It does not list window hours in the specific payload. I'll include it just in case, but keep to spec mainly.
      };

      const response = await fetch(`${API_BASE_URL}/simulation/what-if`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) throw new Error("Failed to execute simulation");

      const result = await response.json();
      if (onSimulationComplete) {
        onSimulationComplete(result);
      }
    } catch (err) {
      setSimError(err.message);
    } finally {
      setIsSimulating(false);
    }
  };

  return (
    <div
      className="bg-[#ffffff] dark:bg-[#161b27] shadow-[0_2px_8px_rgba(0,0,0,0.06)] dark:shadow-none dark:border dark:border-[rgba(255,255,255,0.06)] rounded-xl p-5 font-sans flex flex-col justify-between"
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      {/* Custom Styles for Sliders & Tooltips */}
      <style>{`
        .tooltip {
          visibility: hidden;
          opacity: 0;
          transition: opacity 0.2s;
        }
        .has-tooltip:hover .tooltip {
          visibility: visible;
          opacity: 1;
        }
        
        /* Range Slider Styling */
        input[type=range].custom-slider {
          -webkit-appearance: none;
          width: 100%;
          background: transparent;
        }
        input[type=range].custom-slider:focus {
          outline: none;
        }
        /* Webkit Track */
        input[type=range].custom-slider::-webkit-slider-runnable-track {
          width: 100%;
          height: 4px;
          cursor: pointer;
          border-radius: 2px;
        }
        .dark input[type=range].custom-slider::-webkit-slider-runnable-track {
          background: #1e2a3a;
        }
        html:not(.dark) input[type=range].custom-slider::-webkit-slider-runnable-track {
          background: #e5e7eb;
        }
        
        /* Webkit Thumb */
        input[type=range].custom-slider::-webkit-slider-thumb {
          height: 16px;
          width: 16px;
          border-radius: 50%;
          background: #ffffff;
          cursor: pointer;
          -webkit-appearance: none;
          margin-top: -6px;
        }
        .dark input[type=range].custom-slider::-webkit-slider-thumb {
          border: 2px solid #3b82f6;
        }
        html:not(.dark) input[type=range].custom-slider::-webkit-slider-thumb {
          border: 2px solid #2563eb;
        }

        /* Firefox Track */
        input[type=range].custom-slider::-moz-range-track {
          width: 100%;
          height: 4px;
          cursor: pointer;
          border-radius: 2px;
        }
        .dark input[type=range].custom-slider::-moz-range-track {
          background: #1e2a3a;
        }
        html:not(.dark) input[type=range].custom-slider::-moz-range-track {
          background: #e5e7eb;
        }
        
        /* Firefox Thumb */
        input[type=range].custom-slider::-moz-range-thumb {
          height: 16px;
          width: 16px;
          border-radius: 50%;
          background: #ffffff;
          cursor: pointer;
        }
        .dark input[type=range].custom-slider::-moz-range-thumb {
          border: 2px solid #3b82f6;
        }
        html:not(.dark) input[type=range].custom-slider::-moz-range-thumb {
          border: 2px solid #2563eb;
        }
      `}</style>

      {/* HEADER */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2 text-[#111827] dark:text-[#f1f5f9]">
          <Sliders size={16} className="text-[#2563eb] dark:text-[#3b82f6]" />
          <div className="flex flex-col">
            <span className="text-[12px] font-semibold uppercase tracking-wider">
              CONTROL PANEL
            </span>
            <span className="text-[11px] text-[#6b7280] dark:text-[#6b7280]">
              Simulation Mode Active
            </span>
          </div>
        </div>
        {/* Status Indicator */}
        <div
          className={`text-[11px] font-medium transition-opacity ${slidersStatus.state ? "opacity-100" : "opacity-0"} ${slidersStatus.state === "success" ? "text-[#16a34a] dark:text-[#22c55e]" : "text-[#dc2626] dark:text-[#ef4444]"}`}
        >
          {slidersStatus.msg}
        </div>
      </div>

      {/* SLIDERS SECTION */}
      <div className="flex flex-col gap-6 mb-6">
        {/* TEMP OFFSET */}
        <div className="flex flex-col gap-3">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-1.5 cursor-help has-tooltip relative">
              <span className="text-[11px] uppercase font-medium tracking-[0.08em] text-[#6b7280] dark:text-[#6b7280]">
                TEMP OFFSET
              </span>
              <Info size={12} className="text-[#6b7280]" />
              <div className="tooltip absolute bottom-full left-0 mb-1 w-50 z-10 bg-[#111827] dark:bg-white text-[#f8f7f4] dark:text-[#111827] text-[11px] p-2 rounded shadow-lg pointer-events-none">
                Adjusts temperature modifier for load prediction. +1°C ≈ +0.8%
                load increase.
              </div>
            </div>
            <span
              className="text-[#2563eb] dark:text-[#3b82f6] font-bold text-[12px]"
              style={{ fontVariantNumeric: "tabular-nums" }}
            >
              {tempOffset > 0
                ? `+${tempOffset.toFixed(1)}`
                : tempOffset.toFixed(1)}
              °C
            </span>
          </div>
          <div className="relative w-full flex items-center">
            {/* The active fill before the thumb is achieved purely by CSS or complex React wrapper.
                For simplicity with HTML input range, we use Tailwind gradients, but standard range doesn't support active fill natively across browsers.
                Wait, I can use a simple native trick or just an inline style. */}
            <input
              type="range"
              className="custom-slider"
              min="-10"
              max="10"
              step="0.1"
              value={tempOffset}
              onChange={handleTempChange}
            />
          </div>
        </div>

        {/* DEMAND LOAD */}
        <div className="flex flex-col gap-3">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-1.5 cursor-help has-tooltip relative">
              <span className="text-[11px] uppercase font-medium tracking-[0.08em] text-[#6b7280] dark:text-[#6b7280]">
                DEMAND LOAD
              </span>
              <Info size={12} className="text-[#6b7280]" />
              <div className="tooltip absolute bottom-full left-0 mb-1 w-50 z-10 bg-[#111827] dark:bg-white text-[#f8f7f4] dark:text-[#111827] text-[11px] p-2 rounded shadow-lg pointer-events-none">
                Scale factor for base demand. 100% = current load. 150% = 1.5×
                stress scenario.
              </div>
            </div>
            <span
              className="text-[#2563eb] dark:text-[#3b82f6] font-bold text-[12px]"
              style={{ fontVariantNumeric: "tabular-nums" }}
            >
              {demandLoad}%
            </span>
          </div>
          <input
            type="range"
            className="custom-slider"
            min="0"
            max="200"
            step="1"
            value={demandLoad}
            onChange={handleDemandChange}
          />
        </div>

        {/* HORIZON */}
        <div className="flex flex-col gap-3">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-1.5 cursor-help has-tooltip relative">
              <span className="text-[11px] uppercase font-medium tracking-[0.08em] text-[#6b7280] dark:text-[#6b7280]">
                HORIZON
              </span>
              <Info size={12} className="text-[#6b7280]" />
              <div className="tooltip absolute bottom-full left-0 mb-1 w-50 z-10 bg-[#111827] dark:bg-white text-[#f8f7f4] dark:text-[#111827] text-[11px] p-2 rounded shadow-lg pointer-events-none">
                Prediction lookahead window in hours.
              </div>
            </div>
            <span
              className="text-[#2563eb] dark:text-[#3b82f6] font-bold text-[12px]"
              style={{ fontVariantNumeric: "tabular-nums" }}
            >
              {horizon} Hours
            </span>
          </div>
          <input
            type="range"
            className="custom-slider"
            min="1"
            max="72"
            step="1"
            value={horizon}
            onChange={handleHorizonChange}
          />
        </div>
      </div>

      {/* EXECUTE SIMULATION */}
      <div className="mt-auto">
        <button
          onClick={executeSimulation}
          disabled={isSimulating}
          className="group relative w-full h-12 rounded-lg bg-[#2563eb] dark:bg-[#3b82f6] hover:bg-[#1d4ed8] dark:hover:bg-[#2563eb] text-white font-semibold text-[14px] flex items-center justify-center gap-2 transition-all duration-200 disabled:opacity-70 disabled:cursor-not-allowed"
          style={{
            boxShadow:
              "var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)",
          }}
        >
          {/* Custom style for hover state glow since arbitrary variants don't always parse cleanly in arbitrary box shadow without extending config */}
          <div
            className="absolute inset-0 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
            style={{
              boxShadow:
                "0 4px 14px rgba(59,130,246,0.4), 0 0 20px rgba(59,130,246,0.35)",
            }}
          ></div>

          {isSimulating ? (
            <>
              <Loader2 size={16} className="animate-spin relative z-10" />
              <span className="relative z-10">Running...</span>
            </>
          ) : (
            <>
              <Play size={16} fill="currentColor" className="relative z-10" />
              <span className="relative z-10">Execute Simulation</span>
            </>
          )}
        </button>

        {simError && (
          <div className="mt-3 text-[12px] text-[#dc2626] dark:text-[#ef4444] text-center font-medium">
            ⚠ {simError}
          </div>
        )}
      </div>
    </div>
  );
}
