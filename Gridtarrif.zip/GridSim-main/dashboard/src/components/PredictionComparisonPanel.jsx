import React, { useState } from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
} from "chart.js";
import { Line } from "react-chartjs-2";
import { X, ArrowLeftRight, Download } from "lucide-react";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { API_BASE_URL } from "../config";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
);

// Utility for formatting numbers
const formatMW = (val) =>
  new Intl.NumberFormat("en-US").format(Math.round(val));

// Tailwind merge helper
function cn(...inputs) {
  return twMerge(clsx(inputs));
}

export function PredictionComparisonPanel({
  simulations = [],
  onDismiss,
  max = 5,
}) {
  const [comparing, setComparing] = useState(false);
  const [compareData, setCompareData] = useState(null);

  const handleExport = async (simId) => {
    try {
      const response = await fetch(
        `${API_BASE_URL}/simulation/export/${simId}?format=csv`,
      );
      const csvText = await response.text();
      const blob = new Blob([csvText], { type: "text/csv" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `simulation-${simId}.csv`;
      a.click();
      URL.revokeObjectURL(a.href);
    } catch (e) {
      console.error("Export failed:", e);
    }
  };

  const handleCompare = async () => {
    if (comparing) {
      setComparing(false);
      setCompareData(null);
      return;
    }

    try {
      const simIds = simulations
        .map((s) => `sim_ids=${s.simulation_id}`)
        .join("&");
      const response = await fetch(
        `${API_BASE_URL}/simulation/compare?${simIds}`,
      );
      const data = await response.json();
      setCompareData(data);
      setComparing(true);
    } catch (e) {
      console.error("Compare failed:", e);
    }
  };

  const chartData = React.useMemo(() => {
    if (!compareData || compareData.length === 0) return null;
    const labels = Array.from({ length: 24 }, (_, i) => `+${i}h`);
    const colors = ["#f43f5e", "#3b82f6", "#10b981", "#f59e0b", "#8b5cf6"];

    const datasets = compareData.map((sim, i) => {
      let data = Array(24).fill(0);
      if (sim.predictions?.transformer?.hourly_forecast) {
        data = sim.predictions.transformer.hourly_forecast;
      }
      return {
        label: `Sim ${i + 1} (Transformer)`,
        data,
        borderColor: colors[i % colors.length],
        borderWidth: 2,
        tension: 0.1,
        pointRadius: 0,
        pointHoverRadius: 4,
      };
    });

    return { labels, datasets };
  }, [compareData]);

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: "bottom",
        labels: { color: "#94a3b8", font: { size: 11, family: "Inter" } },
      },
      tooltip: { mode: "index", intersect: false },
    },
    scales: {
      x: {
        grid: { color: "rgba(255,255,255,0.05)" },
        ticks: { color: "#94a3b8", font: { size: 10, family: "Inter" } },
      },
      y: {
        grid: { color: "rgba(255,255,255,0.05)" },
        ticks: { color: "#94a3b8", font: { size: 10, family: "Inter" } },
      },
    },
    interaction: { mode: "nearest", axis: "x", intersect: false },
  };

  const isFull = simulations.length >= max;

  if (simulations.length === 0) {
    return (
      <div className="relative rounded-xl border border-dashed border-indigo-500/30 p-12 flex flex-col items-center justify-center text-center transition-colors">
        <div className="absolute top-4 right-4 text-[11px] text-muted-fore">
          Queue: 0/{max} simulations
        </div>
        <ArrowLeftRight className="w-12 h-12 text-slate-500 mb-4" />
        <h3 className="text-[13px] font-semibold uppercase tracking-widest text-slate-500 mb-2">
          Prediction Comparison Overlay
        </h3>
        <p className="text-[12px] text-slate-500 max-w-[320px] mb-6">
          Run a simulation using the controls panel to compare model forecasts
          under modified conditions.
        </p>
        <button
          onClick={() => {
            const btn = document.querySelector(
              '[data-testid="execute-simulation-btn"]',
            );
            if (btn) btn.focus();
          }}
          className="px-4 py-2 text-sm font-medium border border-blue-500 text-blue-500 rounded-md hover:bg-blue-500/10 transition-colors"
        >
          Execute Simulation
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      {/* Header */}
      <div className="flex justify-between items-center px-1">
        <h3 className="text-[13px] font-semibold uppercase tracking-widest text-slate-500">
          Prediction Comparison Overlay
        </h3>
        <div
          className={cn(
            "text-[11px] font-medium",
            isFull ? "text-red-500" : "text-slate-500",
          )}
        >
          Queue: {simulations.length}/{max} simulations{" "}
          {isFull && "(Queue Full)"}
        </div>
      </div>

      <div className="flex flex-col gap-4">
        {simulations.map((sim, index) => (
          <SimulationCard
            key={sim.simulation_id}
            sim={sim}
            index={index}
            onDismiss={() => onDismiss(sim.simulation_id)}
            onExport={() => handleExport(sim.simulation_id)}
          />
        ))}
      </div>

      {simulations.length >= 2 && (
        <div className="mt-2">
          <button
            onClick={handleCompare}
            className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-md transition-colors"
          >
            {comparing ? "Hide Comparison" : "Compare Simulations"}
          </button>

          {comparing && compareData && (
            <div className="mt-4 p-4 rounded-xl bg-white dark:bg-[#161b27] border border-black/5 dark:border-white/5 shadow-[0_2px_8px_rgba(0,0,0,0.06)]">
              <h4 className="text-sm font-semibold mb-4 text-slate-900 dark:text-slate-100">
                Combined Overlay
              </h4>
              <div className="h-62.5 w-full">
                {chartData ? (
                  <Line data={chartData} options={chartOptions} />
                ) : (
                  <div className="h-62.5 text-slate-500 text-sm flex items-center justify-center border border-dashed border-slate-300 dark:border-slate-700 rounded-md">
                    (Chart rendering combined data...)
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function SimulationCard({ sim, index, onDismiss, onExport }) {
  const formatTime = (ts) => {
    const d = new Date(ts);
    const day = d.getDate();
    const month = d.toLocaleString("en-US", { month: "short" });
    const hh = String(d.getHours()).padStart(2, "0");
    const mm = String(d.getMinutes()).padStart(2, "0");
    return `${hh}:${mm} ${day} ${month}`;
  };

  const getDeltaInfo = (base, peak) => {
    const deltaPct = ((peak - base) / base) * 100;
    const absPct = Math.abs(deltaPct);
    let colorClass = "text-green-500 dark:text-green-400";
    if (absPct >= 15) {
      colorClass = "text-red-500 dark:text-red-400";
    } else if (absPct >= 5) {
      colorClass = "text-amber-500 dark:text-amber-400";
    }

    const sign = deltaPct > 0 ? "+" : "";
    return {
      formatted: `${sign}${deltaPct.toFixed(1)}%`,
      colorClass,
    };
  };

  const conditions = [
    ...(sim.conditions_applied?.temperature_shift_c
      ? [
          {
            label: `${sim.conditions_applied.temperature_shift_c > 0 ? "+" : ""}${sim.conditions_applied.temperature_shift_c}°C`,
          },
        ]
      : []),
    ...(sim.conditions_applied?.demand_surge_pct
      ? [
          {
            label: `${sim.conditions_applied.demand_surge_pct > 0 ? "+" : ""}${sim.conditions_applied.demand_surge_pct}% demand`,
          },
        ]
      : []),
    ...(sim.conditions_applied?.renewable_injection_pct
      ? [
          {
            label: `${sim.conditions_applied.renewable_injection_pct > 0 ? "+" : ""}${sim.conditions_applied.renewable_injection_pct}% renewables`,
          },
        ]
      : []),
  ];

  const chartData = {
    labels: Array.from({ length: 24 }, (_, i) => i.toString()),
    datasets: [
      {
        data: sim.predictions?.lstm?.hourly_forecast || [],
        borderColor: "#f59e0b",
        borderWidth: 1.5,
        tension: 0.4,
        pointRadius: 0,
      },
      {
        data: sim.predictions?.deeplstm?.hourly_forecast || [],
        borderColor: "#8b5cf6",
        borderWidth: 1.5,
        tension: 0.4,
        pointRadius: 0,
      },
      {
        data: sim.predictions?.transformer?.hourly_forecast || [],
        borderColor: "#f43f5e",
        borderWidth: 1.5,
        tension: 0.4,
        pointRadius: 0,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false }, tooltip: { enabled: false } },
    scales: {
      x: { display: false },
      y: { display: false },
    },
    animation: { duration: 0 },
    interaction: { mode: "index", intersect: false },
  };

  return (
    <div className="relative flex flex-col p-5 rounded-xl bg-white dark:bg-[#161b27] border border-black/5 dark:border-white/5 shadow-[0_2px_8px_rgba(0,0,0,0.06)] overflow-hidden animate-slide-in">
      <div className="flex justify-between items-center mb-3">
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Simulation #{index + 1}
          </span>
          <span className="text-xs text-slate-500 font-mono">
            {sim.simulation_id.substring(0, 8)}
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-xs text-slate-500">
            {formatTime(sim.base_timestamp)}
          </span>
          <button
            onClick={onDismiss}
            className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {conditions.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-4">
          {conditions.map((cond, i) => (
            <span
              key={i}
              className="px-2 py-0.5 rounded-full border border-slate-200 dark:border-slate-700 text-[11px] text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/50"
            >
              {cond.label}
            </span>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 gap-2 mb-4">
        {["lstm", "deeplstm", "transformer"].map((modelName) => {
          const pred = sim.predictions?.[modelName];
          if (!pred) return null;

          const delta = getDeltaInfo(sim.base_load_mw, pred.peak_mw);
          const nameClass =
            modelName === "lstm"
              ? "text-amber-500"
              : modelName === "deeplstm"
                ? "text-purple-500"
                : "text-rose-500";
          const Name =
            modelName === "lstm"
              ? "LSTM"
              : modelName === "deeplstm"
                ? "DeepLSTM"
                : "Transformer";

          return (
            <div
              key={modelName}
              className="flex justify-between text-sm font-medium tabular-nums"
            >
              <span className={nameClass}>
                {Name} Peak: {formatMW(pred.peak_mw)} MW
              </span>
              <span className={delta.colorClass}>({delta.formatted})</span>
            </div>
          );
        })}
      </div>

      <div className="h-15 w-full mt-2">
        <Line
          id={`sim-chart-${sim.simulation_id || index}-${Math.random()}`}
          data={chartData}
          options={chartOptions}
        />
      </div>

      <div className="mt-3 flex justify-end">
        <button
          onClick={onExport}
          className="flex items-center gap-1 text-[11px] font-medium text-slate-500 hover:text-blue-500 transition-colors uppercase tracking-wider"
        >
          <Download className="w-3 h-3" />
          Export
        </button>
      </div>
    </div>
  );
}
