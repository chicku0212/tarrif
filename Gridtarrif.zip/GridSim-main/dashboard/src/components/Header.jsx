import React, { useState, useEffect } from "react";
import { API_BASE_URL } from "../config";

const Header = ({ wsStatus = "disconnected" }) => {
  const [theme, setTheme] = useState("dark");
  const [healthOk, setHealthOk] = useState(null);

  useEffect(() => {
    const fetchHealth = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/health`);
        if (!response.ok) throw new Error("Network not ok");
        const data = await response.json();
        setHealthOk(data.status === "ok");
      } catch (err) {
        setHealthOk(false);
      }
    };
    fetchHealth();
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === "dark" ? "light" : "dark"));
  };

  let dotColor = "#ef4444";
  let isPulsing = false;

  if (healthOk === false || wsStatus === "disconnected") {
    dotColor = "#ef4444";
    isPulsing = false;
  } else if (wsStatus === "reconnecting") {
    dotColor = "#f59e0b";
    isPulsing = true;
  } else if (healthOk === true && wsStatus === "connected") {
    dotColor = "#22c55e";
    isPulsing = true;
  }

  const isDark = theme === "dark";
  const glassHeaderStyle = {
    fontFamily: '"Inter", sans-serif',
    WebkitBackdropFilter: "blur(18px) saturate(140%)",
    backdropFilter: "blur(18px) saturate(140%)",
  };

  return (
    <header
      className={`header-transition sticky top-0 z-50 w-full h-13 flex items-center justify-between px-4 font-sans backdrop-blur-xl ${
        isDark
          ? "bg-[rgba(22,27,39,0.58)] border-b border-[rgba(255,255,255,0.12)] shadow-[0_8px_28px_rgba(0,0,0,0.32)] text-[#f1f5f9]"
          : "bg-[rgba(255,255,255,0.62)] border-b border-[rgba(255,255,255,0.45)] shadow-[0_8px_24px_rgba(15,23,42,0.12)] text-[#111827]"
      }`}
      style={glassHeaderStyle}
    >
      <style>{`
        @keyframes header-pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.5; transform: scale(0.85); }
        }
        .animate-header-pulse {
          animation: header-pulse 2s ease-in-out infinite;
        }
        .header-transition {
          transition: background 0.25s, color 0.25s, border-color 0.25s, box-shadow 0.25s, backdrop-filter 0.25s;
        }
      `}</style>

      {/* Left: Logo + Text + Status Dot */}
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-6 h-6">
          <svg viewBox="0 0 24 24" fill="none" className="w-full h-full">
            <path
              d="M3 12h4l3-7 4 14 3-7h4"
              stroke={isDark ? "#3b82f6" : "#2563eb"}
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
        <div className="flex items-center gap-1">
          <span className="font-semibold text-[15px] tracking-wide">
            Digital Twin
          </span>
          <span className="font-normal text-[15px] text-[#6b7280]">
            &nbsp;| India Load
          </span>
        </div>
        <div className="flex items-center ml-2">
          <div
            className={`w-2 h-2 rounded-full ${
              isPulsing ? "animate-header-pulse" : ""
            }`}
            style={{ backgroundColor: dotColor }}
            title={
              dotColor === "#22c55e"
                ? "Connected"
                : dotColor === "#f59e0b"
                  ? "Reconnecting"
                  : "Disconnected"
            }
          />
        </div>
      </div>

      {/* Center: Empty */}
      <div className="flex-1"></div>

      {/* Right: Theme Toggle & Avatar */}
      <div className="flex items-center gap-4">
        <button
          onClick={toggleTheme}
          className="flex items-center justify-center w-8 h-8 rounded-full hover:bg-[rgba(128,128,128,0.2)] transition-colors"
          aria-label="Toggle theme"
        >
          {isDark ? (
            <svg
              viewBox="0 0 24 24"
              fill="none"
              className="w-4.5 h-4.5"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="5" />
              <line x1="12" y1="1" x2="12" y2="3" />
              <line x1="12" y1="21" x2="12" y2="23" />
              <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
              <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
              <line x1="1" y1="12" x2="3" y2="12" />
              <line x1="21" y1="12" x2="23" y2="12" />
              <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
              <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
            </svg>
          ) : (
            <svg
              viewBox="0 0 24 24"
              fill="none"
              className="w-4.5 h-4.5"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
            </svg>
          )}
        </button>

        <div
          className={`flex items-center justify-center w-8 h-8 rounded-full font-medium text-[12px] tracking-wide ${
            isDark
              ? "bg-[#0f1117] border border-[rgba(255,255,255,0.06)]"
              : "bg-[#f8f7f4] border border-[rgba(0,0,0,0.06)]"
          }`}
        >
          SO
        </div>
      </div>
    </header>
  );
};

export default Header;
