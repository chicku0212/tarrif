import { useState, useEffect } from "react";
import Header from "./components/Header";
import KPIBar from "./components/KPIBar";
import RealTimeLoadChart from "./components/RealTimeLoadChart";
import ModelPerformanceCards from "./components/ModelPerformanceCards";
import { PredictionComparisonPanel } from "./components/PredictionComparisonPanel";
import SimulationControlPanel from "./components/SimulationControlPanel";
import SystemAlertsPanel from "./components/SystemAlertsPanel";
import { API_BASE_URL, WS_BASE_URL } from "./config";

const API_CONFIG = {
  baseURL: API_BASE_URL,
  wsURL: `${WS_BASE_URL}/ws/dashboard`,
  reconnectDelay: 3000,
  maxReconnectAttempts: 10,
  metricsRefreshInterval: 30000, // 30s
  kpiRefreshInterval: 60000, // 60s
};

/* --- useWebSocket Hook Inline --- */
function useWebSocket(url) {
  const [liveData, setLiveData] = useState(null);
  const [wsStatus, setWsStatus] = useState("reconnecting");
  const [, setReconnectCount] = useState(0);

  useEffect(() => {
    let ws;
    let reconnectTimeoutTracker;

    const connect = () => {
      ws = new WebSocket(url);

      ws.onopen = () => {
        setWsStatus("connected");
        setReconnectCount(0);
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          setLiveData(data);
        } catch (err) {
          console.error("Failed to parse ws data", err);
        }
      };

      ws.onclose = () => {
        setWsStatus("reconnecting");
        setReconnectCount((prev) => {
          const nextCount = prev + 1;
          if (nextCount > API_CONFIG.maxReconnectAttempts) {
            setWsStatus("disconnected");
            return nextCount;
          }
          reconnectTimeoutTracker = setTimeout(
            connect,
            API_CONFIG.reconnectDelay,
          );
          return nextCount;
        });
      };

      ws.onerror = () => {
        ws.close();
      };
    };

    connect();

    return () => {
      clearTimeout(reconnectTimeoutTracker);
      if (ws) {
        ws.onclose = null; // Prevent reconnect on unmount
        ws.close();
      }
    };
  }, [url]);

  return { liveData, wsStatus };
}

function App() {
  const { liveData, wsStatus } = useWebSocket(API_CONFIG.wsURL);
  const [gridStatus, setGridStatus] = useState(null);
  const [historyData, setHistoryData] = useState([]);
  const [predictions24h, setPredictions24h] = useState({
    lstm: [],
    deeplstm: [],
    transformer: [],
  });
  const [simulations, setSimulations] = useState([]);

  // App Mount Fetch
  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const [gridRes, histRes, lstmRes, deepRes, transRes] =
          await Promise.all([
            fetch(`${API_CONFIG.baseURL}/grid/status`).catch(() => ({
              json: () => null,
            })),
            fetch(`${API_CONFIG.baseURL}/history`).catch(() => ({
              json: () => [],
            })),
            fetch(`${API_CONFIG.baseURL}/predictions/24h?model=lstm`).catch(
              () => ({ json: () => [] }),
            ),
            fetch(`${API_CONFIG.baseURL}/predictions/24h?model=deeplstm`).catch(
              () => ({ json: () => [] }),
            ),
            fetch(
              `${API_CONFIG.baseURL}/predictions/24h?model=transformer`,
            ).catch(() => ({ json: () => [] })),
          ]);

        const gridData = await gridRes.json();
        const histData = await histRes.json();
        const lstmData = await lstmRes.json();
        const deepData = await deepRes.json();
        const transData = await transRes.json();

        setGridStatus(gridData);
        setHistoryData(histData);
        setPredictions24h({
          lstm: lstmData,
          deeplstm: deepData,
          transformer: transData,
        });
      } catch (err) {
        console.error("Failed fetching initial data", err);
      }
    };

    fetchInitialData();
  }, []);

  // Theme Toggle via Header -> body [data-theme="dark"] mapping is automatic in our setup if using simple JS or React approach
  // Normally managed in Header but applying class logic

  const handleSimulationComplete = (result) => {
    setSimulations((prev) => [result, ...prev].slice(0, 5));
  };

  const handleDismiss = (id) => {
    setSimulations((prev) => prev.filter((s) => s.simulation_id !== id));
  };

  const handleReconnect = () => {
    window.location.reload(); // Simple reconnect for now
  };

  return (
    <>
      <Header wsStatus={wsStatus} />

      <main style={{ padding: "20px", maxWidth: "none" }}>
        <KPIBar liveData={liveData} />

        <div className="dashboard-grid">
          <div className="main-col">
            <RealTimeLoadChart
              liveData={liveData}
              initialGridStatus={gridStatus}
              historyData={historyData}
              predictions24h={predictions24h}
            />
            <ModelPerformanceCards
              liveMetrics={liveData?.metrics}
            />
            <PredictionComparisonPanel
              simulations={simulations}
              onDismiss={handleDismiss}
            />
          </div>

          <div className="control-col">
            <SimulationControlPanel
              onSimulationComplete={handleSimulationComplete}
            />
            <SystemAlertsPanel
              liveData={liveData}
              wsStatus={wsStatus}
              onReconnect={handleReconnect}
            />
          </div>
        </div>
      </main>
    </>
  );
}

export default App;
