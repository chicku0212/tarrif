# PRD: India Load Tariff Digital Twin Dashboard

## 1. Project Overview
The India Load Tariff Digital Twin is a mission-critical monitoring and simulation platform for grid operators. It provides real-time visibility into grid load, evaluates the performance of multiple forecasting models (LSTM, Deep LSTM, Transformer), and allows for "what-if" scenario simulations to predict future load patterns.

## 2. Target Audience
- **Grid Operators:** Professional users who need high-density, accurate, and real-time data to make operational decisions.
- **Data Scientists:** Users monitoring model performance (RMSE, MAE, MAPE) to ensure forecasting accuracy.

## 3. Core Functionality

### 3.1. Real-Time Monitoring
- **Global KPIs:** Top-level visibility into Current Load (MW), Peak Today (MW), Grid Frequency (Hz), and the currently active "Best" model.
- **Main Load Chart:** A high-precision time-series visualization showing actual load (solid line) versus multiple model predictions (dotted lines).
- **Time Range Control:** Ability to toggle views between 1H, 6H, 24H, 7D, and 30D.

### 3.2. Model Performance Analysis
- **Model Comparison:** Three distinct cards for LSTM, Deep LSTM, and Transformer.
- **Performance Metrics:** RMSE, MAE, MAPE, and R² values.
- **Trend Visualization:** 24H MAPE Trend sparklines with gradient fills for rapid visual assessment of error rates.
- **Intelligent Alerting:** Dynamic badges (Green/Amber/Red) that flag only the worst-performing metric per card to reduce cognitive load.

### 3.3. Simulation & "What-If" Analysis
- **Simulation Controls:** Adjustable parameters for Temperature Offset, Demand Load, and Prediction Horizon.
- **Execution:** A high-visibility "Run Simulation" trigger with visual feedback.
- **Comparison Engine:** A dedicated panel to overlay simulation results against real-time data (supports up to 5 concurrent simulations).

### 3.4. System Awareness
- **Critical Alerts:** Severity-based notification system (Info, Warning, Critical) with actionable deep links.
- **Connectivity Status:** Real-time indicator of the data stream health.

## 4. Visual Strategy
- **Aesthetic:** "The Kinetic Observatory" — A professional, high-fidelity interface inspired by modern technical platforms like Linear and Vercel.
- **Themes:** Supports both high-contrast Dark Mode and a warm, low-strain Light Mode.
- **Typography:** Inter/Geist for technical precision; tabular numbers for data stability.

## 5. Success Metrics
- **Reduction in Operator Cognitive Load:** Measured by the time taken to identify a forecasting anomaly.
- **Simulation Frequency:** Utilization of the "what-if" tool for daily planning.
- **Model Trust:** Alignment between "Best" model indicators and actual grid performance.