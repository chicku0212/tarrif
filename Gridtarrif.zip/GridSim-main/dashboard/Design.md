# Design System Document: The Radiant Utility

## 1. Overview & Creative North Star: "The Kinetic Observatory"
The design system for the India Load Dashboard transforms a standard utility dashboard into a high-end editorial monitoring experience. It balances "Data Density" with "Visual Breathing Room," ensuring that grid operators can monitor complex telemetry without fatigue.

## 2. Visual Principles
- **Technical Precision:** Every pixel serves a purpose. Grids are rigid (12-column), and typography is optimized for legibility.
- **Surface Elevation:** Using shadows and subtle background shifts (Dark: #0f1117 to #161b27) to define hierarchy rather than heavy borders.
- **Subtle Motion:** Entrance animations and pulsing "LIVE" indicators provide a sense of life without being distracting.

## 3. Color Palette

### 3.1. Dark Theme (Primary)
- **Page Background:** `#0f1117` (Near black, slightly warm)
- **Card Surface:** `#161b27` (Deep navy)
- **Primary Accent:** `#3b82f6` (Electric Blue)
- **Borders:** `rgba(255,255,255,0.06)`

### 3.2. Light Theme
- **Page Background:** `#f8f7f4` (Warm off-white)
- **Card Surface:** `#ffffff`
- **Primary Accent:** `#2563eb`
- **Elevation:** `0 2px 8px rgba(0,0,0,0.06)`

### 3.3. Semantic Colors
- **Success/Best:** `#22c55e` (Emerald)
- **Warning:** `#f59e0b` (Amber)
- **Critical:** `#ef4444` (Rose)

## 4. Typography
- **Font Stack:** Inter (Primary), Tabular Numbers for metrics.
- **Headings:** Semibold (600), `#f1f5f9` (Dark) / `#1a1c1e` (Light).
- **Metric Labels:** 11px, Medium (500), All-Caps, 0.08em letter-spacing.
- **Muted Text:** `#6b7280`

## 5. Component Guidelines

### 5.1. Data Cards
- **Border Radius:** 12px.
- **Padding:** 20px uniform.
- **Accent:** 3px top border for model distinction (LSTM: Amber, DeepLSTM: Purple, Transformer: Rose).

### 5.2. Charts
- **Line Weight:** 2px for Actual Load; 1.5px dotted for Predictions.
- **Fills:** Subtle gradients (12-15% opacity) to provide volume without obscuring grid lines.

### 5.3. Interaction
- **Buttons:** Primary buttons feature a subtle glow on hover (`box-shadow: 0 0 20px rgba(59,130,246,0.35)`).
- **Sliders:** 16px diameter thumbs with internal borders for precision.

## 6. Layout
- **12-Column Grid:** 8 columns for core monitoring, 4 columns for peripheral controls.
- **Spacing:** 16px base gap; 24px section gaps.