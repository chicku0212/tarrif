import redis

def test_redis(username=None):
    try:
        client = redis.Redis(
            host="prime-maggot-102211.upstash.io",
            port=6379,
            password="gQAAAAAAAAY9DAAIocDJmM2E1NzkzNzhjZTU0NWMwODFmYTU0MzE0NTU1MzZlN3AyMTAyMjEx",
            username=username,
            ssl=True,
            ssl_cert_reqs="none"
        )
        if client.ping():
            print(f"Success with username: {username}")
    except Exception as e:
        print(f"Failed with username {username}: {e}")

test_redis(None)
test_redis("default")

import redis.asyncio as aioredis
from_url = redis.from_url("rediss://default:gQAAAAAAAAY9DAAIocDJmM2E1NzkzNzhjZTU0NWMwODFmYTU0MzE0NTU1MzZlN3AyMTAyMjEx@prime-maggot-102211.upstash.io:6379?ssl_cert_reqs=none")
try:
    if from_url.ping():
        print("Success with from_url")
except Exception as e:
    print(f"Failed with from_url: {e}")

