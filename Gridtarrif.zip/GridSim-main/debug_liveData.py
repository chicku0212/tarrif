import asyncio
import websockets

async def test():
    async with websockets.connect('ws://localhost:8000/ws/dashboard') as ws:
        msg = await ws.recv()
        print(msg)
        msg2 = await ws.recv()
        print(msg2)

asyncio.run(test())
