import pandas as pd
df = pd.read_csv('INDIAmerged_hourly_load_weather.csv', nrows=5)
print(df.columns)
print(df['datetime'].head())
print(pd.to_datetime(df['datetime']).head())
