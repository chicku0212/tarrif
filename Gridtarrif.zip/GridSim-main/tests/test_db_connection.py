import pytest
import asyncpg
import sys
import os

# Add project root to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.config import settings

@pytest.mark.asyncio
async def test_db_connection():
    print(f"Attempting to connect to DB at {settings.database.host}:{settings.database.port} as {settings.database.user}")
    try:
        dsn = f"postgresql://{settings.database.user}:{settings.database.password}@{settings.database.host}:{settings.database.port}/{settings.database.name}"
        conn = await asyncpg.connect(dsn)
        print("Successfully connected to the database!")
        await conn.close()
        assert True
    except Exception as e:
        print(f"Failed to connect to database: {e}")
        # Skip the test if connection fails due to environment configuration
        pytest.skip(f"Database connection failed (environment issue): {e}")

if __name__ == "__main__":
    # Allow running as script
    import asyncio
    asyncio.run(test_db_connection())

