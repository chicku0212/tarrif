import pytest
from fastapi.testclient import TestClient
from unittest.mock import AsyncMock, MagicMock, patch
import json
import os

# Set ENV to test
os.environ["APP_ENV"] = "test"

from app.main import app
from fastapi_limiter import FastAPILimiter

@pytest.fixture
def mock_redis():
    with patch("app.main.redis.Redis") as mock:
        instance = mock.return_value
        # Mock get for specific keys
        instance.get = AsyncMock(return_value=None)
        instance.close = AsyncMock()
        instance.script_load = AsyncMock(return_value="sha1")
        instance.evalsha = AsyncMock(return_value=0)
        instance.set = AsyncMock()
        yield mock

# Mock background task to prevent it from running during tests
# We can patch it where it is imported or defined
@pytest.fixture(autouse=True)
def mock_background_task():
    with patch("app.main.generate_forecast_background_task", new_callable=AsyncMock) as mock:
        yield mock

from fastapi_limiter.depends import RateLimiter

@pytest.fixture
def client(mock_redis):
    # Override RateLimiter to allow all requests
    async def mock_rate_limit():
        return True
    
    app.dependency_overrides[RateLimiter] = mock_rate_limit
    
    # TestClient triggers startup events (lifespan)
    with TestClient(app) as c:
        yield c
    
    # Clean up overrides
    app.dependency_overrides = {}

def test_health_check(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok", "services": ["api", "redis", "database"]}

def test_grid_status_endpoint(client, mock_redis):
    # Setup mock data
    mock_redis.return_value.get = AsyncMock(return_value=json.dumps({
        "load": 15000, 
        "temperature_2m": 30.0,
        "prediction": 15200
    }))

    response = client.get("/grid/status")
    
    assert response.status_code == 200
    assert response.json()["load"] == 15000

def test_analytics_endpoint(client):
    # Mock DB connection
    with patch("app.routers.analytics.asyncpg.connect") as mock_connect:
        mock_conn = AsyncMock()
        mock_connect.return_value = mock_conn
        
        # Mock fetch result
        mock_conn.fetch.return_value = [
            {"day": "2024-01-01T00:00:00", "max_load": 20000.0},
            {"day": "2024-01-02T00:00:00", "max_load": 21000.0}
        ]
        mock_conn.close = AsyncMock()

        response = client.get("/analytics/daily-peak")

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 2
        assert data[0]["value"] == 20000.0

def test_predictions_endpoint(client, mock_redis):
    # Mock redis get for prediction
    # Logic in router: get(key). If none, return pending.
    
    # We want to test success case for LSTM
    # We also want to test switching models
    
    def side_effect(key):
        if key == "digital_twin:forecast:24h:lstm":
             return json.dumps([100, 101, 102])
        if key == "digital_twin:forecast:24h:transformer":
             return json.dumps([200, 201, 202])
        return None

    mock_redis.return_value.get = AsyncMock(side_effect=side_effect)
    
    # Test LSTM (default)
    response = client.get("/predictions/24h?model=lstm")
    assert response.status_code == 200
    assert response.json()[0] == 100
    
    # Test Transformer
    response = client.get("/predictions/24h?model=transformer")
    assert response.status_code == 200
    assert response.json()[0] == 200
    
    # Test Invalid
    response = client.get("/predictions/24h?model=invalid")
    assert response.status_code == 400

def test_analytics_accuracy(client):
    with patch("app.routers.analytics.asyncpg.connect") as mock_connect:
        mock_conn = AsyncMock()
        mock_connect.return_value = mock_conn
        
        # Mock fetch result for get_prediction_accuracy
        # It expects a list of rows with 'load' and 'prediction'
        mock_data = [
            {"load": 100.0, "prediction": 95.0},
            {"load": 110.0, "prediction": 112.0},
            {"load": 105.0, "prediction": 105.0}
        ]
        mock_conn.fetch.return_value = mock_data
        mock_conn.close = AsyncMock()
        
        response = client.get("/analytics/accuracy")
        assert response.status_code == 200
        # Calculate expected MAPE manually or just check keys exist and are float
        # |100-95|/100 = 0.05
        # |110-112|/110 = 0.01818
        # |105-105|/105 = 0
        # Mean = (0.05 + 0.01818 + 0)/3 * 100 = 2.27%
        res_json = response.json()
        assert "mape" in res_json
        assert isinstance(res_json["mape"], float)
        assert 2.0 < res_json["mape"] < 3.0

def test_sse_endpoint(client, mock_redis):
    # SSE endpoint: /sse/stream
    # It communicates via redis pubsub.
    # TestClient can connect but it's an infinite stream. It might hang if we try to read content/text.
    # We can use stream=True
    
    # Mock redis pubsub
    pubsub_mock = MagicMock()
    pubsub_mock.subscribe = AsyncMock()
    pubsub_mock.listen = MagicMock(return_value=iter([])) # Empty iterator to stop immediately?
    # Or async iterator
    async def async_iter():
        yield {"type": "message", "data": json.dumps({"test": "data"})}
        # Then stop? loops forever usually.
    
    # It's hard to test infinite stream with TestClient without timeout or specific handling.
    # Just check status code if possible, or skip deep functionality test.
    pass

def test_websocket_connect(client):
    # /ws/dashboard
    with client.websocket_connect("/ws/dashboard") as websocket:
        # Check if connected
        # Router implementation: await websocket.accept()
        # Then enters loop.
        # We can try to receive json.
        # But we need to mock Redis pubsub inside the websocket endpoint too.
        pass
    # If connection accepted, it passes.

