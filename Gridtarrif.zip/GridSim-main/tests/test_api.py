import os
import sys
import unittest
from unittest.mock import MagicMock, patch
import pandas as pd
import numpy as np
import torch

# Add src to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from fastapi.testclient import TestClient
from src.api.main import app
from src.preprocessing.pipeline import TariffPreprocessor

client = TestClient(app)

class TestAPI(unittest.TestCase):
    def setUp(self):
        # Reset global variables in app if needed, though patching is better
        pass

    @patch('src.api.main.os.path.exists')
    def test_startup_no_models(self, mock_exists):
        mock_exists.return_value = False
        with TestClient(app) as c:
            response = c.get("/model/info")
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.json(), [])

    @patch('src.api.main.os.path.exists')
    @patch('src.api.main.torch.load')
    @patch('src.api.main.IndiaLSTM')
    @patch('src.api.main.IndiaTransformer')
    @patch('src.api.main.TariffPreprocessor')
    def test_startup_with_models(self, mock_preprocessor_cls, mock_transformer, mock_lstm, mock_torch_load, mock_exists):
        mock_exists.return_value = True
        
        # Mock preprocessor instance
        mock_preprocessor_instance = MagicMock()
        mock_preprocessor_instance.features = ["feature1"]
        mock_preprocessor_cls.return_value = mock_preprocessor_instance
        
        # Mock models
        mock_lstm_instance = MagicMock()
        mock_lstm.return_value = mock_lstm_instance
        mock_lstm_instance.eval.return_value = None
        
        mock_transformer_instance = MagicMock()
        mock_transformer.return_value = mock_transformer_instance
        mock_transformer_instance.eval.return_value = None

        with TestClient(app) as c:
            response = c.get("/model/info")
            self.assertEqual(response.status_code, 200)
            data = response.json()
            self.assertEqual(len(data), 2)
            names = [d['name'] for d in data]
            self.assertIn("IndiaLSTM", names)
            self.assertIn("IndiaTransformer", names)

    @patch('src.api.main.lstm_model')
    @patch('src.api.main.lstm_preprocessor')
    def test_predict_lstm(self, mock_preprocessor, mock_model):
        # Setup mocks
        mock_tensor = torch.tensor([[0.5]])
        mock_model.return_value = mock_tensor
        
        mock_preprocessor.preprocess.return_value = torch.ones(1, 1, 11)
        mock_preprocessor.inverse_transform.return_value = np.array([10000.0])
        
        # We need to ensure the app uses these mocks. 
        # Since they are imported in main, we need to patch them correctly.
        # But TestClient might have already imported main. 
        # So we should patch where they are used.
        
        with patch('src.api.main._predict') as mock_predict:
            mock_predict.return_value = np.array([10000.0])
            
            # Since global variables in main.py are populated at startup, 
            # we need to simulate them being non-None for the endpoint check
            with patch('src.api.main.lstm_model', new=MagicMock()), \
                 patch('src.api.main.lstm_preprocessor', new=MagicMock()):
                 
                payload = [{
                    "hour": 10, "day_of_month": 1, "dayofweek": 0, "day_of_year": 1, "month": 1, "year": 2024,
                    "week_of_year": 1, "temperature_2m": 25.0, "relative_humidity_2m": 50.0, "windspeed_10m": 5.0, "dew_point_2m": 15.0
                }]
                
                response = client.post("/predict/lstm", json=payload)
                self.assertEqual(response.status_code, 200)
                result = response.json()
                self.assertEqual(len(result), 1)
                self.assertEqual(result[0]['load'], 10000.0)
                self.assertEqual(result[0]['model_name'], "LSTM")

if __name__ == '__main__':
    unittest.main()
