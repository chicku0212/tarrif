
import pytest
import asyncio
import logging
from datetime import datetime, timedelta
from src.state_manager import StateManager, DigitalTwinState
from src.config import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("TestStateEngine")

@pytest.mark.asyncio
async def test_engine():
    logger.info("Starting State Engine Validation...")
    
    # Initialize Manager
    manager = StateManager()
    await manager.connect()
    
    # Test Data
    test_data = {
        "timestamp": datetime.now().isoformat(),
        "load": 15000.5,
        "prediction": 15100.0,
        "temperature_2m": 30.5,
        "relative_humidity_2m": 60.0,
        "windspeed_10m": 5.5,
        "dew_point_2m": 20.0
    }
    
    # 1. Test Update State
    logger.info("Testing update_state()...")
    await manager.update_state(test_data)
    
    # 2. Test Get State from Redis
    logger.info("Testing get_current_state()...")
    state = await manager.get_current_state()
    assert state is not None
    assert state.load == 15000.5
    assert state.variance == 99.5 # 15100 - 15000.5
    logger.info(f"State Retrieved: {state}")
    
    # 3. Test Snapshot
    logger.info("Testing create_snapshot()...")
    await manager.create_snapshot()
    
    # 4. Test Staleness (Simulate old data)
    logger.info("Testing staleness check...")
    # Manually set old timestamp
    await manager.redis_client.set("digital_twin:last_update", (datetime.now() - timedelta(minutes=20)).isoformat())
    await manager.check_staleness()
    
    logger.info("Validation Complete!")

if __name__ == "__main__":
    asyncio.run(test_engine())
