from fastapi.testclient import TestClient
from src.simulator import router, simulator

# Create a test client for the router
# We need to wrap it in a FastAPI app to test it properly with TestClient if it's just a router
from fastapi import FastAPI
app = FastAPI()
app.include_router(router)

client = TestClient(app)

def test_read_root():
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "running"
    assert "modifiers" in data
    assert data["modifiers"]["temperature_adjustment"] == 0.0
    assert data["modifiers"]["load_multiplier"] == 1.0

def test_what_if_endpoint():
    # 1. Set Modifiers
    payload = {
        "temperature_adjustment": 5.0,
        "load_multiplier": 1.1
    }
    response = client.post("/what-if", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "updated"
    assert data["modifiers"]["temperature_adjustment"] == 5.0
    assert data["modifiers"]["load_multiplier"] == 1.1
    
    # 2. Verify Internal State
    assert simulator.modifiers["temperature_adjustment"] == 5.0
    assert simulator.modifiers["load_multiplier"] == 1.1

    # 3. Reset
    reset_payload = {
        "temperature_adjustment": 0.0,
        "load_multiplier": 1.0
    }
    response = client.post("/what-if", json=reset_payload)
    assert response.status_code == 200
    assert simulator.modifiers["temperature_adjustment"] == 0.0
    assert simulator.modifiers["load_multiplier"] == 1.0
