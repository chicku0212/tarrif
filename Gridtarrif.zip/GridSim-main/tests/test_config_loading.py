import os
import sys
import unittest
from pathlib import Path

# Add project root to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.config import AppConfig

class TestConfigLoading(unittest.TestCase):
    def setUp(self):
        # Clear env vars that might interfere
        for key in ["APP_ENV", "ENV", "APP_DB_HOST", "DB_HOST", "APP_SIMULATOR__SPEED_MULTIPLIER"]:
            if key in os.environ:
                del os.environ[key]
        # Clear config cache
        AppConfig._yaml_config_data = {}

    def test_default_loading(self):
        # Should default to dev
        config = AppConfig.load_config()
        self.assertEqual(config.env, "dev")
        # In dev.yaml, speed_multiplier is 3600.0
        self.assertEqual(config.simulator.speed_multiplier, 3600.0)

    def test_env_override(self):
        # Override ENV to prod
        os.environ["APP_ENV"] = "prod"
        config = AppConfig.load_config()
        # In prod.yaml, speed_multiplier is 1.0 (Real-time)
        self.assertEqual(config.simulator.speed_multiplier, 1.0)
        self.assertEqual(config.database.host, "prod-db.internal")

    def test_env_var_precedence_isolation(self):
        # Test if Env vars override YAML
        os.environ["APP_SIMULATOR__SPEED_MULTIPLIER"] = "9999.0"
        
        # Force reload (customise_sources will reread ENV)
        config = AppConfig()
        print(f"DEBUG: Simulator config: {config.simulator}")
        self.assertEqual(config.simulator.speed_multiplier, 9999.0)

if __name__ == '__main__':
    unittest.main()
