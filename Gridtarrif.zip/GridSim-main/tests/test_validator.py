import unittest
import pandas as pd
import numpy as np
import sys
import os

# Add src to path for import
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from validator import DataValidator

class TestDataValidator(unittest.TestCase):
    def setUp(self):
        self.validator = DataValidator()

    def test_check_missing_values(self):
        df = pd.DataFrame({
            'a': [1, 2, np.nan],
            'b': [4, 5, 6]
        })
        missing = self.validator.check_missing_values(df)
        self.assertEqual(missing, {'a': 1})

    def test_check_outliers(self):
        # Create data with obvious outlier (mean~0, std~1, check > 3)
        data = np.random.normal(0, 1, 100)
        data[0] = 100 # Huge outlier
        df = pd.DataFrame({'val': data})
        
        outliers = self.validator.check_outliers(df, ['val'], threshold=3.0)
        self.assertIn('val', outliers)
        self.assertGreaterEqual(outliers['val'], 1)

    def test_check_continuity(self):
        # Create timestamps with a gap
        dates = pd.to_datetime(['2023-01-01 00:00:00', '2023-01-01 01:00:00', '2023-01-01 03:00:00'])
        df = pd.DataFrame({'timestamp': dates, 'val': [1, 2, 3]})
        
        missing = self.validator.check_continuity(df, 'timestamp', freq='h')
        self.assertEqual(len(missing), 1)
        self.assertEqual(missing[0], pd.Timestamp('2023-01-01 02:00:00'))

if __name__ == '__main__':
    unittest.main()
