
import pytest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import sys
import os

# Add project root to sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.simulation_engine import SimulationEngine, SimulationConfig, ScenarioConfig, ScenarioType
from src.model_executor import ModelExecutor

@pytest.mark.asyncio
async def test_simulation_engine_end_to_end():
    # Setup
    executor = ModelExecutor()
    # Check if models are loaded, warn if not (but don't fail test if environment issue, 
    # though for strict testing we should fail. We'll skip if no models found.)
    if not executor.models:
        pytest.skip("No models loaded, skipping end-to-end test")

    engine = SimulationEngine(executor)
    
    start_time = datetime(2024, 1, 1, 0, 0, 0)
    hours = 24
    
    # Dummy Input
    rows = []
    current = start_time
    for _ in range(hours):
        rows.append({
            "timestamp": current,
            "temperature_2m": 25.0,
            "relative_humidity_2m": 50.0,
            "windspeed_10m": 10.0,
            "dew_point_2m": 15.0,
            "region": "India"
        })
        current += timedelta(hours=1)
    
    df_initial = pd.DataFrame(rows)
    # Feature engineering for dummy
    df_initial['timestamp'] = pd.to_datetime(df_initial['timestamp'])
    dt = df_initial['timestamp'].dt
    df_initial['hour'] = dt.hour
    df_initial['day_of_month'] = dt.day
    df_initial['dayofweek'] = dt.dayofweek
    df_initial['day_of_year'] = dt.dayofyear
    df_initial['month'] = dt.month
    df_initial['year'] = dt.year
    df_initial['week_of_year'] = dt.isocalendar().week.astype(int)

    # 1. Baseline
    config_base = SimulationConfig(
        start_time=start_time,
        hours=hours,
        model_type="LSTM", # Assuming LSTM is always there if models loaded
        scenarios=[]
    )
    result_base = await engine.run(config_base, df_initial)
    assert len(result_base.results) == hours
    load_base = np.array([r['predicted_load'] for r in result_base.results])

    # 2. Temperature Scenario
    # This should modify input before prediction. 
    # Hard to check input modification inside engine without mocking, 
    # but we can check result difference if model is sensitive.
    config_temp = SimulationConfig(
        start_time=start_time,
        hours=hours,
        model_type="LSTM",
        scenarios=[ScenarioConfig(type=ScenarioType.TEMPERATURE, magnitude=10.0)]
    )
    result_temp = await engine.run(config_temp, df_initial)
    load_temp = np.array([r['predicted_load'] for r in result_temp.results])
    
    # Check if results differ (assuming model uses temp)
    # If model is robust/insensitive this might fail, but usually +10C shifts load.
    assert not np.allclose(load_base, load_temp), "Temperature scenario yielded identical results to baseline"

    # 3. Festival Scenario (Post-processing)
    # This we can mathematically verify because it's deterministic post-processing
    magnitude = 20.0 # +20%
    config_fest = SimulationConfig(
        start_time=start_time,
        hours=hours,
        model_type="LSTM",
        scenarios=[ScenarioConfig(type=ScenarioType.FESTIVAL, magnitude=magnitude)]
    )
    result_fest = await engine.run(config_fest, df_initial)
    load_fest = np.array([r['predicted_load'] for r in result_fest.results])
    
    expected_fest = load_base * (1.0 + magnitude/100.0)
    assert np.allclose(load_fest, expected_fest, rtol=1e-5), "Festival scenario did not scale scale load correctly"

if __name__ == "__main__":
    # Allow running directly
    import asyncio
    asyncio.run(test_simulation_engine_end_to_end())
