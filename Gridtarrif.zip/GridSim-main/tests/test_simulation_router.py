from fastapi.testclient import TestClient
from app.main import app
from datetime import datetime, timedelta

client = TestClient(app)

def test_run_simulation_basic():
    """
    Test the basic functionality of the /simulation/run endpoint.
    Retrieves a 24-hour simulation using the LSTM model.
    """
    # Define payload
    payload = {
        "start_time": datetime.now().isoformat(),
        "hours": 24,
        "scenarios": [],
        "model_type": "LSTM",
        "speed_multiplier": 1.0
    }
    
    response = client.post("/simulation/run", json=payload)
    
    if response.status_code != 200:
        print(f"\nResponse Error: {response.text}")
    
    # Assertions
    assert response.status_code == 200
    data = response.json()
    
    assert "simulation_id" in data
    assert "results" in data
    assert len(data["results"]) == 24
    
    # Check result structure
    first_result = data["results"][0]
    assert "timestamp" in first_result
    assert "predicted_load" in first_result
    assert isinstance(first_result["predicted_load"], float)

def test_run_simulation_with_scenarios():
    """
    Test running a simulation with a temperature scenario.
    """
    payload = {
        "start_time": datetime.now().isoformat(),
        "hours": 24,
        "scenarios": [
            {
                "type": "temperature",
                "magnitude": 5.0,
                "start_offset_hours": 0,
                "duration_hours": 24
            }
        ],
        "model_type": "LSTM"
    }
    
    response = client.post("/simulation/run", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert len(data["results"]) == 24

def test_invalid_model_type():
    """
    Test that an invalid model type returns an error (or handles gracefully if logic allows, 
    but ModelExecutor executes strict check).
    """
    payload = {
        "start_time": datetime.now().isoformat(),
        "hours": 24,
        "model_type": "INVALID_MODEL"
    }
    
    response = client.post("/simulation/run", json=payload)
    # Expect 500 because ModelExecutor raises ValueError which is caught as Exception -> 500
    assert response.status_code == 500
