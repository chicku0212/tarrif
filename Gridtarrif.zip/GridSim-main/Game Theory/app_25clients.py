import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ==========================================
# 1. DATA LOADING & PREPARATION
# ==========================================
# Get the absolute path dynamically so it doesn't break
script_dir = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(script_dir, "INDIAhourly_load.csv")

try:
    df = pd.read_csv(file_path)
except FileNotFoundError:
    print(f"Error: Could not find INDIAhourly_load.csv in {script_dir}")
    print("Please ensure the CSV is in the exact same folder as this script.")
    exit()

# Handle different CSV formatting
if len(df.columns) == 1:
    df[['datetime', 'load_MW']] = df.iloc[:, 0].str.split(',', expand=True)
else:
    df.rename(columns={df.columns[0]: "datetime", df.columns[1]: "load_MW"}, inplace=True)

df["datetime"] = pd.to_datetime(df["datetime"])
df["load_MW"] = df["load_MW"].astype(float)

# Filter for October 2024
df_oct = df[(df["datetime"].dt.year == 2024) & (df["datetime"].dt.month == 10)].copy()
df_oct = df_oct.sort_values("datetime")

# ==========================================
# 2. MARKET PARTICIPANT PARAMETERS
# ==========================================
suppliers = {
    "Hydro (Storage)": {"capacity_mw": 200, "marginal_cost": 1.15, "ramp_rate": "Very High"},
    "Solar Farm": {"capacity_mw": 250, "marginal_cost": 2.50, "ramp_rate": "Low"},
    "Wind Farm": {"capacity_mw": 100, "marginal_cost": 3.05, "ramp_rate": "Low"},
    "Nuclear (PHWR)": {"capacity_mw": 700, "marginal_cost": 3.60, "ramp_rate": "Very Low"},
    "Coal (Supercritical)": {"capacity_mw": 660, "marginal_cost": 3.60, "ramp_rate": "Medium"},
    "Biomass": {"capacity_mw": 15, "marginal_cost": 6.25, "ramp_rate": "Medium"},
    "Gas (CCGT)": {"capacity_mw": 250, "marginal_cost": 10.00, "ramp_rate": "High"}
}

consumers = {
    "Industrial Heavy": {"base_share": 0.25, "elasticity": "Low"},
    "Agriculture": {"base_share": 0.18, "elasticity": "High"},
    "Residential Urban": {"base_share": 0.17, "elasticity": "Medium"},
    "Industrial Medium": {"base_share": 0.15, "elasticity": "Medium"},
    "Residential Rural": {"base_share": 0.09, "elasticity": "Medium"},
    "Commercial Large": {"base_share": 0.05, "elasticity": "Medium-High"},
    "Commercial Small": {"base_share": 0.04, "elasticity": "Medium"},
    "Public Infra (Rail/Air)": {"base_share": 0.03, "elasticity": "Low"},
    "EV Charging": {"base_share": 0.02, "elasticity": "Very High"},
    "Data Centers": {"base_share": 0.02, "elasticity": "Medium"}
}

# Translate elasticity strings into mathematical flexibility percentages
elasticity_map = {"Low": 0.02, "Medium": 0.08, "Medium-High": 0.15, "High": 0.25, "Very High": 0.40}

# ==========================================
# 3. BASELINE PRICING & SCALING
# ==========================================
flat_tariff = 7000  # ₹/MWh
min_load = df_oct["load_MW"].min()
max_load = df_oct["load_MW"].max()

# Create normalized load (0 to 1)
df_oct["load_norm"] = (df_oct["load_MW"] - min_load) / (max_load - min_load)

# FIXED PRICING LOGIC: Price goes UP when demand is high (80% to 120% of flat tariff)
# REVISED PRICING LOGIC: Price ranges from 88% (off-peak) to 98% (peak)
df_oct["retail_price"] = flat_tariff * (0.95 + 0.04 * df_oct["load_norm"])
avg_retail_price = df_oct["retail_price"].mean()

# Scale supplier capacities to match the city's peak load + 15% safety margin
total_dict_capacity = sum(s["capacity_mw"] for s in suppliers.values())
scale_factor = (max_load * 1.15) / total_dict_capacity

for name in suppliers:
    suppliers[name]["scaled_capacity"] = suppliers[name]["capacity_mw"] * scale_factor
    suppliers[name]["total_generation"] = 0
    suppliers[name]["total_revenue"] = 0

for name in consumers:
    consumers[name]["total_consumption"] = 0
    consumers[name]["old_cost"] = 0
    consumers[name]["dynamic_cost"] = 0

# Sort suppliers by Merit Order (Cheapest to Most Expensive)
merit_order = sorted(suppliers.keys(), key=lambda x: suppliers[x]["marginal_cost"])

# ==========================================
# 4. HOURLY MARKET SIMULATION
# ==========================================
hourly_wholesale_prices = []
actual_system_load = []

for idx, row in df_oct.iterrows():
    base_system_load = row["load_MW"]
    current_retail_price = row["retail_price"]
    
    # How far is the current price from the average? (Used for demand response)
    price_ratio = (current_retail_price - avg_retail_price) / avg_retail_price 
    
    # --- A. CONSUMER DEMAND RESPONSE ---
    hour_actual_load = 0
    for c_name, c_data in consumers.items():
        base_demand = base_system_load * c_data["base_share"]
        
        # Elasticity: Decrease load if price is high, increase if price is low
        flexibility = elasticity_map[c_data["elasticity"]]
        demand_adjustment = base_demand * (price_ratio * flexibility * -1)
        final_demand = max(0, base_demand + demand_adjustment) # Prevent negative load
        
        consumers[c_name]["total_consumption"] += final_demand
        consumers[c_name]["old_cost"] += base_demand * flat_tariff
        consumers[c_name]["dynamic_cost"] += final_demand * current_retail_price
        
        hour_actual_load += final_demand
        
    actual_system_load.append(hour_actual_load)
    
    # --- B. SUPPLIER MERIT ORDER DISPATCH ---
    remaining_load = hour_actual_load
    clearing_price_kwh = 0
    
    # Find the clearing price (Marginal pricing)
    for s_name in merit_order:
        capacity = suppliers[s_name]["scaled_capacity"]
        if remaining_load > 0:
            generation = min(remaining_load, capacity)
            remaining_load -= generation
            clearing_price_kwh = suppliers[s_name]["marginal_cost"]
            
    clearing_price_mwh = clearing_price_kwh * 1000  # Convert to ₹/MWh
    hourly_wholesale_prices.append(clearing_price_mwh)
    
    # Calculate revenue for suppliers based on the clearing price
    remaining_load_rev = hour_actual_load
    for s_name in merit_order:
        capacity = suppliers[s_name]["scaled_capacity"]
        if remaining_load_rev > 0:
            generation = min(remaining_load_rev, capacity)
            suppliers[s_name]["total_generation"] += generation
            suppliers[s_name]["total_revenue"] += generation * clearing_price_mwh
            remaining_load_rev -= generation

df_oct["actual_load_MW"] = actual_system_load
df_oct["wholesale_price"] = hourly_wholesale_prices

# ==========================================
# 5. GENERATE TABLES & REPORTS
# ==========================================
pd.options.display.float_format = '{:,.2f}'.format

# Build Supplier DataFrame
supplier_df = pd.DataFrame([{
    "Supplier": name,
    "Marginal Cost (₹/kWh)": data["marginal_cost"],
    "Total Generation (MWh)": data["total_generation"],
    "Total Revenue (₹)": data["total_revenue"]
} for name, data in suppliers.items()])

# Build Consumer DataFrame
total_consumer_profit = 0
consumer_table = []
for name, data in consumers.items():
    savings = data["old_cost"] - data["dynamic_cost"]
    total_consumer_profit += savings
    consumer_table.append({
        "Consumer": name,
        "Elasticity": data["elasticity"],
        "Total Consumption (MWh)": data["total_consumption"],
        "Old Cost (₹)": data["old_cost"],
        "Dynamic Cost (₹)": data["dynamic_cost"],
        "Consumer Savings (₹)": savings
    })
consumer_df = pd.DataFrame(consumer_table)

# ==========================================
# 6. VISUALIZATION & OUTPUT
# ==========================================
plt.figure(figsize=(14,5))
plt.plot(df_oct["datetime"], df_oct["load_MW"], label="Original Baseline Load", alpha=0.5, linestyle="--")
plt.plot(df_oct["datetime"], df_oct["actual_load_MW"], label="Actual Load (After Demand Response)", color="blue")
plt.title("City Load (MW) - October 2024: Showing Demand Response")
plt.legend()
plt.grid(True)
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

plt.figure(figsize=(14,5))
plt.plot(df_oct["datetime"], df_oct["retail_price"], label="Retail Price (₹/MWh)", color="red")
plt.plot(df_oct["datetime"], df_oct["wholesale_price"], label="Wholesale Clearing Price (₹/MWh)", color="green", alpha=0.7)
plt.title("Market Pricing Overview")
plt.legend()
plt.grid(True)
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

print("\n" + "="*50)
print("🎯 TOTAL CONSUMER IMPACT")
print("="*50)
print(f"Total Consumer Savings (₹): {total_consumer_profit:,.2f}")
print(f"Total Consumer Savings (Crore ₹): {total_consumer_profit/1e7:,.2f} Crore")

print("\n" + "="*50)
print("🏭 SUPPLIER REVENUE (Sorted by Revenue)")
print("="*50)
print(supplier_df.sort_values("Total Revenue (₹)", ascending=False).to_string(index=False))

print("\n" + "="*50)
print("👥 CONSUMER SAVINGS (Sorted by Savings)")
print("="*50)
print(consumer_df.sort_values("Consumer Savings (₹)", ascending=False).to_string(index=False))