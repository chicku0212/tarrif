
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.optimize import minimize, Bounds
import warnings

warnings.filterwarnings("ignore")
sns.set_theme(style="whitegrid")

# ---------------------------------------------------------------
def load_exact_data(csv_path="INDIAhourly_load.csv"):
    df = pd.read_csv(csv_path)
    df = df.rename(columns={df.columns[0]: 'ds', df.columns[1]: 'y'})
    df['ds'] = pd.to_datetime(df['ds'])

    if df['y'].dtype == object:
        df['y'] = df['y'].astype(str).str.replace(',', '')

    df['y'] = pd.to_numeric(df['y'], errors='coerce')
    df = df.dropna(subset=['ds', 'y'])

    # Convert to MW
    df['y'] = df['y'] / 1000.0

    global_min = df['y'].min()
    global_max = df['y'].max()

    may_data = df[(df['ds'].dt.year == 2024) & (df['ds'].dt.month == 5)].copy()
    oct_data = df[(df['ds'].dt.year == 2024) & (df['ds'].dt.month == 10)].copy()

    return may_data, oct_data, global_min, global_max


# ---------------------------------------------------------------
FLAT_RATE = 7000.0
P_MIN = 3000.0  
P_MAX = 10000.0
ALPHA = 5000.0

FAIRNESS_WEIGHT = 100.0 

def optimize_game_theory_tariffs(month_df, global_min, global_max):
    if month_df.empty:
        return month_df

    optimized_prices = []
    simulated_load_all = []

    for i in range(0, len(month_df), 24):
        daily_load = month_df['y'].iloc[i:i+24].values

        if len(daily_load) == 24:

            def objective(prices):
                prices = np.array(prices)
                elasticity_factor = np.exp(-(prices - FLAT_RATE) / ALPHA)
                simulated_load = daily_load * np.clip(elasticity_factor, 0.01, 1.0)

                revenue = np.sum(prices * simulated_load)

                load_ratio = (daily_load - global_min) / (global_max - global_min + 1e-6)
                natural_trend = P_MIN + (P_MAX - P_MIN) * (load_ratio ** 4.0)

                fairness_penalty = FAIRNESS_WEIGHT * np.sum((prices - natural_trend)**2)

                return -(revenue - fairness_penalty) / 1000000.0

            res = minimize(
                objective,
                x0=np.full(24, FLAT_RATE),
                bounds=Bounds([P_MIN]*24, [P_MAX]*24),
                method='L-BFGS-B'
            )

            best_prices = res.x
            optimized_prices.extend(best_prices)

            elastic_fact = np.exp(-(best_prices - FLAT_RATE) / ALPHA)
            sim_load = daily_load * np.clip(elastic_fact, 0.01, 1.0)
            simulated_load_all.extend(sim_load)

        else:
            optimized_prices.extend([FLAT_RATE]*len(daily_load))
            simulated_load_all.extend(daily_load)

    month_df['dynamic_price'] = optimized_prices
    month_df['simulated_load'] = simulated_load_all

    return month_df


# ---------------------------------------------------------------
def analyze_and_plot(month_df, month_name):
    old_total = np.sum(month_df['y'] * FLAT_RATE)
    new_total = np.sum(month_df['simulated_load'] * month_df['dynamic_price'])

    avg_old_tariff = FLAT_RATE
    avg_new_tariff = new_total / np.sum(month_df['simulated_load'])
    
    median_new_tariff = np.median(month_df['dynamic_price'])

    print("\n" + "="*50)
    print(f"{month_name.upper()} 2024 OPTIMIZATION RESULTS")
    print("="*50)
    print(f"Avg Tariff (Flat):   ₹ {avg_old_tariff:,.2f} / MWh")
    print(f"Avg Tariff (Dynamic):₹ {avg_new_tariff:,.2f} / MWh")
    print(f"Median Tariff (AI):  ₹ {median_new_tariff:,.2f} / MWh") 
    print("-" * 50)
    print(f"Total Consumer Bill (Flat):   ₹ {old_total:,.2f}")
    print(f"Total Consumer Bill (Dynamic):₹ {new_total:,.2f}")

    if new_total < old_total:
        print(f" Net Consumer Savings:      ₹ {old_total - new_total:,.2f}")
    else:
        print(f" Net Consumer Extra Cost:   ₹ {new_total - old_total:,.2f}")

    print("="*50)

    zoom_data = month_df.head(24 * 7)

    fig, axes = plt.subplots(2, 1, figsize=(14, 8))

    axes[0].plot(zoom_data['ds'], zoom_data['y'], linewidth=2)
    axes[0].fill_between(zoom_data['ds'], zoom_data['y'], color='blue', alpha=0.1)
    axes[0].set_title(f"1. Electricity Demand ({month_name} 2024)", fontweight='bold')
    axes[0].set_ylabel("Load (MW)")
    axes[0].grid(True, alpha=0.3)

    axes[1].step(
        zoom_data['ds'],
        zoom_data['dynamic_price'],
        where='mid',
        color='red',
        linewidth=2,
        label="Dynamic Tariff"
    )
    axes[1].axhline(FLAT_RATE, color='gray', linestyle='--', label="Flat Rate (₹7000/MWh)")
    axes[1].set_ylim(2000, 11000)
    axes[1].set_title("2. Optimized Dynamic Tariff Signal", fontweight='bold')
    axes[1].set_ylabel("Price (₹/MWh)")
    axes[1].set_xlabel("Date")
    axes[1].legend()

    plt.tight_layout()
    plt.savefig(f"{month_name}_2024_Final_Analysis.png", dpi=300)
    plt.show(block=False)


# ---------------------------------------------------------------
if __name__ == "__main__":

    may_2024, oct_2024, global_min, global_max = load_exact_data("INDIAhourly_load.csv")

    if not may_2024.empty:
        may_2024 = optimize_game_theory_tariffs(may_2024, global_min, global_max)
        analyze_and_plot(may_2024, "May")
        may_2024.to_csv("May_2024_Final_Tariffs.csv", index=False)

    if not oct_2024.empty:
        oct_2024 = optimize_game_theory_tariffs(oct_2024, global_min, global_max)
        analyze_and_plot(oct_2024, "October")
        oct_2024.to_csv("October_2024_Final_Tariffs.csv", index=False)

    plt.show()