import pandas as pd
df = pd.read_csv('india_complete_load_2001_2025.csv', nrows=5)
print(df['datetime'].head())
print(pd.to_datetime(df['datetime']).head())
