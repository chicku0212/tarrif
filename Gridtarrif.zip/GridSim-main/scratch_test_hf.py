import asyncio
import httpx
import json
from datetime import datetime, timedelta

async def test():
    # Construct a dummy 24-hour weather sequence
    features = []
    base_time = datetime(2019, 1, 1, 0, 0, 0)
    for i in range(24):
        features.append({
            "timestamp": (base_time + timedelta(hours=i)).isoformat(),
            "temperature": 25.0 + (5.0 if 10 <= i <= 16 else 0.0),
            "humidity": 60.0,
            "wind_speed": 10.0
        })
    
    url = "https://samorion-gridsim-inference-api.hf.space/predict/transformer"
    async with httpx.AsyncClient() as client:
        res = await client.post(url, json={"features": features})
        print(f"Prediction: {res.json()}")

asyncio.run(test())
