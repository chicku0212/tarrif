# IndiaLoadTariff Digital Twin Simulator

This project contains a real-time data simulator for the IndiaLoadTariff digital twin.

## How it Works (The Simple Explanation)

Imagine you have a **Time Machine** and a **Crystal Ball**.

1.  **The Time Machine (The Simulator)**:
    We are taking a recording of India's power grid from 2001 to 2025 and playing it back. It’s like watching a replay of a video game. We can speed it up (so 1 hour happens in 1 second) to see years fly by quickly.

2.  **The Crystal Ball (The Digital Twin AI)**:
    As the "video" plays, we have an Artificial Intelligence watching it live.
    *   It **watches** the current weather and electricity usage.
    *   It **guesses (predicts)** what will happen in the next 24 hours.
    *   Then, we compare its guess to what *actually* happens in the next frame to see how smart it is.

**Features:**
- **"What-If" Analysis**: You can inject scenarios like a "Heatwave" (add 5°C) or "EV Boom" (add 10% load) in real-time to see how the grid reacts.

## Features
- **Data Replay**: Replays historical load and weather data from `INDIAmerged_hourly_load_weather.csv`.
- **WebSocket Server**: Broadcasts data via WebSocket at `ws://localhost:8000/ws/simulation`.
- **Robust Configuration**: Uses Pydantic and YAML for type-safe, hierarchical configuration management.
- **Environment Support**: Supports `dev`, `staging`, and `prod` environments with specific overrides.
- **Configurable Speed**: Simulation speed can be adjusted via `config/{env}.yaml` or `APP_SIMULATOR__SPEED_MULTIPLIER` environment variable.
- **Noise Injection**: Adds random noise (2-5%) to numerical values.
- **Logging**: Logs events to `simulation.log`.

## Usage

### Prerequisites
- Python 3.x
- Virtual environment (recommended)
- PostgreSQL (for API and Loader components)
- Dependencies: `pandas`, `fastapi`, `uvicorn`, `psycopg2-binary`, `pydantic`, `pydantic-settings`, `PyYAML`

### Installation
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # Configure your secrets
```

### Configuration
The system uses a hierarchical configuration strategy:
1. **Base**: `config/base.yaml` (Common defaults)
2. **Environment**: `config/{env}.yaml` (e.g., `dev.yaml`, `prod.yaml`)
3. **Secrets**: `.env` file (Loaded via `python-dotenv`)
4. **Environment Variables**: Prefix with `APP_` to override (e.g., `APP_DB_HOST=localhost`). Nested fields use double underscore (e.g., `APP_SIMULATOR__SPEED_MULTIPLIER`).

Set the environment via `APP_ENV` (defaults to `dev`).

### Running the Simulator
```bash
# Start the simulator server (uses config/dev.yaml by default)
uvicorn src.simulator:app --reload
```
The simulator will start broadcasting data immediately upon the first client connection (or startup, depending on implementation).

### Running the Client
```bash
python src/client.py
```
## model-microservice (Digital Twin)

This directory (`app/`) contains the production-ready FastAPI microservice for India Load Tariff prediction.
It acts as a **Digital Twin**, simulating grid load based on a 24-hour weather and time profile.

### Key Features
- **Digital Twin Logic**: Ignores historical load data. purely functioning on environmental state (Weather + Time).
- **Models**:
    - **Standard LSTM**: Baseline RNN.
    - **Deep LSTM**: Stacked LSTM (2 layers, 64 hidden units).
    - **Transformer**: Self-attention model.
- **Automated Operations**:
    - **JIT Compilation**: Models are scripted via `torch.jit` for performance.
    - **Warmup**: Inference is run on dummy data at startup to initialize CUDA/CPU caches.
    - **Preprocessing**: Internal handling of feature engineering (Dew Point) and scaling.

### API Architecture
- **Location**: `app/`
- **Entrypoint**: `app/main.py`
- **Models**: `app/models/`
- **Preprocessing**: `app/preprocessing.py`

### Usage

1.  **Install Dependencies**
    ```bash
    pip install -r requirements.txt
    ```

2.  **Run Service**
    ```bash
    uvicorn app.main:app --host 0.0.0.0 --port 8000
    ```

3.  **Predict**
    Send a POST request to `/predict/{model_type}` (lstm, deeplstm, transformer) with a 24-hour weather sequence.
    ```json
    {
      "features": [
        {"timestamp": "2024-01-01T00:00:00", "temperature": 25.0, "humidity": 60.0, "wind_speed": 10.0},
        ... (24 points total)
      ]
    }
    ```

## Digital Twin State Management Engine

The State Management Engine maintains the real-time grid state, persists data, and handles alerting.

### Architecture
- **State Model**: `DigitalTwinState` (Pydantic) tracks load, weather, time features, and prediction variance.
- **Persistence**: 
  - **Hot Storage**: Redis (Key: `digital_twin:current_state`) for low-latency access.
  - **Historical Archive**: TimescaleDB (Table: `digital_twin_states`) for trend analysis.
- **Alerting**: Monitors for data staleness (> 15 mins delay).
- **Snapshots**: Periodic state serialization to Redis.

### Setup
1. **Start Redis**:
   ```bash
   docker run -d --name redis-stack -p 6379:6379 -p 8001:8001 redis/redis-stack:latest
   ```
2. **Environment Variables**:
   Ensure `.env` contains:
   ```bash
   APP_DATABASE__PASSWORD=your_db_password  # e.g., 1111
   ```

### Running the Engine
```bash
python src/run_engine.py
```
This script connects to the Simulator WebSocket, processes updates, and saves state to Redis/TimescaleDB.

## What-If Simulation Engine

The Simulation Engine enables scenario testing and future load prediction (up to 168 hours) using the Digital Twin state.

### Core Capabilities
- **State Forking**: Isolates current grid state to run independent simulations without affecting real-time operations.
- **Scenario Generators**:
    - **Temperature**: Adjust weather forecast (+/- N degrees) to test load sensitivity.
    - **Festival**: Apply demand surge factors (+X%) to simulate events.
    - **Renewable Injection**: Simulate load reduction due to solar/wind integration.
- **Multi-Model Support**: Run simulations using **LSTM**, **Deep LSTM**, or **Transformer** models.
- **Fast-Forward**: Vectorized execution allows 168-hour simulations to complete in milliseconds.

### API Usage
- **Run Simulation**: `POST /simulation/run` with configuration (start time, horizon, scenarios).
- **Inject Scenarios**: `POST /simulation/what-if` (Live "Heatwave" or "EV Boom" injection).
- **Compare**: `GET /simulation/compare?sim_ids=...` to retrieve multi-scenario datasets for plotting.
- **Export**: `GET /simulation/export/{sim_id}` (CSV/JSON).

### Verification
- **Automated Script**: `scripts/verify_simulation_flow.py` validates the entire pipeline.
- **Integration Tests**: `tests/test_simulation_engine.py` ensures model integration.

## Dashboard Backend Features (New)

The system now supports a full-featured Digital Twin Dashboard.

### Real-Time Streaming
- **WebSockets**: `ws://localhost:8000/ws/dashboard`
  - Subscribes to Redis channel `digital_twin:updates`.
  - Broadcasts live grid state (Load, Weather, Predictions) to connected clients.
- **Server-Sent Events (SSE)**: `GET /sse/stream` (Paused/Backburner)
  - Alternative lightweight streaming for unidirectional updates.

### Queue-Based Simulation Results Panel
The dashboard now includes a comprehensive `PredictionComparison` component:
- **Instant Modifiers**: Adjust Temperature, Load Multiplier, or Renewable percentage limits visually via slider configurations calling `POST /simulation/what-if`.
- **Parallel AI Execution**: Instantly runs LSTM, Deep LSTM, and Transformer inferences side-by-side with staggered visualization rendering.
- **Queue State Control**: Stores up to 5 historical "What-If" scenarios in memory allowing users to scroll and compare varying modifier scenarios simultaneously.

### Analytics & Aggregation
- **Data Source**: Uses `asyncpg` to query TimescaleDB for historical analysis.
- **Endoints**:
  - `/analytics/daily-peak`: Track peak demand trends.
  - `/analytics/accuracy`: Rolling 7-day MAPE calculation.

### Performance & Security
- **Rate Limiting**: `fastapi-limiter` (Redis-backed) protects public endpoints.
- **Caching**: Redis caches partial results for expensive aggregation queries.

### Dashboard Frontend UI
The `LiveLoadChart` implements real-time monitoring and parallel client-side inference tracking:
- **Parallel Prediction Fetch**: Upon an incoming Websocket tick, the frontend queries `POST /predict/lstm`, `/predict/deeplstm`, and `/predict/transformer` concurrently with the rolling last 24hr weather sequence.
- **Data Plotting Alignment**: Predictions evaluated for time `T+1` based on state up to time `T` are mapped directly onto the `T+1` position in the visualization array. 
- **Graceful Degradation**: Missing histories (<24 points) or failed inference endpoints fall back gracefully, rending dashed grey model unavailable series.
- **Simulation Synchronization**: The what-if simulation panel strictly synchronizes the forecasting `start_time` with the livestream's `base_timestamp` and automatically maps user-defined UI modifiers (such as Temperature offset and Demand Load multipliers) into backend `TemperatureScenario` and `FestivalScenario` arrays for dynamically altering the raw database baseline before routing data to the AI model.

### Multi-Model Performance Analytics
The dashboard now actively monitors and scores models based on real-time prediction accuracy via the `ModelPerformanceMetrics` component.
- **Real-Time Embedded Streaming**: Instead of the frontend polling an HTTP endpoint for performance metrics, the backend simulation engine intelligently calculates `RMSE`, `MAE`, `MAPE`, and `R2` inline (for the last 24 items) and embeds this data seamlessly into the main `digital_twin:updates` WebSocket payload under the `.metrics` property.
- **Perfect Synchronization**: By calculating and sending the performance metrics directly on the simulation stream, the frontend UI indicators and graph points update in perfectly synchronized lockstep, completely regardless of the chosen simulated speed multiplier.
- **Metrics Dashboard**: Generates real-time "BEST" modeling recognition caps for models with MAPE parity within `< 0.1%`, tracking historical metric degradations inline with Recharts, and utilizes CSS color tokens seamlessly matched with the `LiveLoadChart`.

### Alert Notification System Context (AlertNotificationSystem.jsx)
- **Data Source**: Replaces mock alerts by consuming `liveData` from `DashboardContext.jsx`.
- **Fields Expected**: Relies on backend simulator forwarding `temperature_2m`, `relative_humidity_2m`, `windspeed_10m`, `load`, and three predictions (`lstm`, `deeplstm`, `transformer`).
- **Historical Tracking**: Employs `useRef` arrays (`tempHistory` & `loadHistory`) to compute 3-hour temperature deltas and 1-hour load spikes/drops over the *simulated timestamp* (`liveData.timestamp`).
- **Deduplication Logic**: Driven strictly via `liveData.timestamp` simulation time lockouts (2 simulated hours per alert type), resolving edge cases where simulated speeds result in redundant alerts. 
- **Animation Considerations**: React-level hooks account for `prefers-reduced-motion` alongside CSS manual keyframes. Alerts utilize absolute sliding transitions except when disabled by OS preferences.
