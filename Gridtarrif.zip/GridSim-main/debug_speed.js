let speed = 1000;
let realWorldDelay = (60 * 60) / speed; // simulator advances 1 hour per ...?
console.log(realWorldDelay)
