import urllib.request, json
import numpy as np

url = "http://localhost:8000/analytics/model-performance"
req = urllib.request.Request(url)
with urllib.request.urlopen(req) as response:
    data = json.loads(response.read().decode())
    print(json.dumps(data, indent=4))
