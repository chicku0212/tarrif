import pandas as pd
from datetime import datetime

data = [{"timestamp": datetime.now()}]
df = pd.DataFrame(data)
print(df['timestamp'].dt.hour)
