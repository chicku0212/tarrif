#!/bin/bash
# Manual Verification Script for Digital Twin Backend

echo "🚀 Starting Manual Verification..."

# 1. Start Redis check
echo "Checking Redis..."
redis-cli ping > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo "✅ Redis is responding (PONG)"
else
    echo "❌ Redis is NOT responding. Please start Redis."
    exit 1
fi

# 2. Check Database Connection (using psql/python script)
echo "Checking Database..."
export APP_DATABASE__PASSWORD=1111
python3 -c "import asyncio; from tests.test_db_connection import test_db_connection; asyncio.run(test_db_connection())" > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo "✅ Database connection successful"
else
    echo "❌ Database connection failed."
    exit 1
fi

# 3. Check Server Endpoints (assuming server is running)
echo "Checking Backend API (assuming it's running on localhost:8000)..."
STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/health)

if [ "$STATUS" -eq 200 ]; then
    echo "✅ /health endpoint reachable (200 OK)"
else
    echo "⚠️  Backend not reachable at http://localhost:8000. Is the server running?"
    echo "   Run: uvicorn app.main:app --reload --host 0.0.0.0 --port 8000"
fi

# 4. Check WebSocket
# Simple python script to connect and close
echo "Checking WebSocket..."
python3 -c "
import asyncio
import websockets
import sys

async def check_ws():
    try:
        async with websockets.connect('ws://localhost:8000/ws/dashboard') as websocket:
            print('✅ WebSocket connection successful')
    except Exception as e:
        print(f'❌ WebSocket connection failed: {e}')
        sys.exit(1)

asyncio.run(check_ws())
"

echo "🎉 Manual Verification Script Complete."
echo ""
echo "To run the FULL system:"
echo "1. Start Backend: uvicorn app.main:app --reload --host 0.0.0.0 --port 8000"
echo "2. Start Simulation (in another term): python -m src.run_engine"
