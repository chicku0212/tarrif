import json
import os

notebook_path = 'IndiaLSTM.ipynb'

with open(notebook_path, 'r') as f:
    notebook = json.load(f)

# 1. Remove cells containing "pip install tensorflow", "import tensorflow", "from tensorflow"
# or "model = Sequential()" which are Keras specific
new_cells = []
for cell in notebook['cells']:
    if cell['cell_type'] == 'code':
        source = "".join(cell['source'])
        if "pip install tensorflow" in source:
            continue
        if "import tensorflow" in source or "from tensorflow" in source:
            continue
        if "model = Sequential()" in source and "LSTM" in source:
            continue
        if "model.compile" in source or "model.fit" in source or "model.summary" in source or "model.save" in source:
             continue
        new_cells.append(cell)
    else:
        new_cells.append(cell)

notebook['cells'] = new_cells

# 2. Inject PyTorch Code
# We need to find where to inject. Let's inject after data preprocessing.
# Look for where 'X_train_keras' is created or 'scaler' is defined.
inject_index = -1
for i, cell in enumerate(notebook['cells']):
    if cell['cell_type'] == 'code':
        source = "".join(cell['source'])
        if "X_train_keras =" in source and "reshape" in source:
            inject_index = i + 1
            break

# 3. Prepare Blocks
imports_code = [
    "import torch\n",
    "import torch.nn as nn\n",
    "import torch.optim as optim\n",
    "from torch.utils.data import TensorDataset, DataLoader\n",
    "import pickle\n",
    "import os\n",
    "from sklearn.preprocessing import MinMaxScaler\n",
    "import pandas as pd\n",
    "import numpy as np\n",
    "import matplotlib.pyplot as plt\n",
    "print('PyTorch imports loaded')"
]

model_code = [
    "# Convert data to PyTorch tensors\n",
    "X_train_tensor = torch.FloatTensor(X_train_keras)\n",
    "y_train_tensor = torch.FloatTensor(y_train_keras).view(-1, 1)\n",
    "X_test_tensor = torch.FloatTensor(X_test_keras)\n",
    "y_test_tensor = torch.FloatTensor(y_test_keras).view(-1, 1)\n",
    "\n",
    "# Create DataLoaders\n",
    "train_dataset = TensorDataset(X_train_tensor, y_train_tensor)\n",
    "test_dataset = TensorDataset(X_test_tensor, y_test_tensor)\n",
    "\n",
    "batch_size = 64\n",
    "train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)\n",
    "test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)\n",
    "\n",
    "# Define PyTorch LSTM Model\n",
    "class IndiaLSTM(nn.Module):\n",
    "    def __init__(self, input_size, hidden_size, num_layers, output_size, dropout=0.2):\n",
    "        super(IndiaLSTM, self).__init__()\n",
    "        self.hidden_size = hidden_size\n",
    "        self.num_layers = num_layers\n",
    "        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, dropout=dropout)\n",
    "        self.fc = nn.Linear(hidden_size, output_size)\n",
    "\n",
    "    def forward(self, x):\n",
    "        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)\n",
    "        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)\n",
    "\n",
    "        out, _ = self.lstm(x, (h0, c0))\n",
    "        out = self.fc(out[:, -1, :])\n",
    "        return out\n",
    "\n",
    "# Hyperparameters\n",
    "input_size = X_train_keras.shape[2]\n",
    "hidden_size = 50\n",
    "num_layers = 1\n",
    "output_size = 1\n",
    "dropout = 0.2\n",
    "\n",
    "# Initialize model\n",
    "device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')\n",
    "model = IndiaLSTM(input_size, hidden_size, num_layers, output_size, dropout).to(device)\n",
    "\n",
    "# Loss and Optimizer\n",
    "criterion = nn.MSELoss()\n",
    "optimizer = optim.Adam(model.parameters(), lr=0.001)\n",
    "\n",
    "print(model)\n",
    "\n",
    "# Training Loop\n",
    "num_epochs = 10\n",
    "train_losses = []\n",
    "val_losses = []\n",
    "\n",
    "print('Starting Training...')\n",
    "for epoch in range(num_epochs):\n",
    "    model.train()\n",
    "    running_loss = 0.0\n",
    "    for X_batch, y_batch in train_loader:\n",
    "        X_batch, y_batch = X_batch.to(device), y_batch.to(device)\n",
    "        \n",
    "        optimizer.zero_grad()\n",
    "        outputs = model(X_batch)\n",
    "        loss = criterion(outputs, y_batch)\n",
    "        loss.backward()\n",
    "        optimizer.step()\n",
    "        running_loss += loss.item() * X_batch.size(0)\n",
    "    \n",
    "    epoch_loss = running_loss / len(train_loader.dataset)\n",
    "    train_losses.append(epoch_loss)\n",
    "    \n",
    "    # Validation\n",
    "    model.eval()\n",
    "    val_loss = 0.0\n",
    "    with torch.no_grad():\n",
    "        for X_val, y_val in test_loader:\n",
    "            X_val, y_val = X_val.to(device), y_val.to(device)\n",
    "            outputs = model(X_val)\n",
    "            loss = criterion(outputs, y_val)\n",
    "            val_loss += loss.item() * X_val.size(0)\n",
    "    \n",
    "    epoch_val_loss = val_loss / len(test_loader.dataset)\n",
    "    val_losses.append(epoch_val_loss)\n",
    "    \n",
    "    print(f'Epoch [{epoch+1}/{num_epochs}], Train Loss: {epoch_loss:.4f}, Val Loss: {epoch_val_loss:.4f}')\n",
    "\n",
    "# Save Model\n",
    "if not os.path.exists('models'):\n",
    "    os.makedirs('models')\n",
    "\n",
    "torch.save(model.state_dict(), 'models/lstm_model.pt')\n",
    "print('Model saved to models/lstm_model.pt')\n",
    "\n",
    "# Save Scaler\n",
    "with open('models/scaler_lstm.pkl', 'wb') as f:\n",
    "    pickle.dump(scaler, f)\n",
    "print('Scaler saved to models/scaler_lstm.pkl')"
]

# Insert imports at top of code cells (after user imports if possible, or just index 0 of code cells)
# Let's find first code cell
for i, cell in enumerate(notebook['cells']):
    if cell['cell_type'] == 'code':
        # Create new imports cell
        import_cell = {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": imports_code
        }
        notebook['cells'].insert(i, import_cell)
        break

# Recalculate inject index because we inserted a cell
# Find 'X_train_keras' again
inject_index = -1
for i, cell in enumerate(notebook['cells']):
    if cell['cell_type'] == 'code':
        source = "".join(cell['source'])
        if "X_train_keras =" in source and "reshape" in source:
            inject_index = i + 1
            break

if inject_index != -1:
    model_cell = {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": model_code
    }
    notebook['cells'].insert(inject_index, model_cell)

with open(notebook_path, 'w') as f:
    json.dump(notebook, f, indent=1)

print(f"Fixed {notebook_path}")

