
import asyncio
import sys
import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging

# Add project root to sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.simulation_engine import SimulationEngine, SimulationConfig, ScenarioConfig, ScenarioType
from src.model_executor import ModelExecutor

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("VerificationParams")

async def run_verification():
    logger.info("Initializing Model Executor...")
    executor = ModelExecutor()
    engine = SimulationEngine(executor)
    
    start_time = datetime(2024, 1, 1, 0, 0, 0)
    hours = 24
    
    # Create Dummy Initial State if DB fetch is mocked/bypassed in engine for now
    # Ideally engine.run fetches, but here we pass explicitly if we modified engine.run signature
    # checking signature: async def run(self, config: SimulationConfig, initial_state: pd.DataFrame)
    
    # Create valid dummy input
    rows = []
    current = start_time
    for _ in range(hours):
        rows.append({
            "timestamp": current,
            "temperature_2m": 25.0,
            "relative_humidity_2m": 50.0,
            "windspeed_10m": 10.0,
            "dew_point_2m": 15.0,
            "region": "India"
        })
        current += timedelta(hours=1)
    
    df_initial = pd.DataFrame(rows)
    # Feature engineering for dummy
    df_initial['timestamp'] = pd.to_datetime(df_initial['timestamp'])
    dt = df_initial['timestamp'].dt
    df_initial['hour'] = dt.hour
    df_initial['day_of_month'] = dt.day
    df_initial['dayofweek'] = dt.dayofweek
    df_initial['day_of_year'] = dt.dayofyear
    df_initial['month'] = dt.month
    df_initial['year'] = dt.year
    df_initial['week_of_year'] = dt.isocalendar().week.astype(int)

    logger.info("--- 1. Baseline Run (LSTM) ---")
    config_base = SimulationConfig(
        start_time=start_time,
        hours=hours,
        model_type="LSTM",
        scenarios=[]
    )
    result_base = await engine.run(config_base, df_initial)
    logger.info(f"Baseline ID: {result_base.simulation_id}, Time: {result_base.execution_time_ms:.2f}ms")
    load_base = [r['predicted_load'] for r in result_base.results]
    logger.info(f"Avg Load: {np.mean(load_base):.2f}")

    logger.info("--- 2. Scenario Run (Temp +5) ---")
    config_temp = SimulationConfig(
        start_time=start_time,
        hours=hours,
        model_type="LSTM",
        scenarios=[
            ScenarioConfig(type=ScenarioType.TEMPERATURE, magnitude=5.0)
        ]
    )
    result_temp = await engine.run(config_temp, df_initial)
    logger.info(f"Scenario ID: {result_temp.simulation_id}, Time: {result_temp.execution_time_ms:.2f}ms")
    load_temp = [r['predicted_load'] for r in result_temp.results]
    logger.info(f"Avg Load: {np.mean(load_temp):.2f}")
    
    # Compare
    # Generally higher temp -> higher load (cooling) in India, or depends on season.
    # In Jan (winter), +5 might reduce heating load or increase AC? 
    # Let's just verify they are DIFFERENT at least.
    if not np.allclose(load_base, load_temp):
        logger.info("SUCCESS: Scenario produced different results.")
    else:
        logger.warning("WARNING: Scenario results identical to baseline. Model might be insensitive or logic failed.")

    logger.info("--- 3. Transformer Run ---")
    try:
        config_trans = SimulationConfig(
            start_time=start_time,
            hours=hours,
            model_type="Transformer",
            scenarios=[]
        )
        result_trans = await engine.run(config_trans, df_initial)
        logger.info(f"Transformer Run Success. Avg Load: {np.mean([r['predicted_load'] for r in result_trans.results]):.2f}")
    except Exception as e:
        logger.error(f"Transformer Run Failed: {e}")

    logger.info("--- 4. DeepLSTM Run ---")
    try:
        config_deep = SimulationConfig(
            start_time=start_time,
            hours=hours,
            model_type="DeepLSTM",
            scenarios=[]
        )
        result_deep = await engine.run(config_deep, df_initial)
        logger.info(f"DeepLSTM Run Success. Avg Load: {np.mean([r['predicted_load'] for r in result_deep.results]):.2f}")
    except Exception as e:
        logger.info(f"DeepLSTM Expected Failure (if model missing): {e}")

    print("\nVerification Complete.")

if __name__ == "__main__":
    asyncio.run(run_verification())
