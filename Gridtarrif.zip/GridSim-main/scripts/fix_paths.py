import json
import os
import glob

def fix_notebook_paths(notebook_path):
    with open(notebook_path, 'r') as f:
        content = f.read()
    
    # Replace /content/ with ./
    # and /content with ./
    
    new_content = content.replace('/content/', './').replace('/content', '.')
    
    if content != new_content:
        with open(notebook_path, 'w') as f:
            f.write(new_content)
        print(f"Fixed paths in {notebook_path}")
    else:
        print(f"No changes needed for {notebook_path}")

notebooks = [
    "IndiaLSTM.ipynb",
    "IndiaTransformer.ipynb",
    "IndiaTariff.ipynb", 
    "IndiaLSTMFed.ipynb",
    "IndiaFedTransformer.ipynb",
    "DatasetIndia.ipynb"
]

for nb in notebooks:
    if os.path.exists(nb):
        fix_notebook_paths(nb)
    else:
        print(f"Notebook {nb} not found, skipping.")
