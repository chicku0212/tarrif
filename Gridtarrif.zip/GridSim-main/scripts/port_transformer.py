import json
import os

notebook_path = 'IndiaTransformer.ipynb'

with open(notebook_path, 'r') as f:
    notebook = json.load(f)

# Code snippets to inject
imports_code = [
    "import torch\n",
    "import torch.nn as nn\n",
    "import torch.optim as optim\n",
    "from torch.utils.data import TensorDataset, DataLoader\n",
    "import pickle\n",
    "import os\n",
    "import math\n",
    "from sklearn.preprocessing import MinMaxScaler\n",
    "import pandas as pd\n",
    "import numpy as np\n",
    "import matplotlib.pyplot as plt"
]

model_code = [
    "# Convert data to PyTorch tensors\n",
    "X_train_tensor = torch.FloatTensor(X_train_keras)\n",
    "y_train_tensor = torch.FloatTensor(y_train_keras).view(-1, 1)\n",
    "X_test_tensor = torch.FloatTensor(X_test_keras)\n",
    "y_test_tensor = torch.FloatTensor(y_test_keras).view(-1, 1)\n",
    "\n",
    "# Create DataLoaders\n",
    "train_dataset = TensorDataset(X_train_tensor, y_train_tensor)\n",
    "test_dataset = TensorDataset(X_test_tensor, y_test_tensor)\n",
    "\n",
    "batch_size = 64\n",
    "train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)\n",
    "test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)\n",
    "\n",
    "# Define PyTorch Transformer Model\n",
    "class PositionalEncoding(nn.Module):\n",
    "    def __init__(self, d_model, dropout=0.1, max_len=5000):\n",
    "        super(PositionalEncoding, self).__init__()\n",
    "        self.dropout = nn.Dropout(p=dropout)\n",
    "\n",
    "        pe = torch.zeros(max_len, d_model)\n",
    "        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)\n",
    "        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))\n",
    "        pe[:, 0::2] = torch.sin(position * div_term)\n",
    "        pe[:, 1::2] = torch.cos(position * div_term)\n",
    "        pe = pe.unsqueeze(0)\n",
    "        self.register_buffer('pe', pe)\n",
    "\n",
    "    def forward(self, x):\n",
    "        x = x + self.pe[:, :x.size(1)]\n",
    "        return self.dropout(x)\n",
    "\n",
    "class IndiaTransformer(nn.Module):\n",
    "    def __init__(self, input_size, d_model, nhead, num_encoder_layers, dim_feedforward, output_size, dropout=0.1):\n",
    "        super(IndiaTransformer, self).__init__()\n",
    "        self.embedding = nn.Linear(input_size, d_model)\n",
    "        self.pos_encoder = PositionalEncoding(d_model, dropout)\n",
    "        encoder_layers = nn.TransformerEncoderLayer(d_model, nhead, dim_feedforward, dropout, batch_first=True)\n",
    "        self.transformer_encoder = nn.TransformerEncoder(encoder_layers, num_encoder_layers)\n",
    "        self.fc = nn.Linear(d_model, output_size)\n",
    "        self.d_model = d_model\n",
    "\n",
    "    def forward(self, src):\n",
    "        src = self.embedding(src) * math.sqrt(self.d_model)\n",
    "        src = self.pos_encoder(src)\n",
    "        output = self.transformer_encoder(src)\n",
    "        output = self.fc(output[:, -1, :])\n",
    "        return output\n",
    "\n",
    "# Hyperparameters\n",
    "input_size = X_train_keras.shape[2]\n",
    "d_model = 64\n",
    "nhead = 4\n",
    "num_encoder_layers = 1\n",
    "dim_feedforward = 128\n",
    "output_size = 1\n",
    "dropout = 0.1\n",
    "\n",
    "# Initialize model\n",
    "device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')\n",
    "model = IndiaTransformer(input_size, d_model, nhead, num_encoder_layers, dim_feedforward, output_size, dropout).to(device)\n",
    "\n",
    "# Loss and Optimizer\n",
    "criterion = nn.MSELoss()\n",
    "optimizer = optim.Adam(model.parameters(), lr=0.001)\n",
    "\n",
    "print(model)\n",
    "\n",
    "# Training Loop\n",
    "num_epochs = 10\n",
    "train_losses = []\n",
    "val_losses = []\n",
    "\n",
    "print('Starting Training...')\n",
    "for epoch in range(num_epochs):\n",
    "    model.train()\n",
    "    running_loss = 0.0\n",
    "    for X_batch, y_batch in train_loader:\n",
    "        X_batch, y_batch = X_batch.to(device), y_batch.to(device)\n",
    "        \n",
    "        optimizer.zero_grad()\n",
    "        outputs = model(X_batch)\n",
    "        loss = criterion(outputs, y_batch)\n",
    "        loss.backward()\n",
    "        optimizer.step()\n",
    "        running_loss += loss.item() * X_batch.size(0)\n",
    "    \n",
    "    epoch_loss = running_loss / len(train_loader.dataset)\n",
    "    train_losses.append(epoch_loss)\n",
    "    \n",
    "    # Validation\n",
    "    model.eval()\n",
    "    val_loss = 0.0\n",
    "    with torch.no_grad():\n",
    "        for X_val, y_val in test_loader:\n",
    "            X_val, y_val = X_val.to(device), y_val.to(device)\n",
    "            outputs = model(X_val)\n",
    "            loss = criterion(outputs, y_val)\n",
    "            val_loss += loss.item() * X_val.size(0)\n",
    "    \n",
    "    epoch_val_loss = val_loss / len(test_loader.dataset)\n",
    "    val_losses.append(epoch_val_loss)\n",
    "    \n",
    "    print(f'Epoch [{epoch+1}/{num_epochs}], Train Loss: {epoch_loss:.4f}, Val Loss: {epoch_val_loss:.4f}')\n",
    "\n",
    "# Save Model\n",
    "if not os.path.exists('models'):\n",
    "    os.makedirs('models')\n",
    "\n",
    "torch.save(model.state_dict(), 'models/transformer_model.pt')\n",
    "print('Model saved to models/transformer_model.pt')\n",
    "\n",
    "# Save Scaler\n",
    "with open('models/scaler_transformer.pkl', 'wb') as f:\n",
    "    pickle.dump(scaler, f)\n",
    "print('Scaler saved to models/scaler_transformer.pkl')"
]

# Identify cells to replace
imports_cell_idx = -1
model_cell_idx = -1

for i, cell in enumerate(notebook['cells']):
    if cell['cell_type'] == 'code':
        source = "".join(cell['source'])
        if "import tensorflow" in source:
            imports_cell_idx = i
        if "transformer_block" in source or "num_transformer_blocks" in source:
             # Heuristic for finding transformer model definition
            model_cell_idx = i

# Replace content
if imports_cell_idx != -1:
    notebook['cells'][imports_cell_idx]['source'] = imports_code
    # Clear outputs
    notebook['cells'][imports_cell_idx]['outputs'] = []

if model_cell_idx != -1:
    notebook['cells'][model_cell_idx]['source'] = model_code
    # Clear outputs
    notebook['cells'][model_cell_idx]['outputs'] = []
    
    # Remove subsequent Keras-specific cells
    indices_to_remove = []
    for j in range(model_cell_idx + 1, len(notebook['cells'])):
        cell = notebook['cells'][j]
        if cell['cell_type'] == 'code':
            src = "".join(cell['source'])
            if "model.compile" in src or "model.fit" in src or "model.summary" in src or "model.save" in src or "ModelCheckpoint" in src:
                indices_to_remove.append(j)
    
    for idx in sorted(indices_to_remove, reverse=True):
        del notebook['cells'][idx]

with open(notebook_path, 'w') as f:
    json.dump(notebook, f, indent=1)

print(f"Modified {notebook_path}")

