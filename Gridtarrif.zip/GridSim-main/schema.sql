-- Create the energy_data table natively partitioned
CREATE TABLE IF NOT EXISTS energy_data (
    timestamp TIMESTAMPTZ NOT NULL,
    region TEXT NOT NULL,
    load_mw DOUBLE PRECISION,
    temperature DOUBLE PRECISION,
    humidity DOUBLE PRECISION,
    wind_speed DOUBLE PRECISION,
    precipitation DOUBLE PRECISION,
    UNIQUE (timestamp, region)
) PARTITION BY RANGE (timestamp);

-- Enable Row Level Security (Since you mentioned RLS)
ALTER TABLE energy_data ENABLE ROW LEVEL SECURITY;

-- Optional: Create a basic read-only policy for authenticated/anon users, adjust as needed!
CREATE POLICY "Allow public read access" ON energy_data FOR SELECT USING (true);

-- Minimal explicit native yearly partitioning (2019 - 2026) to avoid DO block syntax errors
CREATE TABLE IF NOT EXISTS energy_data_y2019 PARTITION OF energy_data FOR VALUES FROM ('2019-01-01') TO ('2020-01-01');
CREATE TABLE IF NOT EXISTS energy_data_y2020 PARTITION OF energy_data FOR VALUES FROM ('2020-01-01') TO ('2021-01-01');
CREATE TABLE IF NOT EXISTS energy_data_y2021 PARTITION OF energy_data FOR VALUES FROM ('2021-01-01') TO ('2022-01-01');
CREATE TABLE IF NOT EXISTS energy_data_y2022 PARTITION OF energy_data FOR VALUES FROM ('2022-01-01') TO ('2023-01-01');
CREATE TABLE IF NOT EXISTS energy_data_y2023 PARTITION OF energy_data FOR VALUES FROM ('2023-01-01') TO ('2024-01-01');
CREATE TABLE IF NOT EXISTS energy_data_y2024 PARTITION OF energy_data FOR VALUES FROM ('2024-01-01') TO ('2025-01-01');
CREATE TABLE IF NOT EXISTS energy_data_y2025 PARTITION OF energy_data FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');
CREATE TABLE IF NOT EXISTS energy_data_y2026 PARTITION OF energy_data FOR VALUES FROM ('2026-01-01') TO ('2027-01-01');

-- Indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_energy_data_region_time ON energy_data (region, timestamp DESC);
