import pandas as pd
from datetime import datetime, timezone, timedelta

# mock utc datetime
dt_utc = datetime(2019, 1, 7, 12, 30, tzinfo=timezone.utc)
df = pd.DataFrame([{"timestamp": dt_utc}])
print("Original hour:", df['timestamp'].dt.hour[0])

# convert to IST
df['timestamp'] = df['timestamp'].dt.tz_convert('Asia/Kolkata')
print("IST hour:", df['timestamp'].dt.hour[0])
print("IST minute:", df['timestamp'].dt.minute[0])
