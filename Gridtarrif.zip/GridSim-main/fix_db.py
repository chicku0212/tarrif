import asyncio
import asyncpg

async def main():
    conn = await asyncpg.connect('postgresql://postgres:1111@localhost/postgres')
    await conn.execute("DELETE FROM digital_twin_states WHERE timestamp > '2020-01-01'")
    rows = await conn.fetch("SELECT count(*) FROM digital_twin_states")
    print("Remaining rows:", rows[0]['count'])
    await conn.close()

asyncio.run(main())
